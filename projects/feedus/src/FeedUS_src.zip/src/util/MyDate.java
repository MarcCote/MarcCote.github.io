package util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

public class MyDate
{
	public static String valueOf(Calendar p_calendar)
	{
		return valueOf(p_calendar.getTime());
	}
	public static String valueOf(Date p_date)
	{
		return DateFormat.getDateTimeInstance().format(p_date);
	}
	
	private static SimpleDateFormat formatter_full_en = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss Z", Locale.ENGLISH);
	private static SimpleDateFormat formatter_compact_en = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.ENGLISH);
	
	private static ArrayList<DateFormat> m_parsers = null;;
	private static ArrayList<DateFormat> getDateParsers()
	{
		if (m_parsers == null)
		{
			m_parsers = new ArrayList<DateFormat>();
			m_parsers.add(formatter_full_en);
			m_parsers.add(formatter_compact_en);
		}
		
		return m_parsers;
	}
	
	public static Calendar parseToCalendar(String p_text)
	{
		Date date = parse(p_text);
		if (date == null)
			return null;
		
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(parse(p_text));
		return calendar;
	}
	
	public static Date parse(String p_text)
	{
		Date date = null;
		
		for (DateFormat parser : getDateParsers())
		{
			try
			{
				date = parser.parse(p_text);
			}
			catch (ParseException e) {}
		}
		
		return date;
	}
}
