package gui;

import db.tuple.TupleAlgo;

public class TreeItemAlgo
{
	private TupleAlgo m_algo;
	
	public TupleAlgo getAlgo() { return m_algo; }
	
	public TreeItemAlgo(TupleAlgo p_algo)
	{
		m_algo = p_algo;
	}
	
	@Override
	public String toString()
	{	
		return m_algo.name;
	}
}
