package gui;

import db.tuple.TupleCategory;

public class TreeItemCategory
{
	public final static TreeItemCategory OTHERS = new TreeItemCategory(null); 
	
	private TupleCategory m_category;
	
	public TupleCategory getCategory() { return m_category; }
	
	public TreeItemCategory(TupleCategory p_category)
	{
		m_category = p_category;
	}
	
	@Override
	public String toString()
	{
		if (this == OTHERS)
			return "Others";
		
		return m_category.name;
	}
}
