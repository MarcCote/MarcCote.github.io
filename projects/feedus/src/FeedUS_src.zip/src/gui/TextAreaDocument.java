package gui;

import javax.swing.JEditorPane;

import db.tuple.TupleDocument;

public class TextAreaDocument extends JEditorPane
{
	private static final long	serialVersionUID	= 3377100048257133585L;

	private TupleDocument m_document = null;
	
	public TextAreaDocument(TupleDocument p_document)
	{
		super();
		
		m_document = p_document;
		setContentType("text/html");
		setText(p_document.text);
		
		setEditable(false);
	}
	
	public TupleDocument getTupleDocument()
	{
		return m_document;
	}
}
