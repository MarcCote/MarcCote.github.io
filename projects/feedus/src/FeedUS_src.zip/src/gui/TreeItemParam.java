package gui;

import db.tuple.TupleParam;

public class TreeItemParam
{
	private TupleParam m_param;
	
	public TupleParam getParam() { return m_param; }
	
	public TreeItemParam(TupleParam p_param)
	{
		m_param = p_param;
	}
	
	@Override
	public String toString()
	{	
		return m_param.name;
	}
}
