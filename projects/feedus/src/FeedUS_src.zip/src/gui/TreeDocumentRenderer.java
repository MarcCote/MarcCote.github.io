package gui;

import java.awt.Component;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;

public class TreeDocumentRenderer extends DefaultTreeCellRenderer
{
	private static final long	serialVersionUID	= -2471141846432112432L;
	
	Icon m_iconCategory;
    Icon m_iconSeen;
    Icon m_iconUnseen;
    Icon m_iconLock;

    public TreeDocumentRenderer()
    {
    	m_iconCategory = new ImageIcon(getClass().getResource("/gui/img/icon/category.png"));
    	m_iconSeen = new ImageIcon(getClass().getResource("/gui/img/icon/seen.png"));
    	m_iconUnseen = new ImageIcon(getClass().getResource("/gui/img/icon/unseen.png"));
    	m_iconLock = new ImageIcon(getClass().getResource("/gui/img/icon/lock.png"));
    }

    public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus)
    {
        super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
        
        if (!(value instanceof DefaultMutableTreeNode))
        	return this;
        
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)value;
        		
        if (node.getUserObject() instanceof TreeItemCategory)
        {
            setIcon(m_iconCategory);
        }
        else if (node.getUserObject() instanceof TreeItemDocument)
        {
        	if (((TreeItemDocument)node.getUserObject()).isAssignedByUser())
        		setIcon(m_iconLock);
        	else if (((TreeItemDocument)node.getUserObject()).getDocument().seen)
        		setIcon(m_iconSeen);
        	else
        		setIcon(m_iconUnseen);
        } 

        return this;
    }
}
