package gui;

public enum TypeModif
{
	NONE,
	INSERT,
	UPDATE,
	DELETE,
	DISPLAY,
}
