package gui;

import db.tuple.TupleDocument;

public class TreeItemDocument
{
	private TupleDocument m_document;
	private boolean m_isAssignedByUser;
	
	public TupleDocument getDocument() { return m_document; }
	public boolean isAssignedByUser() { return m_isAssignedByUser; }
	
	public TreeItemDocument(TupleDocument p_document, boolean p_isAssignedByUser)
	{
		m_document = p_document;
		m_isAssignedByUser = p_isAssignedByUser;
	}
	
	@Override
	public String toString()
	{
		return m_document.title;
	}

}
