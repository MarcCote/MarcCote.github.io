package gui;

import db.tuple.TupleRssFeed;

public class ListItemRssFeed
{
	private TupleRssFeed m_rssFeed;
	
	public TupleRssFeed getRSS() { return m_rssFeed; }
	
	public ListItemRssFeed(TupleRssFeed p_rssFeed)
	{
		m_rssFeed = p_rssFeed;
	}
	
	@Override
	public String toString()
	{
		return m_rssFeed.name;
	}
}
