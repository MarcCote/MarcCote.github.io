package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Observable;
import java.util.Observer;
import java.util.Properties;
import java.util.TreeMap;
import java.util.Map.Entry;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JToolBar;
import javax.swing.JTree;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.basic.BasicToolBarUI;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.DefaultTreeSelectionModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import algo.TypeAlgo;
import app.GestionFeedUS;
import app.exception.NotExistingException;
import db.MyConnection;
import db.TypeDB;
import db.tuple.TupleAlgo;
import db.tuple.TupleCategory;
import db.tuple.TupleDocument;
import db.tuple.TupleDocumentCategory;
import db.tuple.TupleParam;
import db.tuple.TupleRssFeed;
import javax.swing.JCheckBox;

public class FeedUS implements Observer
{

	private JFrame		jFrame				= null;  //  @jve:decl-index=0:visual-constraint="10,10"
	private JPanel		jContentPane		= null;  //  @jve:decl-index=0:
	private JMenuBar	jJMenuBar			= null;
	private JMenu		fileMenu			= null;
	private JMenu		editMenu			= null;
	private JMenu		helpMenu			= null;
	private JMenuItem	exitMenuItem		= null;
	private JMenuItem	aboutMenuItem		= null;
	private JMenuItem	cutMenuItem			= null;
	private JMenuItem	copyMenuItem		= null;
	private JMenuItem	pasteMenuItem		= null;
	private JMenuItem	jMenuItemConnect		= null;
	private JDialog		aboutDialog			= null;
	private JPanel		aboutContentPane	= null;
	private JLabel		aboutVersionLabel	= null;
	private JTabbedPane jTabbedPaneDocuments = null;
	private JTree jTreeDocuments = null;
	private JMenu jMenuAlgos = null;
	private JMenu jMenuRSS = null;
	private JMenu jMenuCategory = null;
	private JToolBar jJToolBarBar = null;
	private JButton jButtonAddCategory = null;
	private JButton jButtonRemoveCategory = null;
	private JButton jButtonFetchDocs = null;
	private JMenuItem jMenuItemAddCategory = null;
	private JMenuItem jMenuItemRemoveCategory = null;
	private JMenuItem jMenuItemAssign = null;
	private JMenuItem jMenuItemUnassign = null;
	private JMenuItem jMenuItemManageCategory = null;
	private JSeparator jSeparator1 = null;
	private JSplitPane jSplitPane = null;
	private JMenuItem jMenuItemManageRSS = null;
	private JMenuItem jMenuItemFetch = null;
	private JSeparator jSeparator2 = null;
	private JMenuItem jMenuItemCompare = null;
	private JSeparator jSeparator3 = null;
	private JRadioButtonMenuItem jRadioButtonMenuItemAlgoSVM = null;
	private JRadioButtonMenuItem jRadioButtonMenuItemAlgoRocchio = null;
	private ButtonGroup buttonGroupAlgoClassification = new ButtonGroup();  //  @jve:decl-index=0:
	private ButtonGroup buttonGroupAlgoClustering= new ButtonGroup();  //  @jve:decl-index=0:
	private JButton jButtonCompare = null;
	private JTextPane jTextPaneViewer = null;
	private JSeparator jSeparator4 = null;
	private JDialog jDialogConnect = null;  //  @jve:decl-index=0:visual-constraint="584,72"
	private JPanel jContentPaneConnect = null;
	private JPanel jPanelConnectServer = null;
	private JPanel jPanelConnectUser = null;
	private JPanel jPanelConnectButtons = null;
	private JButton jButtonConnectOK = null;
	private JButton jButtonConnectCancel = null;
	private JLabel jLabelConnectServerHost = null;
	private JLabel jLabelConnectServerDB = null;
	private JLabel jLabelConnectServerPort = null;
	private JTextField jTextFieldConnectServerHost = null;
	private JTextField jTextFieldConnectServerPort = null;
	private JTextField jTextFieldConnectServerDB = null;
	private JLabel jLabelConnectUserName = null;
	private JLabel jLabelConnectUserPassword = null;
	private JTextField jTextFieldConnectUserName = null;
	private JPasswordField jPasswordFieldConnectUserPassword = null;
	private JLabel jLabelStatusBar = null;
	
	private TypeAlgo m_classificationAlgo = TypeAlgo.USER;  //  @jve:decl-index=0:
	private TypeAlgo m_clusteringAlgo = TypeAlgo.NONE;  //  @jve:decl-index=0:
	
	private static String CONFIG_FILE = "settings.ini";  //  @jve:decl-index=0:
	private Properties m_configs = null;  //  @jve:decl-index=0:
	public void LoadConfigs() throws FileNotFoundException, IOException
	{
		m_configs = new Properties();
		
		File configFile = new File(CONFIG_FILE);
		
		if (!configFile.exists())
			configFile.createNewFile();
		
		m_configs.load(new FileInputStream(configFile));
	}
	public void SaveConfigs() throws FileNotFoundException, IOException
	{
		File configFile = new File(CONFIG_FILE);
		m_configs.store(new FileOutputStream(configFile), "FeedUS's Settings");
	}
	
	private GestionFeedUS m_gestionFeedUS = null;  //  @jve:decl-index=0:
	MyConnection m_cnx = null;  //  @jve:decl-index=0:
	private void disconnect() throws SQLException
	{
		m_cnx.close();
		m_cnx = null;
		m_gestionFeedUS.deleteObserver(this);
		m_gestionFeedUS = null;
		
		getJButtonAddCategory().setEnabled(false);
		getJButtonRemoveCategory().setEnabled(false);
		getJButtonTrain().setEnabled(false);
		getJButtonCompare().setEnabled(false);
		getJButtonRefresh().setEnabled(false);
		getJButtonFetchDocs().setEnabled(false);
		getJMenuAlgos().setEnabled(false);
		getJMenuCategory().setEnabled(false);
		getJMenuRSS().setEnabled(false);
	}
	
	private void connect(String p_host, String p_port, String p_dbName, String p_user, String p_password) throws SQLException
	{
		if (m_cnx != null)
			disconnect();
		
		m_cnx = new MyConnection(TypeDB.MYSQL, p_host, p_port, p_dbName, p_user, p_password);
		m_gestionFeedUS = new GestionFeedUS(m_cnx);
		m_gestionFeedUS.addObserver(this);
		
		getJButtonAddCategory().setEnabled(true);
		getJButtonRemoveCategory().setEnabled(true);
		getJButtonTrain().setEnabled(true);
		getJButtonCompare().setEnabled(true);
		getJButtonRefresh().setEnabled(true);
		getJButtonFetchDocs().setEnabled(true);
		getJMenuAlgos().setEnabled(true);
		getJMenuCategory().setEnabled(true);
		getJMenuRSS().setEnabled(true);
	}
	
	@SuppressWarnings("unused")
	private boolean isConnected()
	{
		return !m_cnx.isClosed() && m_gestionFeedUS != null;
	}
	
	@Override
	public void update(Observable o, Object arg)
	{
		refresh();
	}
	
	private void compare()
	{
	}
	
	private void train(TypeAlgo p_typeAlgo)
	{
		if (p_typeAlgo == TypeAlgo.NONE || p_typeAlgo == TypeAlgo.USER)
		{
			displayWarning(p_typeAlgo.name() + " does not need to be trained.");
			return;
		}
		
		train(p_typeAlgo.getCode());
	}
	
	private void train(Long p_idAlgo)
	{
		TupleAlgo algo;
		try
		{
			algo = m_gestionFeedUS.getAlgo(p_idAlgo);
			
			if (algo == null)
			{
				displayError("Algorithm does not exist: " + p_idAlgo);
				return;
			}
			
			displayMsg("Training " + algo.name + "...");
			
			m_gestionFeedUS.train(p_idAlgo);
			
			displayMsg(algo.name + " has been succesfully trained.");
		}
		catch (SQLException e)
		{
			displayError("Error while training: " + e.getMessage());
		}
		catch (NotExistingException e)
		{
			displayError("Error while training: " + e.getMessage());
		}
	}
	
	private void refresh()
	{
		displayError("Refreshing...");
		try
		{
			TreeMap<TupleCategory, ArrayList<TupleDocumentCategory>> documentsByCategory = m_gestionFeedUS.getDocs(m_classificationAlgo, m_clusteringAlgo);
			DefaultTreeModel model = (DefaultTreeModel)getJTreeDocuments().getModel();
			
			model.setRoot(null);
			DefaultMutableTreeNode root = new DefaultMutableTreeNode();			
			model.setRoot(root);
			
			boolean addedOthers = false;
			
			for (Entry<TupleCategory, ArrayList<TupleDocumentCategory>> entry : documentsByCategory.entrySet())
			{
				if (!entry.getKey().createdByUser && !addedOthers)
				{
					DefaultMutableTreeNode tmp = new DefaultMutableTreeNode(TreeItemCategory.OTHERS);
					//root.add(tmp);
					model.insertNodeInto(tmp, root, root.getChildCount());
					root = tmp;
					addedOthers = true;
				}
				
				//Add category
				DefaultMutableTreeNode node = new DefaultMutableTreeNode(new TreeItemCategory(entry.getKey()));
				//root.add(node);
				model.insertNodeInto(node, root, root.getChildCount());
				
				Collections.sort(entry.getValue(), new Comparator<TupleDocumentCategory>()
				{
					@Override
					public int compare(TupleDocumentCategory o1, TupleDocumentCategory o2)
					{
						return o1.document.title.compareToIgnoreCase(o1.document.title);
					}}
				);
				
				for (TupleDocumentCategory element : entry.getValue())
				{
					boolean isAssignedByUser = element.idAlgo == TypeAlgo.USER.getCode();
					DefaultMutableTreeNode leaf = new DefaultMutableTreeNode(new TreeItemDocument(element.document, isAssignedByUser));
					leaf.setAllowsChildren(false);
					//node.add(leaf);

					model.insertNodeInto(leaf, node, node.getChildCount());
				}
			}
			
			model.reload((TreeNode)model.getRoot());
			
			for (int i = 0; i < getJTreeDocuments().getRowCount(); i++)
				getJTreeDocuments().expandRow(i);
			
			displayError("Refreshing... Completed.");
		}
		catch (SQLException e)
		{
			displayError("Error while refreshing documents: " + e.getMessage());
		}
	}

	private void fetch()
	{
		try
		{
			displayError("Fetching...");
			m_gestionFeedUS.fetch();
			refresh();
			displayMsg("Fetching... completed");
		}
		catch (SQLException e)
		{
			displayError("Error while fetching: " + e.getMessage());
		}
	}
	
	//Category Management
	private static String DEFAULT_CATEGORY_NAME = "--New Category--";  //  @jve:decl-index=0:
	private TypeModif m_categoryModifType = TypeModif.NONE;  //  @jve:decl-index=0:
	private void refreshCategory()
	{
		ArrayList<TupleCategory> categories;
		try
		{
			categories = m_gestionFeedUS.getUserCategories();
			
			Collections.sort(categories, 
					new Comparator<TupleCategory>()
					{
						@Override
						public int compare(TupleCategory o1, TupleCategory o2)
						{
							return o1.name.compareToIgnoreCase(o2.name);
						}
					});

			DefaultListModel model = (DefaultListModel)getJListCategory().getModel();
			model.clear();
			
			for (TupleCategory category : categories)
				model.addElement(new TreeItemCategory(category));
			
			clearCategoryInfos();
			setCategoryTextEnabled(false);
		}
		catch (SQLException e)
		{
			displayError("Error while retrieving categories informations.");
		}
	}

	public void clearCategoryInfos()
	{
		getJTextFieldCategoryName().setText("");
		getJButtonCategoryApply().setEnabled(false);
		getJButtonCategoryRevert().setEnabled(false);
	}
	
	public void setCategoryTextEnabled(boolean p_enabled)
	{
		getJTextFieldCategoryName().setEnabled(p_enabled);
	}
	
	public void displayCategory()
	{
		TreeItemCategory item = (TreeItemCategory)getJListCategory().getSelectedValue();
		
		if (item == null)
			return;
		
		m_categoryModifType = TypeModif.UPDATE;
		clearCategoryInfos();
		getJButtonCategoryApply().setEnabled(true);
		getJButtonCategoryRevert().setEnabled(true);
		setCategoryTextEnabled(true);
		
		TupleCategory category = item.getCategory();
		getJTextFieldCategoryName().setText(category.name);
	}
	
	public void createNewCategory()
	{
		m_categoryModifType = TypeModif.INSERT;
		clearCategoryInfos();
		getJButtonCategoryApply().setEnabled(true);
		setCategoryTextEnabled(true);
		getJTextFieldCategoryName().setText(DEFAULT_CATEGORY_NAME);
		getJListCategory().clearSelection();
	}
	
	public boolean applyCategory()
	{
		//TODO: Validations
		TupleCategory category = new TupleCategory();
		category.idCategory = null;
		category.name = getJTextFieldCategoryName().getText();
		category.createdByUser = true;
		
		if (m_categoryModifType == TypeModif.INSERT)
		{
			try
			{
				m_gestionFeedUS.addCategory(category);
				return true;
			}
			catch (Exception e)
			{
				displayError("Error adding the category: " + e.getMessage());
			}
		}
		else if (m_categoryModifType == TypeModif.UPDATE)
		{
			TreeItemCategory item = (TreeItemCategory)getJListCategory().getSelectedValue();
			category.idCategory = item.getCategory().idCategory;
			try
			{
				m_gestionFeedUS.modifyCategory(category);
				return true;
			}
			catch (Exception e)
			{
				displayError("Error updating the RSS feed: " + e.getMessage());
			}
		}
		
		return false;
	}
	
	public void removeCategory(TupleCategory p_category)
	{
		try
		{
			m_gestionFeedUS.removeCategory(p_category);
		}
		catch (Exception e)
		{
			displayMsg("Error trying to remove this category: '" + p_category.name + "'");
		}
	}
	
	public void removeCategory()
	{
		TreeItemCategory item = (TreeItemCategory)getJListCategory().getSelectedValue();
		
		if (item == null)
			return;

		m_categoryModifType = TypeModif.DELETE;
		removeCategory(item.getCategory());
	}
	
	//Algo Management
	public void clearAlgoInfos()
	{
		getJTextFieldAlgoName().setText("");
		getJButtonAlgoParams().setEnabled(false);
		getJButtonAlgoTrain().setEnabled(false);
	}
	
	public void setAlgoTextEnabled(boolean p_enabled)
	{
		getJTextFieldAlgoName().setEnabled(p_enabled);
		getJCheckBoxIsClustering().setEnabled(p_enabled);
	}
	
	private void refreshAlgos()
	{
		ArrayList<TupleAlgo> algos;
		try
		{
			algos = m_gestionFeedUS.getAlgos();
			
			Collections.sort(algos, 
					new Comparator<TupleAlgo>()
					{
						@Override
						public int compare(TupleAlgo o1, TupleAlgo o2)
						{
							return o1.name.compareToIgnoreCase(o2.name);
						}
					});

			DefaultListModel model = (DefaultListModel)getJListAlgo().getModel();
			model.clear();
			
			for (TupleAlgo algo : algos)
				model.addElement(new TreeItemAlgo(algo));
			
			clearAlgoInfos();
			setAlgoTextEnabled(false);
		}
		catch (SQLException e)
		{
			displayError("Error while retrieving algorithms informations.");
		}
	}
	
	public void displayAlgo()
	{
		TreeItemAlgo item = (TreeItemAlgo)getJListAlgo().getSelectedValue();
		
		if (item == null)
			return;
		
		//m_algoModifType = TypeModif.UPDATE;
		clearAlgoInfos();
		getJButtonAlgoParams().setEnabled(true);
		getJButtonAlgoTrain().setEnabled(true);
		//setAlgoTextEnabled(true);
		
		TupleAlgo algo = item.getAlgo();
		getJTextFieldAlgoName().setText(algo.name);
		getJCheckBoxIsClustering().setSelected(algo.isClustering);
		
		m_idSelectedAlgo = algo.idAlgo;
	}
	
	//Param Management
	private static String DEFAULT_PARAM_NAME = "--New Param--";  //  @jve:decl-index=0:
	private TypeModif m_paramModifType = TypeModif.NONE;  //  @jve:decl-index=0:
	private Long m_idSelectedAlgo = null;  //  @jve:decl-index=0:
	
	private void refreshParams(Long p_idAlgo)
	{
		ArrayList<TupleParam> params;
		try
		{
			params = m_gestionFeedUS.getParams(p_idAlgo);
			
			Collections.sort(params, 
					new Comparator<TupleParam>()
					{
						@Override
						public int compare(TupleParam o1, TupleParam o2)
						{
							return o1.name.compareToIgnoreCase(o2.name);
						}
					});

			DefaultListModel model = (DefaultListModel)getJListParams().getModel();
			model.clear();
			
			for (TupleParam param : params)
				model.addElement(new TreeItemParam(param));
			
			clearParamInfos();
			setParamTextEnabled(false);
		}
		catch (SQLException e)
		{
			displayError("Error while retrieving parameters informations.");
		}
	}
	
	public void clearParamInfos()
	{
		getJTextFieldParamsName().setText("");
		getJTextFieldParamsValue().setText("");
		getJButtonParamsApply().setEnabled(false);
		getJButtonParamsRevert().setEnabled(false);
	}
	
	public void setParamTextEnabled(boolean p_enabled)
	{
		getJTextFieldParamsName().setEnabled(p_enabled);
		getJTextFieldParamsValue().setEnabled(p_enabled);
	}
	
	public void displayParam()
	{
		TreeItemParam item = (TreeItemParam)getJListParams().getSelectedValue();
		
		if (item == null)
			return;
		
		m_paramModifType = TypeModif.UPDATE;
		clearParamInfos();
		getJButtonParamsApply().setEnabled(true);
		getJButtonParamsRevert().setEnabled(true);
		setParamTextEnabled(true);
		
		TupleParam param = item.getParam();
		getJTextFieldParamsName().setText(param.name);
		getJTextFieldParamsValue().setText(param.value);
	}
	
	public void createNewParam()
	{
		m_paramModifType = TypeModif.INSERT;
		clearParamInfos();
		getJButtonParamsApply().setEnabled(true);
		setParamTextEnabled(true);
		getJTextFieldParamsName().setText(DEFAULT_PARAM_NAME);
		getJListParams().clearSelection();
	}
	
	public boolean applyParam(Long p_idAlgo)
	{
		//TODO: Validations
		TupleParam param = new TupleParam();
		param.idParams = null;
		param.idAlgo = p_idAlgo;
		param.name = getJTextFieldParamsName().getText();
		param.value = getJTextFieldParamsValue().getText();
		
		if (m_paramModifType == TypeModif.INSERT)
		{
			try
			{
				m_gestionFeedUS.addParam(param);
				return true;
			}
			catch (Exception e)
			{
				displayError("Error adding the parameter: " + e.getMessage());
			}
		}
		else if (m_paramModifType == TypeModif.UPDATE)
		{
			TreeItemParam item = (TreeItemParam)getJListParams().getSelectedValue();
			param.idParams = item.getParam().idParams;
			try
			{
				m_gestionFeedUS.modifyParam(param);
				return true;
			}
			catch (Exception e)
			{
				displayError("Error updating the parameter: " + e.getMessage());
			}
		}
		
		return false;
	}
		
	public void removeParam()
	{
		TreeItemParam item = (TreeItemParam)getJListParams().getSelectedValue();
		
		if (item == null)
			return;

		m_categoryModifType = TypeModif.DELETE;
		TupleParam param = item.getParam();
		try
		{
			m_gestionFeedUS.removeParam(param);
		}
		catch (Exception e)
		{
			displayMsg("Error trying to remove this parameter: '" + param.name + "'");
		}
	}
	
	//Assign Management
	private void refreshAssignCategories()
	{
		ArrayList<TupleCategory> categories;
		
		try
		{
			categories = m_gestionFeedUS.getUserCategories();
			DefaultComboBoxModel model = (DefaultComboBoxModel)getJComboBoxCategory().getModel();
			model.removeAllElements();
			
			for (TupleCategory category : categories)
				model.addElement(new TreeItemCategory(category));
		}
		catch (SQLException e)
		{
			displayError("Error while retrieving categories: " + e.getMessage());
		}
	}

	private void assign(TupleDocument p_document, TupleCategory p_category) throws Exception
	{
		m_gestionFeedUS.assign(p_document, p_category);
		displayMsg("'" + p_document.title + "' assigned to '" + p_category.name + "'");
		refresh();
	}
	
	private void unassign(TupleDocument p_document) throws Exception
	{
		m_gestionFeedUS.unassign(p_document);
		displayMsg("'" + p_document.title + "' unassigned");
		refresh();
	}
	
	//RSS Management
	private static String DEFAULT_RSS_NAME = "--New RSS--";  //  @jve:decl-index=0:
	private TypeModif m_rssManagerModifType = TypeModif.NONE;  //  @jve:decl-index=0:
	private void refreshRssFeed()
	{
		ArrayList<TupleRssFeed> rssFeeds;
		try
		{
			rssFeeds = m_gestionFeedUS.getRssFeeds();
			
			Collections.sort(rssFeeds, 
					new Comparator<TupleRssFeed>()
					{
						@Override
						public int compare(TupleRssFeed o1, TupleRssFeed o2)
						{
							return o1.name.compareToIgnoreCase(o2.name);
						}
					});

			DefaultListModel model = (DefaultListModel)getJListRSS().getModel();
			model.clear();
			
			for (TupleRssFeed rss : rssFeeds)
				model.addElement(new ListItemRssFeed(rss));
			
			clearRssManagerInfos();
			setRssTextEnabled(false);
		}
		catch (SQLException e)
		{
			displayError("Error while retrieving RSS feeds informations.");
		}
	}

	public void clearRssManagerInfos()
	{
		getJTextFieldRssName().setText("");
		getJTextFieldRssUrl().setText("");
		getJTextFieldRssTagID().setText("");
		getJTextFieldRssTagClass().setText("");
		getJTextFieldRssTagName().setText("");
		getJTextFieldRssTag().setText("");
		getJButtonRssManagerApply().setEnabled(false);
		getJButtonRssManagerRevert().setEnabled(false);
	}
	
	public void setRssTextEnabled(boolean p_enabled)
	{
		getJTextFieldRssName().setEnabled(p_enabled);
		getJTextFieldRssUrl().setEnabled(p_enabled);
		getJTextFieldRssTagID().setEnabled(p_enabled);
		getJTextFieldRssTagClass().setEnabled(p_enabled);
		getJTextFieldRssTagName().setEnabled(p_enabled);
		getJTextFieldRssTag().setEnabled(p_enabled);
	}
	
	public void displayRssFeed()
	{
		ListItemRssFeed item = (ListItemRssFeed)getJListRSS().getSelectedValue();
		
		if (item == null)
			return;
		
		m_rssManagerModifType = TypeModif.UPDATE;
		clearRssManagerInfos();
		getJButtonRssManagerApply().setEnabled(true);
		getJButtonRssManagerRevert().setEnabled(true);
		setRssTextEnabled(true);
		
		TupleRssFeed rss = item.getRSS();
		getJTextFieldRssName().setText(rss.name);
		getJTextFieldRssUrl().setText(rss.url);
		getJTextFieldRssTagID().setText(rss.tagID);
		getJTextFieldRssTagClass().setText(rss.tagClass);
		getJTextFieldRssTagName().setText(rss.tagName);
		getJTextFieldRssTag().setText(rss.tag);
	}
	
	public void createNewRssFeed()
	{
		m_rssManagerModifType = TypeModif.INSERT;
		clearRssManagerInfos();
		getJButtonRssManagerApply().setEnabled(true);
		setRssTextEnabled(true);
		getJTextFieldRssName().setText(DEFAULT_RSS_NAME);
		getJListRSS().clearSelection();
	}
	
	public boolean applyRssFeed()
	{
		//TODO: Validations
		TupleRssFeed rss = new TupleRssFeed();
		rss.idRSS = null;
		rss.name = getJTextFieldRssName().getText();
		rss.url = getJTextFieldRssUrl().getText();
		rss.tagID = getJTextFieldRssTagID().getText();
		rss.tagClass = getJTextFieldRssTagClass().getText();
		rss.tagName = getJTextFieldRssTagName().getText();
		rss.tag = getJTextFieldRssTag().getText();
		
		if (m_rssManagerModifType == TypeModif.INSERT)
		{
			try
			{
				m_gestionFeedUS.addRssFeed(rss);
				return true;
			}
			catch (Exception e)
			{
				displayError("Error adding the RSS feed: " + e.getMessage());
			}
		}
		else if (m_rssManagerModifType == TypeModif.UPDATE)
		{
			ListItemRssFeed item = (ListItemRssFeed)getJListRSS().getSelectedValue();
			rss.idRSS = item.getRSS().idRSS;
			try
			{
				m_gestionFeedUS.modifyRssFeed(rss);
				return true;
			}
			catch (Exception e)
			{
				displayError("Error updating the RSS feed: " + e.getMessage());
			}
		}
		
		return false;
	}
	
	public void deleteRssFeed()
	{
		ListItemRssFeed item = (ListItemRssFeed)getJListRSS().getSelectedValue();
		
		if (item == null)
			return;

		m_rssManagerModifType = TypeModif.DELETE;
		
		try
		{
			m_gestionFeedUS.removeRssFeed(item.getRSS());
		}
		catch (Exception e)
		{
			displayMsg("Error trying to remove this RSS feed: " + item.toString());
		}
	}
	
	
	private void setEnabledFeedUS(boolean p_enabled)
	{
		getJButtonAddCategory().setEnabled(p_enabled);
		getJButtonRemoveCategory().setEnabled(p_enabled);
		
		getJButtonAssign().setEnabled(p_enabled);
		getJButtonUnassign().setEnabled(p_enabled);
		
		getJButtonRefresh().setEnabled(p_enabled);
		getJButtonFetchDocs().setEnabled(p_enabled);
		getJButtonTrain().setEnabled(p_enabled);
		getJButtonCompare().setEnabled(p_enabled);
		getJButtonBrowser().setEnabled(p_enabled);
		
		getJMenuItemAlgoManager().setEnabled(p_enabled);
		getJMenuItemAddCategory().setEnabled(p_enabled);
		getJMenuItemManageCategory().setEnabled(p_enabled);
		getJMenuItemRemoveCategory().setEnabled(p_enabled);
		
		getJMenuItemAssign().setEnabled(p_enabled);
		getJMenuItemUnassign().setEnabled(p_enabled);
	}
	
	//Tab Management
	private int getTabIndex(TupleDocument p_document)
	{
		for (int i= 0; i != getJTabbedPaneDocuments().getTabCount(); ++i)
		{
			Component component = getJTabbedPaneDocuments().getComponentAt(i);
			if (!(component instanceof JScrollPane))
				continue;
			
			JScrollPane scrollPane = (JScrollPane)component;
			if (!(scrollPane.getViewport().getComponent(0) instanceof TextAreaDocument))
				continue;
			
			if (((TextAreaDocument)scrollPane.getViewport().getComponent(0)).getTupleDocument().idDocument == p_document.idDocument)
				return i;
		}
		
		return -1;
	}
	
	private final static int TAB_TITLE_LIMIT = 10;
	private void openTab(TupleDocument p_document)
	{
		int index = getTabIndex(p_document);
		if (index >= 0)
		{
			getJTabbedPaneDocuments().setSelectedIndex(index);
			return;
		}

		String title = p_document.title;
		ImageIcon icon = new ImageIcon(getClass().getResource("/gui/img/icon/rss.png"));
		TextAreaDocument document = new TextAreaDocument(p_document);
		JScrollPane scollPane = new JScrollPane(document);
		
		StringBuilder description = new StringBuilder();
		for (String chunk : p_document.description.split(".{80}"))
			description.append(chunk + "<br>");
		
		if (title.length() > TAB_TITLE_LIMIT)
			title = title.substring(0, TAB_TITLE_LIMIT-3) + "...";

		getJTabbedPaneDocuments().addTab(title, icon, scollPane, description.toString());
		getJTabbedPaneDocuments().setTabComponentAt(getJTabbedPaneDocuments().getTabCount()-1, new ButtonTabComponent(getJTabbedPaneDocuments()));
		getJTabbedPaneDocuments().setSelectedIndex(getJTabbedPaneDocuments().getTabCount()-1);
	}
	
	private void manageDocumentSelection(TreeItemDocument p_documentItem)
	{
		setEnabledFeedUS(true);
		
		getJButtonRemoveCategory().setEnabled(false);
		getJMenuItemRemoveCategory().setEnabled(false);
		
		getJMenuItemAssign().setEnabled(!p_documentItem.isAssignedByUser());
		getJMenuItemUnassign().setEnabled(p_documentItem.isAssignedByUser());
		
		getJButtonAssign().setEnabled(!p_documentItem.isAssignedByUser());
		getJButtonUnassign().setEnabled(p_documentItem.isAssignedByUser());
	}
	
	private void manageCategorySelection(TreeItemCategory p_categoryItem)
	{
		setEnabledFeedUS(true);

		getJButtonAssign().setEnabled(false);
		getJButtonUnassign().setEnabled(false);
		
		getJMenuItemAssign().setEnabled(false);
		getJMenuItemUnassign().setEnabled(false);
		
		getJButtonBrowser().setEnabled(false);
	}
	
	private TupleCategory getSelectedCategory()
	{
		TreePath path = getJTreeDocuments().getSelectionPath();
		
		if (path != null)
		{
			Object obj = path.getLastPathComponent();
			if (!(obj instanceof DefaultMutableTreeNode))
				return null;
				
			DefaultMutableTreeNode node = (DefaultMutableTreeNode)obj;
			if (node.getUserObject() instanceof TreeItemCategory)
				return ((TreeItemCategory)node.getUserObject()).getCategory();
		}

		return null;
	}
	
	private TupleDocument getSelectedDocument()
	{
		TreePath path = getJTreeDocuments().getSelectionPath();
		
		if (path != null)
		{
			Object obj = path.getLastPathComponent();
			if (!(obj instanceof DefaultMutableTreeNode))
				return null;
				
			DefaultMutableTreeNode node = (DefaultMutableTreeNode)obj;
			if (node.getUserObject() instanceof TreeItemDocument)
				return ((TreeItemDocument)node.getUserObject()).getDocument();
		}

		return null;
	}
	
	private TupleDocument getCurrentOpenedDocument()
	{
		Component component = getJTabbedPaneDocuments().getSelectedComponent();
		
		if (!(component instanceof JScrollPane))
			return null;
		
		JScrollPane tab = (JScrollPane)component;
		component = tab.getViewport().getComponent(0);
		
		if (!(component instanceof TextAreaDocument))
			return null;
		
		return ((TextAreaDocument)component).getTupleDocument();
	}
	
	private void displayMsg(String p_msg)
	{
		getJLabelStatusBar().setForeground(Color.BLACK);
		getJLabelStatusBar().setText(p_msg);
		getJFrame().toFront();
	}
	private void displayError(String p_msg)
	{
		getJLabelStatusBar().setForeground(Color.RED);
		getJLabelStatusBar().setText(p_msg);
		getJFrame().toFront();
	}
	private void displayWarning(String p_msg)
	{
		getJLabelStatusBar().setForeground(Color.ORANGE);
		getJLabelStatusBar().setText(p_msg);
		getJFrame().toFront();
	}
	
	private JDialog jDialogRssManager = null;  //  @jve:decl-index=0:visual-constraint="10,401"
	private JPanel jContentPaneRssManager = null;
	private JPanel jPanelRssManagerButtons = null;
	private JSplitPane jSplitPaneRssManager = null;
	private JButton jButtonRssManagerClose = null;
	private JList jListRSS = null;
	private JPanel jPanelRssManagerInfos = null;
	private JPanel jPanelRssInfos = null;
	private JLabel jLabelRssName = null;
	private JLabel jLabelRssUrl = null;
	private JLabel jLabelRssTagID = null;
	private JLabel jLabelRssTagClass = null;
	private JLabel jLabelTagName = null;
	private JLabel jLabelRssTag = null;
	private JTextField jTextFieldRssName = null;
	private JTextField jTextFieldRssUrl = null;
	private JTextField jTextFieldRssTagID = null;
	private JTextField jTextFieldRssTagClass = null;
	private JTextField jTextFieldRssTagName = null;
	private JTextField jTextFieldRssTag = null;
	private JLabel jLabelOptional1 = null;
	private JLabel jLabelOptional2 = null;
	private JLabel jLabelOptional3 = null;
	private JLabel jLabelOptional4 = null;
	private JPanel jPanelRssManagerInfosButtons = null;
	private JButton jButtonRssManagerApply = null;
	private JButton jButtonRssManagerRevert = null;
	private JPanel jPanelListRss = null;
	private JToolBar jToolBarRssManager = null;
	private JButton jButtonRssManagerAdd = null;
	private JButton jButtonRssManagerRemove = null;
	private JSeparator jSeparator5 = null;
	private JButton jButtonBrowser = null;
	private JSeparator jSeparator6 = null;
	private JSeparator jSeparator7 = null;
	private JButton jButtonAssign = null;
	private JButton jButtonUnassign = null;
	private JSeparator jSeparator8 = null;
	private JScrollPane jScrollPaneTreeDocuments = null;
	private JDialog jDialogAssign = null;  //  @jve:decl-index=0:visual-constraint="797,70"
	private JPanel jContentPaneAssign = null;
	private JPanel jPanelAssignButtons = null;
	private JPanel jPanelAssign = null;
	private JLabel jLabelCategory = null;
	private JComboBox jComboBoxCategory = null;
	private JButton jButtonAssignOK = null;
	private JButton jButtonAssignCancel = null;
	private JDialog jDialogCategory = null;  //  @jve:decl-index=0:visual-constraint="636,398"
	private JPanel jContentPaneCategory = null;
	private JPanel jPanelCategoryButtons = null;
	private JButton jButtonCategoryClose = null;
	private JSplitPane jSplitPaneCategory = null;
	private JPanel jPanelListCategories = null;
	private JPanel jPanelInfosCategory = null;
	private JPanel jPanelCategoryInfos = null;
	private JLabel jLabelCategoryName = null;
	private JTextField jTextFieldCategoryName = null;
	private JToolBar jToolBarCategory = null;
	private JButton jButtonCategoryAdd = null;
	private JButton jButtonCategoryRemove = null;
	private JList jListCategory = null;
	private JPanel jPanelCategoryInfosButtons = null;
	private JButton jButtonCategoryApply = null;
	private JButton jButtonCategoryRevert = null;
	private JButton jButtonRefresh = null;
	private JMenuItem jMenuItemRefresh = null;
	private JScrollPane jScrollPaneListCategory = null;
	private JScrollPane jScrollPaneListRSS = null;
	private JMenu jMenuAlgosClassification = null;
	private JMenu jMenuAlgosClustering = null;
	private JRadioButtonMenuItem jRadioButtonMenuItemAlgoBKMean = null;
	private JMenuItem jMenuItemAlgoManager = null;
	private JButton jButtonTrain = null;
	private JRadioButtonMenuItem jRadioButtonMenuItemAlgoRandomForestTree = null;
	private JRadioButtonMenuItem jRadioButtonMenuItemAlgoUser = null;
	private JRadioButtonMenuItem jRadioButtonMenuItemAlgoClusteringNone = null;
	private JDialog jDialogAlgo = null;  //  @jve:decl-index=0:visual-constraint="637,634"
	private JPanel jContentPaneAlgo = null;
	private JPanel jPanelAlgoButtons = null;
	private JButton jButtonAlgoClose = null;
	private JSplitPane jSplitPaneAlgo = null;
	private JPanel jPanelListAlgos = null;
	private JToolBar jToolBarAlgo = null;
	private JButton jButtonAlgoAdd = null;
	private JButton jButtonAlgoRemove = null;
	private JScrollPane jScrollPaneListAlgo = null;
	private JList jListAlgo = null;
	private JPanel jPanelInfosAlgo = null;
	private JPanel jPanelAlgoInfos = null;
	private JLabel jLabelAlgoName = null;
	private JTextField jTextFieldAlgoName = null;
	private JPanel jPanelAlgoInfosButtons = null;
	private JButton jButtonAlgoTrain = null;
	private JLabel jLabelIsClustering = null;
	private JCheckBox jCheckBoxIsClustering = null;
	private JButton JButtonAlgoParams = null;
	private JDialog jDialogParams = null;  //  @jve:decl-index=0:visual-constraint="12,713"
	private JPanel jContentPaneParams = null;
	private JPanel jPanelParamsButtons = null;
	private JButton jButtonParamsClose = null;
	private JSplitPane jSplitPaneParams = null;
	private JPanel jPanelListParams = null;
	private JToolBar jToolBarParams = null;
	private JButton jButtonParamsAdd = null;
	private JButton jButtonParamsRemove = null;
	private JScrollPane jScrollPaneListParams = null;
	private JList jListParams = null;
	private JPanel jPanelInfosParams = null;
	private JPanel jPanelParamsInfos = null;
	private JLabel jLabelParamsName = null;
	private JTextField jTextFieldParamsName = null;
	private JPanel jPanelParamsInfosButtons = null;
	private JButton jButtonParamsApply = null;
	private JButton jButtonParamsRevert = null;
	private JLabel jLabelParamsValue = null;
	private JTextField jTextFieldParamsValue = null;
	/**
	 * This method initializes jFrame
	 * 
	 * @return javax.swing.JFrame
	 */
	private JFrame getJFrame()
	{
		if (jFrame == null)
		{
			jFrame = new JFrame();
			jFrame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			jFrame.setJMenuBar(getJMenuBar());
			jFrame.setSize(564, 382);
			jFrame.setContentPane(getJContentPane());
			jFrame.setTitle("FeedUS");
			jFrame.addWindowListener(new java.awt.event.WindowAdapter()
			{
				public void windowClosed(java.awt.event.WindowEvent e)
				{    
					try
					{
						SaveConfigs();
					}
					catch (Exception e1) { e1.printStackTrace(); }
				}
				
				public void windowOpened(java.awt.event.WindowEvent e)
				{
					try
					{
						LoadConfigs();
					}
					catch (FileNotFoundException e1)
					{
						displayWarning("Unable to open settings file: " + CONFIG_FILE);
					}
					catch (IOException e1)
					{
						displayWarning("Unable to read settings file: " + CONFIG_FILE);
					}
				}
			});
		}
		return jFrame;
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane()
	{
		if (jContentPane == null)
		{
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getJToolBarBar(), BorderLayout.NORTH);
			jContentPane.add(getJLabelStatusBar(), BorderLayout.SOUTH);
			jContentPane.add(getJSplitPane(), BorderLayout.CENTER);
		}
		return jContentPane;
	}
	
	/**
	 * This method initializes jLabelStatusBar	
	 * 	
	 * @return javax.swing.JLabel
	 */
	private JLabel getJLabelStatusBar()
	{
		if (jLabelStatusBar == null)
		{
			jLabelStatusBar = new JLabel();
			jLabelStatusBar.setText("Welcome");
		}
		
		return jLabelStatusBar;
	}

	/**
	 * This method initializes jJMenuBar	
	 * 	
	 * @return javax.swing.JMenuBar	
	 */
	private JMenuBar getJMenuBar()
	{
		if (jJMenuBar == null)
		{
			jJMenuBar = new JMenuBar();
			jJMenuBar.add(getFileMenu());
			jJMenuBar.add(getEditMenu());
			jJMenuBar.add(getJMenuCategory());
			jJMenuBar.add(getJMenuRSS());
			jJMenuBar.add(getJMenuAlgos());
			jJMenuBar.add(getHelpMenu());
		}
		return jJMenuBar;
	}

	/**
	 * This method initializes jMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getFileMenu()
	{
		if (fileMenu == null)
		{
			fileMenu = new JMenu();
			fileMenu.setText("File");
			fileMenu.add(getJMenuItemConnect());
			fileMenu.add(getJSeparator4());
			fileMenu.add(getExitMenuItem());
		}
		return fileMenu;
	}

	/**
	 * This method initializes jMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getEditMenu()
	{
		if (editMenu == null)
		{
			editMenu = new JMenu();
			editMenu.setText("Edit");
			editMenu.setVisible(false);
			editMenu.add(getCutMenuItem());
			editMenu.add(getCopyMenuItem());
			editMenu.add(getPasteMenuItem());
		}
		return editMenu;
	}

	/**
	 * This method initializes jMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getHelpMenu()
	{
		if (helpMenu == null)
		{
			helpMenu = new JMenu();
			helpMenu.setText("Help");
			helpMenu.add(getAboutMenuItem());
		}
		return helpMenu;
	}

	/**
	 * This method initializes jMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getExitMenuItem()
	{
		if (exitMenuItem == null)
		{
			exitMenuItem = new JMenuItem();
			exitMenuItem.setText("Exit");
			exitMenuItem.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					try
					{
						getJFrame().dispose();

						if (m_cnx != null)
							m_cnx.close();
					}
					catch (SQLException e1) { System.exit(1);}
				}
			});
		}
		return exitMenuItem;
	}

	/**
	 * This method initializes jMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getAboutMenuItem()
	{
		if (aboutMenuItem == null)
		{
			aboutMenuItem = new JMenuItem();
			aboutMenuItem.setText("About");
			aboutMenuItem.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					JDialog aboutDialog = getAboutDialog();
					aboutDialog.pack();
					Point loc = getJFrame().getLocation();
					loc.translate(20, 20);
					aboutDialog.setLocation(loc);
					aboutDialog.setVisible(true);
				}
			});
		}
		return aboutMenuItem;
	}

	/**
	 * This method initializes aboutDialog	
	 * 	
	 * @return javax.swing.JDialog
	 */
	private JDialog getAboutDialog()
	{
		if (aboutDialog == null)
		{
			aboutDialog = new JDialog(getJFrame(), true);
			aboutDialog.setTitle("About");
			aboutDialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			aboutDialog.setContentPane(getAboutContentPane());
		}
		return aboutDialog;
	}

	/**
	 * This method initializes aboutContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getAboutContentPane()
	{
		if (aboutContentPane == null)
		{
			aboutContentPane = new JPanel();
			aboutContentPane.setLayout(new BorderLayout());
			aboutContentPane.add(getAboutVersionLabel(), BorderLayout.CENTER);
		}
		return aboutContentPane;
	}

	/**
	 * This method initializes aboutVersionLabel	
	 * 	
	 * @return javax.swing.JLabel	
	 */
	private JLabel getAboutVersionLabel()
	{
		if (aboutVersionLabel == null)
		{
			aboutVersionLabel = new JLabel();
			aboutVersionLabel.setText("Version 1.0");
			aboutVersionLabel.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return aboutVersionLabel;
	}

	/**
	 * This method initializes jMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getCutMenuItem()
	{
		if (cutMenuItem == null)
		{
			cutMenuItem = new JMenuItem();
			cutMenuItem.setText("Cut");
			cutMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,
					Event.CTRL_MASK, true));
		}
		return cutMenuItem;
	}

	/**
	 * This method initializes jMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getCopyMenuItem()
	{
		if (copyMenuItem == null)
		{
			copyMenuItem = new JMenuItem();
			copyMenuItem.setText("Copy");
			copyMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C,
					Event.CTRL_MASK, true));
		}
		return copyMenuItem;
	}

	/**
	 * This method initializes jMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getPasteMenuItem()
	{
		if (pasteMenuItem == null)
		{
			pasteMenuItem = new JMenuItem();
			pasteMenuItem.setText("Paste");
			pasteMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V,
					Event.CTRL_MASK, true));
		}
		return pasteMenuItem;
	}

	/**
	 * This method initializes jMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemConnect()
	{
		if (jMenuItemConnect == null)
		{
			jMenuItemConnect = new JMenuItem();
			jMenuItemConnect.setText("Connect...");
			jMenuItemConnect.setActionCommand("Connect");
			jMenuItemConnect.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					JDialog connectDialog = getJDialogConnect();
					connectDialog.pack();
					Point loc = getJFrame().getLocation();
					loc.translate(20, 20);
					connectDialog.setLocation(loc);
					connectDialog.setVisible(true);
				}
			});
		}
		return jMenuItemConnect;
	}

	/**
	 * This method initializes jTabbedPaneDocuments	
	 * 	
	 * @return javax.swing.JTabbedPane	
	 */
	private JTabbedPane getJTabbedPaneDocuments()
	{
		if (jTabbedPaneDocuments == null)
		{
			jTabbedPaneDocuments = new JTabbedPane();
			jTabbedPaneDocuments.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
			jTabbedPaneDocuments.addTab("Viewer", new ImageIcon(getClass().getResource("/gui/img/icon/rss.png")), getJTextPaneViewer());
			jTabbedPaneDocuments.setTabComponentAt(0, new ButtonTabComponent(jTabbedPaneDocuments));
		}
		return jTabbedPaneDocuments;
	}

	/**
	 * This method initializes jTreeDocuments	
	 * 	
	 * @return javax.swing.JTree	
	 */
	private JTree getJTreeDocuments()
	{
		if (jTreeDocuments == null)
		{
			DefaultTreeSelectionModel defaultTreeSelectionModel = new DefaultTreeSelectionModel();
			defaultTreeSelectionModel.setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
			jTreeDocuments = new JTree((TreeNode)null);
			jTreeDocuments.setRootVisible(false);
			jTreeDocuments.setLargeModel(false);
			jTreeDocuments.setEditable(false);
			jTreeDocuments.setRowHeight(0);
			jTreeDocuments.setVisibleRowCount(10);
			jTreeDocuments.setSelectionModel(defaultTreeSelectionModel);
			jTreeDocuments.setCellRenderer(new TreeDocumentRenderer());
			jTreeDocuments.addTreeSelectionListener(new javax.swing.event.TreeSelectionListener()
			{
				public void valueChanged(javax.swing.event.TreeSelectionEvent e)
				{
					Object obj = e.getPath().getLastPathComponent();
					
					if (!(obj instanceof DefaultMutableTreeNode))
						return;
					
					DefaultMutableTreeNode node = (DefaultMutableTreeNode)obj;
					
					if (node.getUserObject() instanceof TreeItemDocument)
					{
						//openTab(((TreeItemDocument)node.getUserObject()).getDocument());
						manageDocumentSelection((TreeItemDocument)node.getUserObject());
					}
					else if (node.getUserObject() instanceof TreeItemCategory)
					{
						manageCategorySelection((TreeItemCategory)node.getUserObject());
					}
				}
			});
			jTreeDocuments.addMouseListener(new java.awt.event.MouseListener()
			{
				public void mouseClicked(java.awt.event.MouseEvent e)
				{
					if (e.getClickCount() == 2)
					{
						TupleDocument document = getSelectedDocument();
						if (document != null)
							openTab(document);
					}
				}
				public void mousePressed(java.awt.event.MouseEvent e)
				{}
				public void mouseReleased(java.awt.event.MouseEvent e)
				{}
				public void mouseEntered(java.awt.event.MouseEvent e)
				{}
				public void mouseExited(java.awt.event.MouseEvent e)
				{}
			});
		}
		return jTreeDocuments;
	}

	/**
	 * This method initializes jMenuAlgos	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJMenuAlgos()
	{
		if (jMenuAlgos == null)
		{
			jMenuAlgos = new JMenu();
			jMenuAlgos.setText("Algos");
			jMenuAlgos.setEnabled(false);
			jMenuAlgos.add(getJMenuItemAlgoManager());
			jMenuAlgos.add(getJMenuItemCompare());
			jMenuAlgos.add(getJSeparator3());
			jMenuAlgos.add(getJMenuAlgosClassification());
			jMenuAlgos.add(getJMenuAlgosClustering());
		}
		return jMenuAlgos;
	}

	/**
	 * This method initializes jMenuRSS	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJMenuRSS()
	{
		if (jMenuRSS == null)
		{
			jMenuRSS = new JMenu();
			jMenuRSS.setText("RSS");
			jMenuRSS.setEnabled(false);
			jMenuRSS.add(getJMenuItemRefresh());
			jMenuRSS.add(getJMenuItemFetch());
			jMenuRSS.add(getJSeparator2());
			jMenuRSS.add(getJMenuItemManageRSS());
		}
		return jMenuRSS;
	}

	/**
	 * This method initializes jMenuCategory	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJMenuCategory()
	{
		if (jMenuCategory == null)
		{
			jSeparator1 = new JSeparator();
			jMenuCategory = new JMenu();
			jMenuCategory.setText("Category");
			jMenuCategory.setEnabled(false);
			jMenuCategory.add(getJMenuItemAssign());
			jMenuCategory.add(getJMenuItemUnassign());
			jMenuCategory.add(jSeparator1);
			jMenuCategory.add(getJMenuItemAddCategory());
			jMenuCategory.add(getJMenuItemRemoveCategory());
			jMenuCategory.add(getJMenuItemManageCategory());
		}
		return jMenuCategory;
	}

	/**
	 * This method initializes jJToolBarBar	
	 * 	
	 * @return javax.swing.JToolBar	
	 */
	private JToolBar getJToolBarBar()
	{
		if (jJToolBarBar == null)
		{
			jJToolBarBar = new JToolBar();
			jJToolBarBar.setFloatable(false);
			jJToolBarBar.setPreferredSize(new Dimension(48, 30));
			jJToolBarBar.setUI(new BasicToolBarUI());
			jJToolBarBar.setEnabled(true);
			jJToolBarBar.add(getJButtonRefresh());
			jJToolBarBar.add(getJButtonFetchDocs());
			jJToolBarBar.add(getJButtonTrain());
			jJToolBarBar.add(getJSeparator8());
			jJToolBarBar.add(getJButtonAssign());
			jJToolBarBar.add(getJButtonUnassign());
			jJToolBarBar.add(getJSeparator6());
			jJToolBarBar.add(getJButtonAddCategory());
			jJToolBarBar.add(getJButtonRemoveCategory());
			jJToolBarBar.add(getJSeparator7());
			jJToolBarBar.add(getJButtonCompare());
			jJToolBarBar.add(getJSeparator5());
			jJToolBarBar.add(getJButtonBrowser());
		}
		return jJToolBarBar;
	}

	/**
	 * This method initializes jButtonAddCategory	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonAddCategory()
	{
		if (jButtonAddCategory == null)
		{
			jButtonAddCategory = new JButton();
			jButtonAddCategory.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/add.png")));
			jButtonAddCategory.setMargin(new Insets(2, 2, 2, 2));
			jButtonAddCategory.setMaximumSize(null);
			jButtonAddCategory.setMinimumSize(new Dimension(28, 28));
			jButtonAddCategory.setVerticalAlignment(SwingConstants.CENTER);
			jButtonAddCategory.setEnabled(false);
			jButtonAddCategory.setHorizontalTextPosition(SwingConstants.TRAILING);
			jButtonAddCategory.setHorizontalAlignment(SwingConstants.LEADING);
			jButtonAddCategory.setSize(new Dimension(26, 26));
			jButtonAddCategory.setLocation(new Point(2, 1));
			jButtonAddCategory.setAlignmentY(0.5F);
			jButtonAddCategory.setBorderPainted(false);
			jButtonAddCategory.setToolTipText("Add new category");
			jButtonAddCategory.setPreferredSize(new Dimension(26, 26));
			jButtonAddCategory.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					getJDialogCategory().setVisible(true);
					getJButtonCategoryAdd().doClick();
				}
			});
		}
		return jButtonAddCategory;
	}

	/**
	 * This method initializes jButtonRemoveCategory	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonRemoveCategory()
	{
		if (jButtonRemoveCategory == null)
		{
			jButtonRemoveCategory = new JButton();
			jButtonRemoveCategory.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/delete.png")));
			jButtonRemoveCategory.setMaximumSize(new Dimension(28, 28));
			jButtonRemoveCategory.setMargin(new Insets(0, 0, 0, 0));
			jButtonRemoveCategory.setSize(new Dimension(28, 28));
			jButtonRemoveCategory.setPreferredSize(new Dimension(28, 28));
			jButtonRemoveCategory.setLocation(new Point(30, 1));
			jButtonRemoveCategory.setBorder(BorderFactory.createCompoundBorder(null, null));
			jButtonRemoveCategory.setAlignmentY(0.5F);
			jButtonRemoveCategory.setBorderPainted(false);
			jButtonRemoveCategory.setEnabled(false);
			jButtonRemoveCategory.setToolTipText("Remove category");
			jButtonRemoveCategory.setMinimumSize(new Dimension(28, 28));
			jButtonRemoveCategory.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					TupleCategory category =  getSelectedCategory();
					
					if (category == null)
						return;
					
					removeCategory(category);
					refresh();
				}
			});
		}
		return jButtonRemoveCategory;
	}

	/**
	 * This method initializes jButtonFetchDocs	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonFetchDocs()
	{
		if (jButtonFetchDocs == null)
		{
			jButtonFetchDocs = new JButton();
			jButtonFetchDocs.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/fetch.png")));
			jButtonFetchDocs.setBorderPainted(false);
			jButtonFetchDocs.setEnabled(false);
			jButtonFetchDocs.setToolTipText("Fetch new articles from Internet");
			jButtonFetchDocs.setMargin(new Insets(2, 2, 2, 2));
			jButtonFetchDocs.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					fetch();
				}
			});
		}
		return jButtonFetchDocs;
	}

	/**
	 * This method initializes jMenuItemAddCategory	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemAddCategory()
	{
		if (jMenuItemAddCategory == null)
		{
			jMenuItemAddCategory = new JMenuItem();
			jMenuItemAddCategory.setText("Add Category...");
			jMenuItemAddCategory.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/add.png")));
			jMenuItemAddCategory.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					getJDialogCategory().setVisible(true);
					getJButtonCategoryAdd().doClick();
				}
			});
		}
		return jMenuItemAddCategory;
	}

	/**
	 * This method initializes jMenuItemRemoveCategory	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemRemoveCategory()
	{
		if (jMenuItemRemoveCategory == null)
		{
			jMenuItemRemoveCategory = new JMenuItem();
			jMenuItemRemoveCategory.setText("Remove Category");
			jMenuItemRemoveCategory.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/delete.png")));
			jMenuItemRemoveCategory.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					TupleCategory category = getSelectedCategory();

					if (category == null)
						return;

					removeCategory(category);
					refresh();
				}
			});
		}
		return jMenuItemRemoveCategory;
	}

	/**
	 * This method initializes jMenuItemAssign	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemAssign()
	{
		if (jMenuItemAssign == null)
		{
			jMenuItemAssign = new JMenuItem();
			jMenuItemAssign.setText("Assign to...");
			jMenuItemAssign.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/assign.png")));
			jMenuItemAssign.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					getJDialogAssign().setVisible(true);
				}
			});
		}
		return jMenuItemAssign;
	}

	/**
	 * This method initializes jMenuItemUnassign	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemUnassign()
	{
		if (jMenuItemUnassign == null)
		{
			jMenuItemUnassign = new JMenuItem();
			jMenuItemUnassign.setText("Unassign");
			jMenuItemUnassign.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/unassign.png")));
			jMenuItemUnassign.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					TupleDocument document = getSelectedDocument();
					
					if (document == null)
						return;
					
					try
					{
						unassign(document);
					}
					catch (Exception e1)
					{
						displayError("Error while unassigning '" + document.title + "'");
					}
				}
			});
		}
		return jMenuItemUnassign;
	}

	/**
	 * This method initializes jMenuItemManageCategory	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemManageCategory()
	{
		if (jMenuItemManageCategory == null)
		{
			jMenuItemManageCategory = new JMenuItem();
			jMenuItemManageCategory.setText("Manage Category...");
			jMenuItemManageCategory.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					getJDialogCategory().setVisible(true);
				}
			});
		}
		return jMenuItemManageCategory;
	}

	/**
	 * This method initializes jSplitPane	
	 * 	
	 * @return javax.swing.JSplitPane	
	 */
	private JSplitPane getJSplitPane()
	{
		if (jSplitPane == null)
		{
			jSplitPane = new JSplitPane();
			jSplitPane.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
			jSplitPane.setRightComponent(getJTabbedPaneDocuments());
			jSplitPane.setLeftComponent(getJScrollPaneTreeDocuments());
			jSplitPane.setOneTouchExpandable(true);
		}
		return jSplitPane;
	}

	/**
	 * This method initializes jMenuItemManageRSS	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemManageRSS()
	{
		if (jMenuItemManageRSS == null)
		{
			jMenuItemManageRSS = new JMenuItem();
			jMenuItemManageRSS.setText("Manage RSS...");
			jMenuItemManageRSS.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					getJDialogRssManager().setVisible(true);
				}
			});
		}
		return jMenuItemManageRSS;
	}

	/**
	 * This method initializes jMenuItemFetch	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemFetch()
	{
		if (jMenuItemFetch == null)
		{
			jMenuItemFetch = new JMenuItem();
			jMenuItemFetch.setText("Fetch");
			jMenuItemFetch.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/fetch.png")));
			jMenuItemFetch.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					fetch();
				}
			});
		}
		return jMenuItemFetch;
	}

	/**
	 * This method initializes jSeparator2	
	 * 	
	 * @return javax.swing.JSeparator	
	 */
	private JSeparator getJSeparator2()
	{
		if (jSeparator2 == null)
		{
			jSeparator2 = new JSeparator();
		}
		return jSeparator2;
	}

	/**
	 * This method initializes jMenuItemCompare	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemCompare()
	{
		if (jMenuItemCompare == null)
		{
			jMenuItemCompare = new JMenuItem();
			jMenuItemCompare.setText("Compare...");
			jMenuItemCompare.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/compare.png")));
			jMenuItemCompare.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					compare();
				}
			});
		}
		return jMenuItemCompare;
	}

	/**
	 * This method initializes jSeparator3	
	 * 	
	 * @return javax.swing.JSeparator	
	 */
	private JSeparator getJSeparator3()
	{
		if (jSeparator3 == null)
		{
			jSeparator3 = new JSeparator();
		}
		return jSeparator3;
	}

	/**
	 * This method initializes jRadioButtonMenuItemAlgoSVM	
	 * 	
	 * @return javax.swing.JRadioButtonMenuItem	
	 */
	private JRadioButtonMenuItem getJRadioButtonMenuItemAlgoSVM()
	{
		if (jRadioButtonMenuItemAlgoSVM == null)
		{
			jRadioButtonMenuItemAlgoSVM = new JRadioButtonMenuItem();
			jRadioButtonMenuItemAlgoSVM.setText("SVM");
			jRadioButtonMenuItemAlgoSVM.addItemListener(new java.awt.event.ItemListener()
			{
				public void itemStateChanged(java.awt.event.ItemEvent e)
				{
					displayMsg("Classfication algorithm changed to: SVM");
					m_classificationAlgo = TypeAlgo.SVM;
				}
			});
			buttonGroupAlgoClassification.add(jRadioButtonMenuItemAlgoSVM);
		}
		return jRadioButtonMenuItemAlgoSVM;
	}

	/**
	 * This method initializes jRadioButtonMenuItemAlgoRocchio	
	 * 	
	 * @return javax.swing.JRadioButtonMenuItem	
	 */
	private JRadioButtonMenuItem getJRadioButtonMenuItemAlgoRocchio()
	{
		if (jRadioButtonMenuItemAlgoRocchio == null)
		{
			jRadioButtonMenuItemAlgoRocchio = new JRadioButtonMenuItem();
			jRadioButtonMenuItemAlgoRocchio.setText("Rocchio");
			jRadioButtonMenuItemAlgoRocchio.addItemListener(new java.awt.event.ItemListener()
			{
				public void itemStateChanged(java.awt.event.ItemEvent e)
				{
					displayMsg("Classfication algorithm changed to: Rocchio");
					m_classificationAlgo = TypeAlgo.ROCCHIO;
				}
			});
			buttonGroupAlgoClassification.add(jRadioButtonMenuItemAlgoRocchio);
		}
		return jRadioButtonMenuItemAlgoRocchio;
	}

	/**
	 * This method initializes jButtonCompare	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCompare()
	{
		if (jButtonCompare == null)
		{
			jButtonCompare = new JButton();
			jButtonCompare.setMargin(new Insets(2, 2, 2, 2));
			jButtonCompare.setBorderPainted(false);
			jButtonCompare.setEnabled(false);
			jButtonCompare.setToolTipText("Compare");
			jButtonCompare.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/compare.png")));
			jButtonCompare.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					compare();
				}
			});
		}
		return jButtonCompare;
	}

	/**
	 * This method initializes jTextPaneViewer	
	 * 	
	 * @return javax.swing.JTextPane	
	 */
	private JTextPane getJTextPaneViewer()
	{
		if (jTextPaneViewer == null)
		{
			jTextPaneViewer = new JTextPane();
		}
		return jTextPaneViewer;
	}

	/**
	 * This method initializes jSeparator4	
	 * 	
	 * @return javax.swing.JSeparator	
	 */
	private JSeparator getJSeparator4()
	{
		if (jSeparator4 == null)
		{
			jSeparator4 = new JSeparator();
		}
		return jSeparator4;
	}

	/**
	 * This method initializes jDialogConnect	
	 * 	
	 * @return javax.swing.JDialog	
	 */
	private JDialog getJDialogConnect()
	{
		if (jDialogConnect == null)
		{
			jDialogConnect = new JDialog(getJFrame());
			jDialogConnect.getRootPane().setDefaultButton(getJButtonConnectOK());
			jDialogConnect.setSize(new Dimension(200, 250));
			jDialogConnect.setResizable(false);
			jDialogConnect.setTitle("Connect");
			jDialogConnect.setModal(true);
			jDialogConnect.setLocationRelativeTo(getJFrame());
			jDialogConnect.setMinimumSize(new Dimension(200, 250));
			jDialogConnect.setMaximumSize(new Dimension(200, 250));
			jDialogConnect.setPreferredSize(new Dimension(200, 250));
			jDialogConnect.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			jDialogConnect.setContentPane(getJContentPaneConnect());
			jDialogConnect.addWindowListener(new java.awt.event.WindowAdapter()
			{   
				public void windowActivated(java.awt.event.WindowEvent e)
				{
					getJFrame().toFront();
				}
				public void windowOpened(java.awt.event.WindowEvent e)
				{
					getJTextFieldConnectServerHost().setText(m_configs.getProperty("host", "feedus.servebeer.com"));
					getJTextFieldConnectServerPort().setText(m_configs.getProperty("port", "4242"));
					getJTextFieldConnectServerDB().setText(m_configs.getProperty("dbName", "feedus_ift603"));
					getJTextFieldConnectUserName().setText(m_configs.getProperty("user", "feedus"));
					getJPasswordFieldConnectUserPassword().setText(m_configs.getProperty("password", ""));
				}
			});
		}
		return jDialogConnect;
	}

	/**
	 * This method initializes jContentPaneConnect	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJContentPaneConnect()
	{
		if (jContentPaneConnect == null)
		{
			jContentPaneConnect = new JPanel();
			jContentPaneConnect.setLayout(new BorderLayout());
			jContentPaneConnect.add(getJPanelConnectServer(), BorderLayout.NORTH);
			jContentPaneConnect.add(getJPanelConnectUser(), BorderLayout.CENTER);
			jContentPaneConnect.add(getJPanelConnectButtons(), BorderLayout.SOUTH);
		}
		return jContentPaneConnect;
	}

	/**
	 * This method initializes jPanelConnectServer	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelConnectServer()
	{
		if (jPanelConnectServer == null)
		{
			GridBagConstraints gridBagConstraints5 = new GridBagConstraints();
			gridBagConstraints5.fill = GridBagConstraints.BOTH;
			gridBagConstraints5.gridy = 2;
			gridBagConstraints5.weightx = 1.0;
			gridBagConstraints5.insets = new Insets(0, 10, 5, 10);
			gridBagConstraints5.gridx = 1;
			GridBagConstraints gridBagConstraints4 = new GridBagConstraints();
			gridBagConstraints4.fill = GridBagConstraints.BOTH;
			gridBagConstraints4.gridy = 1;
			gridBagConstraints4.weightx = 1.0;
			gridBagConstraints4.insets = new Insets(0, 10, 5, 10);
			gridBagConstraints4.gridx = 1;
			GridBagConstraints gridBagConstraints3 = new GridBagConstraints();
			gridBagConstraints3.fill = GridBagConstraints.BOTH;
			gridBagConstraints3.gridy = 0;
			gridBagConstraints3.weightx = 1.0;
			gridBagConstraints3.ipadx = 0;
			gridBagConstraints3.insets = new Insets(0, 10, 5, 10);
			gridBagConstraints3.gridx = 1;
			GridBagConstraints gridBagConstraints2 = new GridBagConstraints();
			gridBagConstraints2.gridx = 0;
			gridBagConstraints2.insets = new Insets(0, 5, 5, 0);
			gridBagConstraints2.anchor = GridBagConstraints.WEST;
			gridBagConstraints2.gridy = 1;
			jLabelConnectServerPort = new JLabel();
			jLabelConnectServerPort.setText("Port:");
			GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
			gridBagConstraints1.gridx = 0;
			gridBagConstraints1.insets = new Insets(0, 5, 5, 0);
			gridBagConstraints1.anchor = GridBagConstraints.WEST;
			gridBagConstraints1.gridy = 2;
			jLabelConnectServerDB = new JLabel();
			jLabelConnectServerDB.setText("DB:");
			GridBagConstraints gridBagConstraints = new GridBagConstraints();
			gridBagConstraints.gridx = 0;
			gridBagConstraints.insets = new Insets(0, 5, 5, 0);
			gridBagConstraints.anchor = GridBagConstraints.WEST;
			gridBagConstraints.gridy = 0;
			jLabelConnectServerHost = new JLabel();
			jLabelConnectServerHost.setText("Host:");
			jPanelConnectServer = new JPanel();
			jPanelConnectServer.setLayout(new GridBagLayout());
			jPanelConnectServer.setBorder(BorderFactory.createTitledBorder(null, "Server", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			jPanelConnectServer.add(jLabelConnectServerHost, gridBagConstraints);
			jPanelConnectServer.add(jLabelConnectServerDB, gridBagConstraints1);
			jPanelConnectServer.add(jLabelConnectServerPort, gridBagConstraints2);
			jPanelConnectServer.add(getJTextFieldConnectServerHost(), gridBagConstraints3);
			jPanelConnectServer.add(getJTextFieldConnectServerPort(), gridBagConstraints4);
			jPanelConnectServer.add(getJTextFieldConnectServerDB(), gridBagConstraints5);
		}
		return jPanelConnectServer;
	}

	/**
	 * This method initializes jPanelConnectUser	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelConnectUser()
	{
		if (jPanelConnectUser == null)
		{
			GridBagConstraints gridBagConstraints9 = new GridBagConstraints();
			gridBagConstraints9.fill = GridBagConstraints.BOTH;
			gridBagConstraints9.gridy = 1;
			gridBagConstraints9.weightx = 1.0;
			gridBagConstraints9.insets = new Insets(0, 10, 5, 10);
			gridBagConstraints9.gridx = 1;
			GridBagConstraints gridBagConstraints8 = new GridBagConstraints();
			gridBagConstraints8.fill = GridBagConstraints.BOTH;
			gridBagConstraints8.gridy = 0;
			gridBagConstraints8.weightx = 1.0;
			gridBagConstraints8.insets = new Insets(0, 10, 5, 10);
			gridBagConstraints8.gridx = 1;
			GridBagConstraints gridBagConstraints7 = new GridBagConstraints();
			gridBagConstraints7.gridx = 0;
			gridBagConstraints7.insets = new Insets(0, 5, 5, 0);
			gridBagConstraints7.anchor = GridBagConstraints.WEST;
			gridBagConstraints7.gridy = 1;
			jLabelConnectUserPassword = new JLabel();
			jLabelConnectUserPassword.setText("Password:");
			GridBagConstraints gridBagConstraints6 = new GridBagConstraints();
			gridBagConstraints6.gridx = 0;
			gridBagConstraints6.insets = new Insets(0, 5, 5, 0);
			gridBagConstraints6.anchor = GridBagConstraints.WEST;
			gridBagConstraints6.gridy = 0;
			jLabelConnectUserName = new JLabel();
			jLabelConnectUserName.setText("User:");
			jPanelConnectUser = new JPanel();
			jPanelConnectUser.setLayout(new GridBagLayout());
			jPanelConnectUser.setBorder(BorderFactory.createTitledBorder(null, "User", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			jPanelConnectUser.add(jLabelConnectUserName, gridBagConstraints6);
			jPanelConnectUser.add(jLabelConnectUserPassword, gridBagConstraints7);
			jPanelConnectUser.add(getJTextFieldConnectUserName(), gridBagConstraints8);
			jPanelConnectUser.add(getJPasswordFieldConnectUserPassword(), gridBagConstraints9);
		}
		return jPanelConnectUser;
	}

	/**
	 * This method initializes jPanelConnectButtons	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelConnectButtons()
	{
		if (jPanelConnectButtons == null)
		{
			FlowLayout flowLayout = new FlowLayout();
			flowLayout.setAlignment(FlowLayout.RIGHT);
			jPanelConnectButtons = new JPanel();
			jPanelConnectButtons.setLayout(flowLayout);
			jPanelConnectButtons.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			jPanelConnectButtons.add(getJButtonConnectOK(), null);
			jPanelConnectButtons.add(getJButtonConnectCancel(), null);
		}
		return jPanelConnectButtons;
	}

	/**
	 * This method initializes jButtonConnectOK	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonConnectOK()
	{
		if (jButtonConnectOK == null)
		{
			jButtonConnectOK = new JButton();
			jButtonConnectOK.setText("OK");
			jButtonConnectOK.setMinimumSize(new Dimension(73, 26));
			jButtonConnectOK.setPreferredSize(new Dimension(65, 20));
			jButtonConnectOK.setMaximumSize(new Dimension(73, 26));
			jButtonConnectOK.addActionListener(new java.awt.event.ActionListener()
			{
				@SuppressWarnings("deprecation")
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					String host = getJTextFieldConnectServerHost().getText();
					String port = getJTextFieldConnectServerPort().getText();
					String dbName = getJTextFieldConnectServerDB().getText();
					String user = getJTextFieldConnectUserName().getText();
					String password = getJPasswordFieldConnectUserPassword().getText();
					
					try
					{
						//Try to establish connection.
						connect(host, port , dbName, user, password);
						displayMsg("Connected to " + host + ":" + port + "/" + dbName + " as " + user);
						
						//Save used settings.
						m_configs.setProperty("host", getJTextFieldConnectServerHost().getText());
						m_configs.setProperty("port", getJTextFieldConnectServerPort().getText());
						m_configs.setProperty("dbName", getJTextFieldConnectServerDB().getText());
						m_configs.setProperty("user", getJTextFieldConnectUserName().getText());
						m_configs.setProperty("password", getJPasswordFieldConnectUserPassword().getText());
						
						getJDialogConnect().dispose();
					}
					catch (SQLException e1)
					{
						displayError("Failed to connect! (" + host + ":" + port + "/" + dbName + " as " + user + ")");
					}
				}
			});
		}
		return jButtonConnectOK;
	}

	/**
	 * This method initializes jButtonConnectCancel	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonConnectCancel()
	{
		if (jButtonConnectCancel == null)
		{
			jButtonConnectCancel = new JButton();
			jButtonConnectCancel.setText("Cancel");
			jButtonConnectCancel.setMinimumSize(new Dimension(73, 26));
			jButtonConnectCancel.setMargin(new Insets(2, 10, 2, 10));
			jButtonConnectCancel.setPreferredSize(new Dimension(65, 20));
			jButtonConnectCancel.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					getJDialogConnect().dispose();
				}
			});
		}
		return jButtonConnectCancel;
	}

	/**
	 * This method initializes jTextFieldConnectServerHost	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldConnectServerHost()
	{
		if (jTextFieldConnectServerHost == null)
		{
			jTextFieldConnectServerHost = new JTextField();
		}
		return jTextFieldConnectServerHost;
	}

	/**
	 * This method initializes jTextFieldConnectServerPort	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldConnectServerPort()
	{
		if (jTextFieldConnectServerPort == null)
		{
			jTextFieldConnectServerPort = new JTextField();
		}
		return jTextFieldConnectServerPort;
	}

	/**
	 * This method initializes jTextFieldConnectServerDB	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldConnectServerDB()
	{
		if (jTextFieldConnectServerDB == null)
		{
			jTextFieldConnectServerDB = new JTextField();
		}
		return jTextFieldConnectServerDB;
	}

	/**
	 * This method initializes jTextFieldConnectUserName	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldConnectUserName()
	{
		if (jTextFieldConnectUserName == null)
		{
			jTextFieldConnectUserName = new JTextField();
		}
		return jTextFieldConnectUserName;
	}

	/**
	 * This method initializes jPasswordFieldConnectUserPassword	
	 * 	
	 * @return javax.swing.JPasswordField	
	 */
	private JPasswordField getJPasswordFieldConnectUserPassword()
	{
		if (jPasswordFieldConnectUserPassword == null)
		{
			jPasswordFieldConnectUserPassword = new JPasswordField();
		}
		return jPasswordFieldConnectUserPassword;
	}

	/**
	 * This method initializes jFrameRssManager	
	 * 	
	 * @return javax.swing.JFrame	
	 */
	private JDialog getJDialogRssManager()
	{
		if (jDialogRssManager == null)
		{
			jDialogRssManager = new JDialog();
			jDialogRssManager.getRootPane().setDefaultButton(getJButtonRssManagerClose());
			jDialogRssManager.setSize(new Dimension(615, 305));
			jDialogRssManager.setTitle("Manage RSS");
			jDialogRssManager.setModal(true);
			jDialogRssManager.setLocationRelativeTo(getJFrame());
			jDialogRssManager.setResizable(true);
			jDialogRssManager.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			jDialogRssManager.setContentPane(getJContentPaneRssManager());
			jDialogRssManager.addWindowListener(new java.awt.event.WindowAdapter()
			{   
				public void windowActivated(java.awt.event.WindowEvent e)
				{
					getJFrame().toFront();
				}
				public void windowOpened(java.awt.event.WindowEvent e)
				{
					refreshRssFeed();
				}
			});
		}
		return jDialogRssManager;
	}
	/**
	 * This method initializes jContentPaneRssManager	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJContentPaneRssManager()
	{
		if (jContentPaneRssManager == null)
		{
			jContentPaneRssManager = new JPanel();
			jContentPaneRssManager.setLayout(new BorderLayout());
			jContentPaneRssManager.add(getJPanelRssManagerButtons(), BorderLayout.SOUTH);
			jContentPaneRssManager.add(getJSplitPaneRssManager(), BorderLayout.CENTER);
		}
		return jContentPaneRssManager;
	}
	/**
	 * This method initializes jPanelRssManagerButtons	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelRssManagerButtons()
	{
		if (jPanelRssManagerButtons == null)
		{
			FlowLayout flowLayout1 = new FlowLayout();
			flowLayout1.setAlignment(FlowLayout.RIGHT);
			jPanelRssManagerButtons = new JPanel();
			jPanelRssManagerButtons.setLayout(flowLayout1);
			jPanelRssManagerButtons.add(getJButtonRssManagerClose(), null);
		}
		return jPanelRssManagerButtons;
	}
	/**
	 * This method initializes jSplitPaneRssManager	
	 * 	
	 * @return javax.swing.JSplitPane	
	 */
	private JSplitPane getJSplitPaneRssManager()
	{
		if (jSplitPaneRssManager == null)
		{
			jSplitPaneRssManager = new JSplitPane();
			jSplitPaneRssManager.setRightComponent(getJPanelRssManagerInfos());
			jSplitPaneRssManager.setLeftComponent(getJPanelListRss());
		}
		return jSplitPaneRssManager;
	}
	/**
	 * This method initializes jButtonRssManagerClose	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonRssManagerClose()
	{
		if (jButtonRssManagerClose == null)
		{
			jButtonRssManagerClose = new JButton();
			jButtonRssManagerClose.setText("Close");
			jButtonRssManagerClose.setMargin(new Insets(2, 10, 2, 10));
			jButtonRssManagerClose.setPreferredSize(new Dimension(65, 20));
			jButtonRssManagerClose.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					getJDialogRssManager().dispose();
				}
			});
		}
		return jButtonRssManagerClose;
	}
	/**
	 * This method initializes jListRSS	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListRSS()
	{
		if (jListRSS == null)
		{
			jListRSS = new JList();
			jListRSS.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			jListRSS.setModel(new DefaultListModel());
			jListRSS.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));
			jListRSS.addListSelectionListener(new javax.swing.event.ListSelectionListener()
			{
				public void valueChanged(javax.swing.event.ListSelectionEvent e)
				{
					displayRssFeed();
				}
			});
		}
		return jListRSS;
	}
	/**
	 * This method initializes jPanelRssManagerInfos	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelRssManagerInfos()
	{
		if (jPanelRssManagerInfos == null)
		{
			BorderLayout borderLayout = new BorderLayout();
			borderLayout.setVgap(0);
			borderLayout.setHgap(0);
			jPanelRssManagerInfos = new JPanel();
			jPanelRssManagerInfos.setBorder(BorderFactory.createTitledBorder(null, "", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			jPanelRssManagerInfos.setLayout(borderLayout);
			jPanelRssManagerInfos.add(getJPanelRssInfos(), BorderLayout.CENTER);
			jPanelRssManagerInfos.add(getJPanelRssManagerInfosButtons(), BorderLayout.SOUTH);
		}
		return jPanelRssManagerInfos;
	}
	/**
	 * This method initializes jPanelRssInfos	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelRssInfos()
	{
		if (jPanelRssInfos == null)
		{
			GridBagConstraints gridBagConstraints25 = new GridBagConstraints();
			gridBagConstraints25.insets = new Insets(0, 0, 5, 2);
			gridBagConstraints25.gridy = 5;
			gridBagConstraints25.gridx = 2;
			jLabelOptional4 = new JLabel();
			jLabelOptional4.setText("(Optional)");
			GridBagConstraints gridBagConstraints24 = new GridBagConstraints();
			gridBagConstraints24.insets = new Insets(0, 0, 5, 2);
			gridBagConstraints24.gridy = 4;
			gridBagConstraints24.gridx = 2;
			jLabelOptional3 = new JLabel();
			jLabelOptional3.setText("(Optional)");
			GridBagConstraints gridBagConstraints23 = new GridBagConstraints();
			gridBagConstraints23.insets = new Insets(0, 0, 5, 2);
			gridBagConstraints23.gridy = 3;
			gridBagConstraints23.gridx = 2;
			jLabelOptional2 = new JLabel();
			jLabelOptional2.setText("(Optional)");
			GridBagConstraints gridBagConstraints22 = new GridBagConstraints();
			gridBagConstraints22.insets = new Insets(0, 0, 5, 2);
			gridBagConstraints22.gridy = 2;
			gridBagConstraints22.gridx = 2;
			jLabelOptional1 = new JLabel();
			jLabelOptional1.setText("(Optional)");
			GridBagConstraints gridBagConstraints21 = new GridBagConstraints();
			gridBagConstraints21.fill = GridBagConstraints.BOTH;
			gridBagConstraints21.gridx = 1;
			gridBagConstraints21.gridy = 5;
			gridBagConstraints21.weightx = 1.0;
			gridBagConstraints21.insets = new Insets(0, 10, 5, 5);
			GridBagConstraints gridBagConstraints20 = new GridBagConstraints();
			gridBagConstraints20.fill = GridBagConstraints.BOTH;
			gridBagConstraints20.gridx = 1;
			gridBagConstraints20.gridy = 4;
			gridBagConstraints20.weightx = 1.0;
			gridBagConstraints20.insets = new Insets(0, 10, 5, 5);
			GridBagConstraints gridBagConstraints19 = new GridBagConstraints();
			gridBagConstraints19.fill = GridBagConstraints.BOTH;
			gridBagConstraints19.gridx = 1;
			gridBagConstraints19.gridy = 3;
			gridBagConstraints19.weightx = 1.0;
			gridBagConstraints19.insets = new Insets(0, 10, 5, 5);
			GridBagConstraints gridBagConstraints18 = new GridBagConstraints();
			gridBagConstraints18.fill = GridBagConstraints.BOTH;
			gridBagConstraints18.gridx = 1;
			gridBagConstraints18.gridy = 2;
			gridBagConstraints18.weightx = 1.0;
			gridBagConstraints18.insets = new Insets(0, 10, 5, 5);
			GridBagConstraints gridBagConstraints17 = new GridBagConstraints();
			gridBagConstraints17.fill = GridBagConstraints.BOTH;
			gridBagConstraints17.gridwidth = 2;
			gridBagConstraints17.gridx = 1;
			gridBagConstraints17.gridy = 1;
			gridBagConstraints17.weightx = 1.0;
			gridBagConstraints17.insets = new Insets(0, 10, 5, 2);
			GridBagConstraints gridBagConstraints16 = new GridBagConstraints();
			gridBagConstraints16.fill = GridBagConstraints.BOTH;
			gridBagConstraints16.gridwidth = 2;
			gridBagConstraints16.gridx = 1;
			gridBagConstraints16.gridy = 0;
			gridBagConstraints16.ipadx = 0;
			gridBagConstraints16.weightx = 1.0;
			gridBagConstraints16.insets = new Insets(0, 10, 5, 2);
			GridBagConstraints gridBagConstraints15 = new GridBagConstraints();
			gridBagConstraints15.anchor = GridBagConstraints.WEST;
			gridBagConstraints15.gridx = 0;
			gridBagConstraints15.gridy = 5;
			gridBagConstraints15.insets = new Insets(0, 5, 5, 0);
			jLabelRssTag = new JLabel();
			jLabelRssTag.setText("Tag:");
			GridBagConstraints gridBagConstraints14 = new GridBagConstraints();
			gridBagConstraints14.anchor = GridBagConstraints.WEST;
			gridBagConstraints14.gridx = 0;
			gridBagConstraints14.gridy = 4;
			gridBagConstraints14.insets = new Insets(0, 5, 5, 0);
			jLabelTagName = new JLabel();
			jLabelTagName.setText("Tag Name:");
			GridBagConstraints gridBagConstraints13 = new GridBagConstraints();
			gridBagConstraints13.anchor = GridBagConstraints.WEST;
			gridBagConstraints13.gridx = 0;
			gridBagConstraints13.gridy = 3;
			gridBagConstraints13.insets = new Insets(0, 5, 5, 0);
			jLabelRssTagClass = new JLabel();
			jLabelRssTagClass.setText("Tag Class:");
			GridBagConstraints gridBagConstraints12 = new GridBagConstraints();
			gridBagConstraints12.anchor = GridBagConstraints.WEST;
			gridBagConstraints12.gridx = 0;
			gridBagConstraints12.gridy = 2;
			gridBagConstraints12.insets = new Insets(0, 5, 5, 0);
			jLabelRssTagID = new JLabel();
			jLabelRssTagID.setText("Tag ID:");
			GridBagConstraints gridBagConstraints11 = new GridBagConstraints();
			gridBagConstraints11.anchor = GridBagConstraints.WEST;
			gridBagConstraints11.gridx = 0;
			gridBagConstraints11.gridy = 1;
			gridBagConstraints11.insets = new Insets(0, 5, 5, 0);
			jLabelRssUrl = new JLabel();
			jLabelRssUrl.setText("URL:");
			GridBagConstraints gridBagConstraints10 = new GridBagConstraints();
			gridBagConstraints10.anchor = GridBagConstraints.WEST;
			gridBagConstraints10.gridx = 0;
			gridBagConstraints10.gridy = 0;
			gridBagConstraints10.insets = new Insets(0, 5, 5, 0);
			jLabelRssName = new JLabel();
			jLabelRssName.setText("Name:");
			jPanelRssInfos = new JPanel();
			jPanelRssInfos.setLayout(new GridBagLayout());
			jPanelRssInfos.setBorder(BorderFactory.createTitledBorder(null, "RSS Infos", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			jPanelRssInfos.add(jLabelRssName, gridBagConstraints10);
			jPanelRssInfos.add(jLabelRssUrl, gridBagConstraints11);
			jPanelRssInfos.add(jLabelRssTagID, gridBagConstraints12);
			jPanelRssInfos.add(jLabelRssTagClass, gridBagConstraints13);
			jPanelRssInfos.add(jLabelTagName, gridBagConstraints14);
			jPanelRssInfos.add(jLabelRssTag, gridBagConstraints15);
			jPanelRssInfos.add(getJTextFieldRssName(), gridBagConstraints16);
			jPanelRssInfos.add(getJTextFieldRssUrl(), gridBagConstraints17);
			jPanelRssInfos.add(getJTextFieldRssTagID(), gridBagConstraints18);
			jPanelRssInfos.add(getJTextFieldRssTagClass(), gridBagConstraints19);
			jPanelRssInfos.add(getJTextFieldRssTagName(), gridBagConstraints20);
			jPanelRssInfos.add(getJTextFieldRssTag(), gridBagConstraints21);
			jPanelRssInfos.add(jLabelOptional1, gridBagConstraints22);
			jPanelRssInfos.add(jLabelOptional2, gridBagConstraints23);
			jPanelRssInfos.add(jLabelOptional3, gridBagConstraints24);
			jPanelRssInfos.add(jLabelOptional4, gridBagConstraints25);
		}
		return jPanelRssInfos;
	}
	/**
	 * This method initializes jTextFieldRssName	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldRssName()
	{
		if (jTextFieldRssName == null)
		{
			jTextFieldRssName = new JTextField();
			jTextFieldRssName.setEnabled(false);
			jTextFieldRssName.addFocusListener(new java.awt.event.FocusAdapter()
			{
				public void focusGained(java.awt.event.FocusEvent e)
				{
					if (getJTextFieldRssName().getText().equals(DEFAULT_RSS_NAME))
						getJTextFieldRssName().selectAll();
				}
			});
		}
		return jTextFieldRssName;
	}
	/**
	 * This method initializes jTextFieldRssUrl	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldRssUrl()
	{
		if (jTextFieldRssUrl == null)
		{
			jTextFieldRssUrl = new JTextField();
			jTextFieldRssUrl.setEnabled(false);
		}
		return jTextFieldRssUrl;
	}
	/**
	 * This method initializes jTextFieldRssTagID	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldRssTagID()
	{
		if (jTextFieldRssTagID == null)
		{
			jTextFieldRssTagID = new JTextField();
			jTextFieldRssTagID.setEnabled(false);
		}
		return jTextFieldRssTagID;
	}
	/**
	 * This method initializes jTextFieldRssTagClass	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldRssTagClass()
	{
		if (jTextFieldRssTagClass == null)
		{
			jTextFieldRssTagClass = new JTextField();
			jTextFieldRssTagClass.setEnabled(false);
		}
		return jTextFieldRssTagClass;
	}
	/**
	 * This method initializes jTextFieldRssTagName	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldRssTagName()
	{
		if (jTextFieldRssTagName == null)
		{
			jTextFieldRssTagName = new JTextField();
			jTextFieldRssTagName.setEnabled(false);
		}
		return jTextFieldRssTagName;
	}
	/**
	 * This method initializes jTextFieldRssTag	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldRssTag()
	{
		if (jTextFieldRssTag == null)
		{
			jTextFieldRssTag = new JTextField();
			jTextFieldRssTag.setEnabled(false);
		}
		return jTextFieldRssTag;
	}
	/**
	 * This method initializes jPanelRssManagerInfosButtons	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelRssManagerInfosButtons()
	{
		if (jPanelRssManagerInfosButtons == null)
		{
			FlowLayout flowLayout2 = new FlowLayout();
			flowLayout2.setAlignment(FlowLayout.RIGHT);
			flowLayout2.setHgap(5);
			jPanelRssManagerInfosButtons = new JPanel();
			jPanelRssManagerInfosButtons.setMinimumSize(new Dimension(135, 100));
			jPanelRssManagerInfosButtons.setLayout(flowLayout2);
			jPanelRssManagerInfosButtons.add(getJButtonRssManagerApply(), null);
			jPanelRssManagerInfosButtons.add(getJButtonRssManagerRevert(), null);
		}
		return jPanelRssManagerInfosButtons;
	}
	/**
	 * This method initializes jButtonRssManagerApply	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonRssManagerApply()
	{
		if (jButtonRssManagerApply == null)
		{
			jButtonRssManagerApply = new JButton();
			jButtonRssManagerApply.setPreferredSize(new Dimension(65, 20));
			jButtonRssManagerApply.setText("Apply");
			jButtonRssManagerApply.setEnabled(false);
			jButtonRssManagerApply.setMargin(new Insets(2, 10, 2, 10));
			jButtonRssManagerApply.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					if (applyRssFeed())
						refreshRssFeed();
				}
			});
		}
		return jButtonRssManagerApply;
	}
	/**
	 * This method initializes jButtonRssManagerRevert	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonRssManagerRevert()
	{
		if (jButtonRssManagerRevert == null)
		{
			jButtonRssManagerRevert = new JButton();
			jButtonRssManagerRevert.setText("Revert");
			jButtonRssManagerRevert.setMargin(new Insets(2, 10, 2, 10));
			jButtonRssManagerRevert.setEnabled(false);
			jButtonRssManagerRevert.setPreferredSize(new Dimension(65, 20));
			jButtonRssManagerRevert.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					displayRssFeed();
				}
			});
		}
		return jButtonRssManagerRevert;
	}
	
	/**
	 * This method initializes jPanelListRss	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelListRss()
	{
		if (jPanelListRss == null)
		{
			jPanelListRss = new JPanel();
			jPanelListRss.setLayout(new BorderLayout());
			jPanelListRss.add(getJToolBarRssManager(), java.awt.BorderLayout.NORTH);
			jPanelListRss.add(getJScrollPaneListRSS(), BorderLayout.CENTER);
		}
		return jPanelListRss;
	}
	/**
	 * This method initializes jToolBarRssManager	
	 * 	
	 * @return javax.swing.JToolBar	
	 */
	private JToolBar getJToolBarRssManager()
	{
		if (jToolBarRssManager == null)
		{
			jToolBarRssManager = new JToolBar();
			jToolBarRssManager.setFloatable(false);
			jToolBarRssManager.setBorderPainted(true);
			jToolBarRssManager.setUI(new BasicToolBarUI());
			jToolBarRssManager.add(getJButtonRssManagerAdd());
			jToolBarRssManager.add(getJButtonRssManagerRemove());
		}
		return jToolBarRssManager;
	}
	/**
	 * This method initializes jButtonRssManagerAdd	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonRssManagerAdd()
	{
		if (jButtonRssManagerAdd == null)
		{
			jButtonRssManagerAdd = new JButton();
			jButtonRssManagerAdd.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/add.png")));
			jButtonRssManagerAdd.setBorderPainted(false);
			jButtonRssManagerAdd.setBounds(new Rectangle(0, 0, 0, 0));
			jButtonRssManagerAdd.setToolTipText("Add new RSS");
			jButtonRssManagerAdd.setMargin(new Insets(0, 0, 0, 0));
			jButtonRssManagerAdd.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					createNewRssFeed();
				}
			});
		}
		return jButtonRssManagerAdd;
	}
	/**
	 * This method initializes jButtonRssManagerRemove	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonRssManagerRemove()
	{
		if (jButtonRssManagerRemove == null)
		{
			jButtonRssManagerRemove = new JButton();
			jButtonRssManagerRemove.setBorderPainted(false);
			jButtonRssManagerRemove.setMargin(new Insets(0, 0, 0, 0));
			jButtonRssManagerRemove.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/delete.png")));
			jButtonRssManagerRemove.setToolTipText("Remove RSS");
			jButtonRssManagerRemove.setBounds(new Rectangle(0, 0, 0, 0));
			jButtonRssManagerRemove.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					deleteRssFeed();
					refreshRssFeed();
				}
			});
		}
		return jButtonRssManagerRemove;
	}
	/**
	 * This method initializes jSeparator5	
	 * 	
	 * @return javax.swing.JSeparator	
	 */
	private JSeparator getJSeparator5()
	{
		if (jSeparator5 == null)
		{
			jSeparator5 = new JSeparator();
			jSeparator5.setOrientation(SwingConstants.VERTICAL);
		}
		return jSeparator5;
	}
	/**
	 * This method initializes jButtonBrowser	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonBrowser()
	{
		if (jButtonBrowser == null)
		{
			jButtonBrowser = new JButton();
			jButtonBrowser.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/browser.png")));
			jButtonBrowser.setPreferredSize(new Dimension(26, 26));
			jButtonBrowser.setBorderPainted(false);
			jButtonBrowser.setMargin(new Insets(2, 2, 2, 2));
			jButtonBrowser.setToolTipText("Open Browser");
			jButtonBrowser.setSize(new Dimension(26, 26));
			jButtonBrowser.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					TupleDocument document = getCurrentOpenedDocument();
					
					if (document == null)
					{
						displayWarning("The current table does not contain a link.");
						return;
					}
					
					try
					{
						displayWarning("The article is opening in your default browser...");
						java.awt.Desktop.getDesktop().browse(URI.create(document.source));
					}
					catch (IOException e1)
					{
						displayError("Cannot access this page: " + document.source);
					}
				}
			});
		}
		return jButtonBrowser;
	}
	/**
	 * This method initializes jSeparator6	
	 * 	
	 * @return javax.swing.JSeparator	
	 */
	private JSeparator getJSeparator6()
	{
		if (jSeparator6 == null)
		{
			jSeparator6 = new JSeparator();
			jSeparator6.setOrientation(SwingConstants.VERTICAL);
			jSeparator6.setMaximumSize(new Dimension(2, 26));
		}
		return jSeparator6;
	}
	/**
	 * This method initializes jSeparator7	
	 * 	
	 * @return javax.swing.JSeparator	
	 */
	private JSeparator getJSeparator7()
	{
		if (jSeparator7 == null)
		{
			jSeparator7 = new JSeparator();
			jSeparator7.setOrientation(SwingConstants.VERTICAL);
			jSeparator7.setMaximumSize(new Dimension(2, 26));
		}
		return jSeparator7;
	}
	/**
	 * This method initializes jButtonAssign	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonAssign()
	{
		if (jButtonAssign == null)
		{
			jButtonAssign = new JButton();
			jButtonAssign.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/assign.png")));
			jButtonAssign.setMaximumSize(new Dimension(26, 26));
			jButtonAssign.setMinimumSize(new Dimension(26, 26));
			jButtonAssign.setBorderPainted(false);
			jButtonAssign.setToolTipText("Assign document to a category");
			jButtonAssign.setEnabled(false);
			jButtonAssign.setPreferredSize(new Dimension(26, 26));
			jButtonAssign.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					getJDialogAssign().setVisible(true);
				}
			});
		}
		return jButtonAssign;
	}
	/**
	 * This method initializes jButtonUnassign	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonUnassign()
	{
		if (jButtonUnassign == null)
		{
			jButtonUnassign = new JButton();
			jButtonUnassign.setToolTipText("Unassign a document");
			jButtonUnassign.setSize(new Dimension(26, 26));
			jButtonUnassign.setPreferredSize(new Dimension(26, 26));
			jButtonUnassign.setMinimumSize(new Dimension(26, 26));
			jButtonUnassign.setMaximumSize(new Dimension(26, 26));
			jButtonUnassign.setBorderPainted(false);
			jButtonUnassign.setEnabled(false);
			jButtonUnassign.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/unassign.png")));
			jButtonUnassign.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					TupleDocument document = getSelectedDocument();
					
					if (document == null)
						return;
					
					try
					{
						unassign(document);
					}
					catch (Exception e1)
					{
						displayError("Error while unassigning '" + document.title + "'");
					}
				}
			});
		}
		return jButtonUnassign;
	}
	/**
	 * This method initializes jSeparator8	
	 * 	
	 * @return javax.swing.JSeparator	
	 */
	private JSeparator getJSeparator8()
	{
		if (jSeparator8 == null)
		{
			jSeparator8 = new JSeparator();
			jSeparator8.setOrientation(SwingConstants.VERTICAL);
			jSeparator8.setMaximumSize(new Dimension(2, 26));
			jSeparator8.setSize(new Dimension(5, 26));
		}
		return jSeparator8;
	}
	/**
	 * This method initializes jScrollPaneTreeDocuments	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPaneTreeDocuments()
	{
		if (jScrollPaneTreeDocuments == null)
		{
			jScrollPaneTreeDocuments = new JScrollPane();
			jScrollPaneTreeDocuments.setViewportView(getJTreeDocuments());
			jScrollPaneTreeDocuments.setPreferredSize(new Dimension(150, 60));
		}
		return jScrollPaneTreeDocuments;
	}
	/**
	 * This method initializes jDialogAssign	
	 * 	
	 * @return javax.swing.JDialog	
	 */
	private JDialog getJDialogAssign()
	{
		if (jDialogAssign == null)
		{
			jDialogAssign = new JDialog(getJFrame());
			jDialogAssign.setSize(new Dimension(238, 102));
			jDialogAssign.setTitle("Assign Category");
			jDialogAssign.setModal(true);
			jDialogAssign.setLocationRelativeTo(getJFrame());
			jDialogAssign.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			jDialogAssign.setContentPane(getJContentPaneAssign());
			jDialogAssign.addWindowListener(new java.awt.event.WindowAdapter()
			{
				public void windowActivated(java.awt.event.WindowEvent e)
				{
					getJFrame().toFront();
					refreshAssignCategories();
				}
				public void windowOpened(java.awt.event.WindowEvent e)
				{
					refreshAssignCategories();
				}
			});
		}
		return jDialogAssign;
	}
	/**
	 * This method initializes jContentPaneAssign	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJContentPaneAssign()
	{
		if (jContentPaneAssign == null)
		{
			jContentPaneAssign = new JPanel();
			jContentPaneAssign.setLayout(new BorderLayout());
			jContentPaneAssign.add(getJPanelAssignButtons(), BorderLayout.SOUTH);
			jContentPaneAssign.add(getJPanelAssign(), BorderLayout.CENTER);
		}
		return jContentPaneAssign;
	}
	/**
	 * This method initializes jPanelAssignButtons	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelAssignButtons()
	{
		if (jPanelAssignButtons == null)
		{
			FlowLayout flowLayout3 = new FlowLayout();
			flowLayout3.setAlignment(FlowLayout.RIGHT);
			jPanelAssignButtons = new JPanel();
			jPanelAssignButtons.setLayout(flowLayout3);
			jPanelAssignButtons.add(getJButtonAssignOK(), null);
			jPanelAssignButtons.add(getJButtonAssignCancel(), null);
		}
		return jPanelAssignButtons;
	}
	/**
	 * This method initializes jPanelAssign	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelAssign()
	{
		if (jPanelAssign == null)
		{
			GridBagConstraints gridBagConstraints27 = new GridBagConstraints();
			gridBagConstraints27.fill = GridBagConstraints.BOTH;
			gridBagConstraints27.gridy = 0;
			gridBagConstraints27.weightx = 1.0;
			gridBagConstraints27.insets = new Insets(0, 10, 5, 10);
			gridBagConstraints27.gridx = 1;
			GridBagConstraints gridBagConstraints26 = new GridBagConstraints();
			gridBagConstraints26.gridx = 0;
			gridBagConstraints26.insets = new Insets(0, 5, 5, 0);
			gridBagConstraints26.gridy = 0;
			jLabelCategory = new JLabel();
			jLabelCategory.setText("Category:");
			jPanelAssign = new JPanel();
			jPanelAssign.setLayout(new GridBagLayout());
			jPanelAssign.add(jLabelCategory, gridBagConstraints26);
			jPanelAssign.add(getJComboBoxCategory(), gridBagConstraints27);
		}
		return jPanelAssign;
	}
	/**
	 * This method initializes jComboBoxCategory	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJComboBoxCategory()
	{
		if (jComboBoxCategory == null)
		{
			jComboBoxCategory = new JComboBox();
		}
		return jComboBoxCategory;
	}
	/**
	 * This method initializes jButtonAssignOK	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonAssignOK()
	{
		if (jButtonAssignOK == null)
		{
			jButtonAssignOK = new JButton();
			jButtonAssignOK.setText("OK");
			jButtonAssignOK.setMargin(new Insets(2, 10, 2, 10));
			jButtonAssignOK.setPreferredSize(new Dimension(65, 20));
			jButtonAssignOK.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					TupleDocument document = getSelectedDocument();
					TupleCategory category = ((TreeItemCategory)getJComboBoxCategory().getSelectedItem()).getCategory();
					
					try
					{
						assign(document, category);
						getJDialogAssign().dispose();
					}
					catch (Exception e1)
					{
						displayError("Error assigning: '" + document.title + "' to '" + category.name + "'");
					}
				}
			});
		}
		return jButtonAssignOK;
	}
	/**
	 * This method initializes jButtonAssignCancel	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonAssignCancel()
	{
		if (jButtonAssignCancel == null)
		{
			jButtonAssignCancel = new JButton();
			jButtonAssignCancel.setText("Cancel");
			jButtonAssignCancel.setMargin(new Insets(2, 10, 2, 10));
			jButtonAssignCancel.setPreferredSize(new Dimension(65, 20));
			jButtonAssignCancel.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					getJDialogAssign().dispose();
				}
			});
		}
		return jButtonAssignCancel;
	}
	/**
	 * This method initializes jDialogCategory	
	 * 	
	 * @return javax.swing.JDialog	
	 */
	private JDialog getJDialogCategory()
	{
		if (jDialogCategory == null)
		{
			jDialogCategory = new JDialog(getJFrame());
			jDialogCategory.setSize(new Dimension(412, 202));
			jDialogCategory.setModal(true);
			jDialogCategory.setLocationRelativeTo(getJFrame());
			jDialogCategory.setTitle("Manage Categories");
			jDialogCategory.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			jDialogCategory.setContentPane(getJContentPaneCategory());
			jDialogCategory.addWindowListener(new java.awt.event.WindowAdapter()
			{
				public void windowActivated(java.awt.event.WindowEvent e)
				{
					getJFrame().toFront();
				}
				public void windowOpened(java.awt.event.WindowEvent e)
				{
					refreshCategory();
				}
			});
		}
		return jDialogCategory;
	}
	/**
	 * This method initializes jContentPaneCategory	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJContentPaneCategory()
	{
		if (jContentPaneCategory == null)
		{
			jContentPaneCategory = new JPanel();
			jContentPaneCategory.setLayout(new BorderLayout());
			jContentPaneCategory.add(getJPanelCategoryButtons(), BorderLayout.SOUTH);
			jContentPaneCategory.add(getJSplitPaneCategory(), BorderLayout.CENTER);
		}
		return jContentPaneCategory;
	}
	/**
	 * This method initializes jPanelCategoryButtons	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelCategoryButtons()
	{
		if (jPanelCategoryButtons == null)
		{
			FlowLayout flowLayout4 = new FlowLayout();
			flowLayout4.setAlignment(FlowLayout.RIGHT);
			jPanelCategoryButtons = new JPanel();
			jPanelCategoryButtons.setLayout(flowLayout4);
			jPanelCategoryButtons.add(getJButtonCategoryClose(), null);
		}
		return jPanelCategoryButtons;
	}
	/**
	 * This method initializes jButtonCategoryClose	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCategoryClose()
	{
		if (jButtonCategoryClose == null)
		{
			jButtonCategoryClose = new JButton();
			jButtonCategoryClose.setText("Close");
			jButtonCategoryClose.setMargin(new Insets(2, 10, 2, 10));
			jButtonCategoryClose.setPreferredSize(new Dimension(65, 20));
			jButtonCategoryClose.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					getJDialogCategory().dispose();
				}
			});
		}
		return jButtonCategoryClose;
	}
	/**
	 * This method initializes jSplitPaneCategory	
	 * 	
	 * @return javax.swing.JSplitPane	
	 */
	private JSplitPane getJSplitPaneCategory()
	{
		if (jSplitPaneCategory == null)
		{
			jSplitPaneCategory = new JSplitPane();
			jSplitPaneCategory.setLeftComponent(getJPanelListCategories());
			jSplitPaneCategory.setRightComponent(getJPanelInfosCategory());
		}
		return jSplitPaneCategory;
	}
	/**
	 * This method initializes jPanelListCategories	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelListCategories()
	{
		if (jPanelListCategories == null)
		{
			jPanelListCategories = new JPanel();
			jPanelListCategories.setLayout(new BorderLayout());
			jPanelListCategories.add(getJToolBarCategory(), java.awt.BorderLayout.NORTH);
			jPanelListCategories.add(getJScrollPaneListCategory(), BorderLayout.CENTER);
		}
		return jPanelListCategories;
	}
	/**
	 * This method initializes jPanelInfosCategory	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelInfosCategory()
	{
		if (jPanelInfosCategory == null)
		{
			jLabelCategoryName = new JLabel();
			jLabelCategoryName.setText("Name:");
			jPanelInfosCategory = new JPanel();
			jPanelInfosCategory.setLayout(new BorderLayout());
			jPanelInfosCategory.add(getJPanelCategoryInfos(), BorderLayout.CENTER);
			jPanelInfosCategory.add(getJPanelCategoryInfosButtons(), BorderLayout.SOUTH);
		}
		return jPanelInfosCategory;
	}
	/**
	 * This method initializes jPanelCategoryInfos	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelCategoryInfos()
	{
		if (jPanelCategoryInfos == null)
		{
			GridBagConstraints gridBagConstraints29 = new GridBagConstraints();
			gridBagConstraints29.insets = new Insets(0, 5, 5, 0);
			gridBagConstraints29.anchor = GridBagConstraints.NORTH;
			gridBagConstraints29.weighty = 1.0;
			GridBagConstraints gridBagConstraints28 = new GridBagConstraints();
			gridBagConstraints28.fill = GridBagConstraints.HORIZONTAL;
			gridBagConstraints28.insets = new Insets(0, 10, 5, 10);
			gridBagConstraints28.weighty = 1.0;
			gridBagConstraints28.anchor = GridBagConstraints.NORTH;
			gridBagConstraints28.weightx = 1.0;
			jPanelCategoryInfos = new JPanel();
			jPanelCategoryInfos.setLayout(new GridBagLayout());
			jPanelCategoryInfos.setBorder(BorderFactory.createTitledBorder(null, "Category Infos", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			jPanelCategoryInfos.add(jLabelCategoryName, gridBagConstraints29);
			jPanelCategoryInfos.add(getJTextFieldCategoryName(), gridBagConstraints28);
		}
		return jPanelCategoryInfos;
	}
	/**
	 * This method initializes jTextFieldCategoryName	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldCategoryName()
	{
		if (jTextFieldCategoryName == null)
		{
			jTextFieldCategoryName = new JTextField();
			jTextFieldCategoryName.setEnabled(false);
			jTextFieldCategoryName.addFocusListener(new java.awt.event.FocusAdapter()
			{
				public void focusGained(java.awt.event.FocusEvent e)
				{
					if (getJTextFieldCategoryName().getText().equals(DEFAULT_CATEGORY_NAME))
						getJTextFieldCategoryName().selectAll();
				}
			});
		}
		return jTextFieldCategoryName;
	}
	/**
	 * This method initializes jToolBarCategory	
	 * 	
	 * @return javax.swing.JToolBar	
	 */
	private JToolBar getJToolBarCategory()
	{
		if (jToolBarCategory == null)
		{
			jToolBarCategory = new JToolBar();
			jToolBarCategory.setFloatable(false);
			jToolBarCategory.setUI(new BasicToolBarUI());
			jToolBarCategory.add(getJButtonCategoryAdd());
			jToolBarCategory.add(getJButtonCategoryRemove());
		}
		return jToolBarCategory;
	}
	/**
	 * This method initializes jButtonCategoryAdd	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCategoryAdd()
	{
		if (jButtonCategoryAdd == null)
		{
			jButtonCategoryAdd = new JButton();
			jButtonCategoryAdd.setToolTipText("Add new category");
			jButtonCategoryAdd.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/add.png")));
			jButtonCategoryAdd.setMargin(new Insets(0, 0, 0, 0));
			jButtonCategoryAdd.setBorderPainted(false);
			jButtonCategoryAdd.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					createNewCategory();
				}
			});
		}
		return jButtonCategoryAdd;
	}
	/**
	 * This method initializes jButtonCategoryRemove	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCategoryRemove()
	{
		if (jButtonCategoryRemove == null)
		{
			jButtonCategoryRemove = new JButton();
			jButtonCategoryRemove.setToolTipText("Remove category");
			jButtonCategoryRemove.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/delete.png")));
			jButtonCategoryRemove.setMargin(new Insets(0, 0, 0, 0));
			jButtonCategoryRemove.setBorderPainted(false);
			jButtonCategoryRemove.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					removeCategory();
					refreshCategory();
				}
			});
		}
		return jButtonCategoryRemove;
	}
	/**
	 * This method initializes jListCategory	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListCategory()
	{
		if (jListCategory == null)
		{
			jListCategory = new JList();
			jListCategory.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));
			jListCategory.setModel(new DefaultListModel());
			jListCategory.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			jListCategory.addListSelectionListener(new javax.swing.event.ListSelectionListener()
			{
				public void valueChanged(javax.swing.event.ListSelectionEvent e)
				{
					displayCategory();
				}
			});
		}
		return jListCategory;
	}
	/**
	 * This method initializes jPanelCategoryInfosButtons	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelCategoryInfosButtons()
	{
		if (jPanelCategoryInfosButtons == null)
		{
			FlowLayout flowLayout21 = new FlowLayout();
			flowLayout21.setHgap(5);
			flowLayout21.setAlignment(FlowLayout.RIGHT);
			jPanelCategoryInfosButtons = new JPanel();
			jPanelCategoryInfosButtons.setMinimumSize(new Dimension(135, 100));
			jPanelCategoryInfosButtons.setLayout(flowLayout21);
			jPanelCategoryInfosButtons.add(getJButtonCategoryApply(), null);
			jPanelCategoryInfosButtons.add(getJButtonCategoryRevert(), null);
		}
		return jPanelCategoryInfosButtons;
	}
	/**
	 * This method initializes jButtonCategoryApply	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCategoryApply()
	{
		if (jButtonCategoryApply == null)
		{
			jButtonCategoryApply = new JButton();
			jButtonCategoryApply.setEnabled(false);
			jButtonCategoryApply.setMargin(new Insets(2, 10, 2, 10));
			jButtonCategoryApply.setText("Apply");
			jButtonCategoryApply.setPreferredSize(new Dimension(65, 20));
			jButtonCategoryApply.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					if (applyCategory())
						refreshCategory();
				}
			});
		}
		return jButtonCategoryApply;
	}
	/**
	 * This method initializes jButtonCategoryRevert	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCategoryRevert()
	{
		if (jButtonCategoryRevert == null)
		{
			jButtonCategoryRevert = new JButton();
			jButtonCategoryRevert.setEnabled(false);
			jButtonCategoryRevert.setMargin(new Insets(2, 10, 2, 10));
			jButtonCategoryRevert.setText("Revert");
			jButtonCategoryRevert.setPreferredSize(new Dimension(65, 20));
			jButtonCategoryRevert.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					displayCategory();
				}
			});
		}
		return jButtonCategoryRevert;
	}
	/**
	 * This method initializes jButtonRefresh	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonRefresh()
	{
		if (jButtonRefresh == null)
		{
			jButtonRefresh = new JButton();
			jButtonRefresh.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/refresh.PNG")));
			jButtonRefresh.setBorderPainted(false);
			jButtonRefresh.setMargin(new Insets(2, 10, 2, 10));
			jButtonRefresh.setPreferredSize(new Dimension(26, 26));
			jButtonRefresh.setMaximumSize(new Dimension(26, 26));
			jButtonRefresh.setEnabled(false);
			jButtonRefresh.setToolTipText("Refresh");
			jButtonRefresh.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					refresh();
				}
			});
		}
		return jButtonRefresh;
	}
	/**
	 * This method initializes jMenuItemRefresh	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemRefresh()
	{
		if (jMenuItemRefresh == null)
		{
			jMenuItemRefresh = new JMenuItem();
			jMenuItemRefresh.setText("Refresh");
			jMenuItemRefresh.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/refresh.png")));
			jMenuItemRefresh.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					refresh();
				}
			});
		}
		return jMenuItemRefresh;
	}
	/**
	 * This method initializes jScrollPaneListCategory	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPaneListCategory()
	{
		if (jScrollPaneListCategory == null)
		{
			jScrollPaneListCategory = new JScrollPane();
			jScrollPaneListCategory.setViewportView(getJListCategory());
			jScrollPaneListCategory.setPreferredSize(new Dimension(150, 400));
		}
		return jScrollPaneListCategory;
	}
	/**
	 * This method initializes jScrollPaneListRSS	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPaneListRSS()
	{
		if (jScrollPaneListRSS == null)
		{
			jScrollPaneListRSS = new JScrollPane();
			jScrollPaneListRSS.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			jScrollPaneListRSS.setViewportView(getJListRSS());
			jScrollPaneListRSS.setPreferredSize(new Dimension(150, 300));
		}
		return jScrollPaneListRSS;
	}
	/**
	 * This method initializes jMenuAlgosClassification	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJMenuAlgosClassification()
	{
		if (jMenuAlgosClassification == null)
		{
			jMenuAlgosClassification = new JMenu();
			jMenuAlgosClassification.setText("Classification");
			jMenuAlgosClassification.add(getJRadioButtonMenuItemAlgoUser());
			jMenuAlgosClassification.add(getJRadioButtonMenuItemAlgoSVM());
			jMenuAlgosClassification.add(getJRadioButtonMenuItemAlgoRandomForestTree());
			jMenuAlgosClassification.add(getJRadioButtonMenuItemAlgoRocchio());
		}
		return jMenuAlgosClassification;
	}
	/**
	 * This method initializes jMenuAlgosClustering	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJMenuAlgosClustering()
	{
		if (jMenuAlgosClustering == null)
		{
			jMenuAlgosClustering = new JMenu();
			jMenuAlgosClustering.setText("Clustering");
			jMenuAlgosClustering.add(getJRadioButtonMenuItemAlgoClusteringNone());
			jMenuAlgosClustering.add(getJRadioButtonMenuItemAlgoBKMean());
		}
		return jMenuAlgosClustering;
	}
	/**
	 * This method initializes jRadioButtonMenuItemAlgoBKMean	
	 * 	
	 * @return javax.swing.JRadioButtonMenuItem	
	 */
	private JRadioButtonMenuItem getJRadioButtonMenuItemAlgoBKMean()
	{
		if (jRadioButtonMenuItemAlgoBKMean == null)
		{
			jRadioButtonMenuItemAlgoBKMean = new JRadioButtonMenuItem();
			jRadioButtonMenuItemAlgoBKMean.setText("Bisecting K-Means");
			//jRadioButtonMenuItemAlgoBKMean.setSelected(true);
			jRadioButtonMenuItemAlgoBKMean.addItemListener(new java.awt.event.ItemListener()
			{
				public void itemStateChanged(java.awt.event.ItemEvent e)
				{
					displayMsg("Clustering algorithm changed to: Bisecting K-Means");
					m_clusteringAlgo = TypeAlgo.B_K_MEANS;
				}
			});
			buttonGroupAlgoClustering.add(jRadioButtonMenuItemAlgoBKMean);
		}
		return jRadioButtonMenuItemAlgoBKMean;
	}
	/**
	 * This method initializes jMenuItemAlgoManager	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemAlgoManager()
	{
		if (jMenuItemAlgoManager == null)
		{
			jMenuItemAlgoManager = new JMenuItem();
			jMenuItemAlgoManager.setText("Manage Algorithms...");
			jMenuItemAlgoManager.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/magic.png")));
			jMenuItemAlgoManager.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					getJDialogAlgo().setVisible(true);
				}
			});
		}
		return jMenuItemAlgoManager;
	}
	/**
	 * This method initializes jButtonTrain	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonTrain()
	{
		if (jButtonTrain == null)
		{
			jButtonTrain = new JButton();
			jButtonTrain.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/magic.png")));
			jButtonTrain.setMargin(new Insets(2, 10, 2, 10));
			jButtonTrain.setSize(new Dimension(26, 26));
			jButtonTrain.setPreferredSize(new Dimension(26, 26));
			jButtonTrain.setMinimumSize(new Dimension(26, 26));
			jButtonTrain.setMaximumSize(new Dimension(26, 26));
			jButtonTrain.setToolTipText("Train selected algorithm(s)");
			jButtonTrain.setEnabled(false);
			jButtonTrain.setBorderPainted(false);
			jButtonTrain.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					//getJDialogAlgo().setVisible(true);
					train(m_classificationAlgo);
					train(m_clusteringAlgo);
				}
			});
		}
		return jButtonTrain;
	}
	/**
	 * This method initializes jRadioButtonMenuItemAlgoRandomForestTree	
	 * 	
	 * @return javax.swing.JRadioButtonMenuItem	
	 */
	private JRadioButtonMenuItem getJRadioButtonMenuItemAlgoRandomForestTree()
	{
		if (jRadioButtonMenuItemAlgoRandomForestTree == null)
		{
			jRadioButtonMenuItemAlgoRandomForestTree = new JRadioButtonMenuItem();
			jRadioButtonMenuItemAlgoRandomForestTree.setText("Random Forest");
			jRadioButtonMenuItemAlgoRandomForestTree.addItemListener(new java.awt.event.ItemListener()
			{
				public void itemStateChanged(java.awt.event.ItemEvent e)
				{
					displayMsg("Classfication algorithm changed to: Random Forest");
					m_classificationAlgo = TypeAlgo.RANDOM_FOREST_TREE;
				}
			});
			buttonGroupAlgoClassification.add(jRadioButtonMenuItemAlgoRandomForestTree);
		}
		return jRadioButtonMenuItemAlgoRandomForestTree;
	}
	/**
	 * This method initializes jRadioButtonMenuItemAlgoUser	
	 * 	
	 * @return javax.swing.JRadioButtonMenuItem	
	 */
	private JRadioButtonMenuItem getJRadioButtonMenuItemAlgoUser()
	{
		if (jRadioButtonMenuItemAlgoUser == null)
		{
			jRadioButtonMenuItemAlgoUser = new JRadioButtonMenuItem();
			jRadioButtonMenuItemAlgoUser.setText("User");
			jRadioButtonMenuItemAlgoUser.setSelected(true);
			jRadioButtonMenuItemAlgoUser.addItemListener(new java.awt.event.ItemListener()
			{
				public void itemStateChanged(java.awt.event.ItemEvent e)
				{
					displayMsg("Classfication algorithm changed to: User");
					m_classificationAlgo = TypeAlgo.USER;
				}
			});
			buttonGroupAlgoClassification.add(jRadioButtonMenuItemAlgoUser);
		}
		return jRadioButtonMenuItemAlgoUser;
	}
	/**
	 * This method initializes jRadioButtonMenuItemAlgoClusteringNone	
	 * 	
	 * @return javax.swing.JRadioButtonMenuItem	
	 */
	private JRadioButtonMenuItem getJRadioButtonMenuItemAlgoClusteringNone()
	{
		if (jRadioButtonMenuItemAlgoClusteringNone == null)
		{
			jRadioButtonMenuItemAlgoClusteringNone = new JRadioButtonMenuItem();
			jRadioButtonMenuItemAlgoClusteringNone.setText("None");
			jRadioButtonMenuItemAlgoClusteringNone.setSelected(true);
			jRadioButtonMenuItemAlgoClusteringNone.addItemListener(new java.awt.event.ItemListener()
			{
				public void itemStateChanged(java.awt.event.ItemEvent e)
				{
					displayMsg("Clustering algorithm changed to: None");
					m_clusteringAlgo = TypeAlgo.NONE;
				}
			});
			buttonGroupAlgoClustering.add(jRadioButtonMenuItemAlgoClusteringNone);
		}
		return jRadioButtonMenuItemAlgoClusteringNone;
	}
	/**
	 * This method initializes jDialogAlgo	
	 * 	
	 * @return javax.swing.JDialog	
	 */
	private JDialog getJDialogAlgo() {
		if (jDialogAlgo == null) {
			jDialogAlgo = new JDialog(getJFrame());
			jDialogAlgo.setSize(new Dimension(421, 279));
			jDialogAlgo.setTitle("Manage Algorithms");
			jDialogAlgo.setModal(true);
			jDialogAlgo.setLocationRelativeTo(getJFrame());
			jDialogAlgo.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			jDialogAlgo.setContentPane(getJContentPaneAlgo());
			jDialogAlgo.addWindowListener(new java.awt.event.WindowAdapter()
			{
				public void windowActivated(java.awt.event.WindowEvent e)
				{
					getJFrame().toFront();
				}
				public void windowOpened(java.awt.event.WindowEvent e)
				{
					refreshAlgos();
				}
			});
		}
		return jDialogAlgo;
	}
	/**
	 * This method initializes jContentPaneAlgo	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJContentPaneAlgo() {
		if (jContentPaneAlgo == null) {
			jContentPaneAlgo = new JPanel();
			jContentPaneAlgo.setLayout(new BorderLayout());
			jContentPaneAlgo.add(getJPanelAlgoButtons(), BorderLayout.SOUTH);
			jContentPaneAlgo.add(getJSplitPaneAlgo(), BorderLayout.CENTER);
		}
		return jContentPaneAlgo;
	}
	/**
	 * This method initializes jPanelAlgoButtons	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelAlgoButtons() {
		if (jPanelAlgoButtons == null) {
			FlowLayout flowLayout41 = new FlowLayout();
			flowLayout41.setAlignment(FlowLayout.RIGHT);
			jPanelAlgoButtons = new JPanel();
			jPanelAlgoButtons.setLayout(flowLayout41);
			jPanelAlgoButtons.add(getJButtonAlgoClose(), null);
		}
		return jPanelAlgoButtons;
	}
	/**
	 * This method initializes jButtonAlgoClose	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonAlgoClose() {
		if (jButtonAlgoClose == null) {
			jButtonAlgoClose = new JButton();
			jButtonAlgoClose.setPreferredSize(new Dimension(65, 20));
			jButtonAlgoClose.setText("Close");
			jButtonAlgoClose.setMargin(new Insets(2, 10, 2, 10));
			jButtonAlgoClose.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					getJDialogAlgo().dispose();
				}
			});
		}
		return jButtonAlgoClose;
	}
	/**
	 * This method initializes jSplitPaneAlgo	
	 * 	
	 * @return javax.swing.JSplitPane	
	 */
	private JSplitPane getJSplitPaneAlgo() {
		if (jSplitPaneAlgo == null) {
			jSplitPaneAlgo = new JSplitPane();
			jSplitPaneAlgo.setLeftComponent(getJPanelListAlgos());
			jSplitPaneAlgo.setRightComponent(getJPanelInfosAlgo());
		}
		return jSplitPaneAlgo;
	}
	/**
	 * This method initializes jPanelListAlgos	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelListAlgos() {
		if (jPanelListAlgos == null) {
			jPanelListAlgos = new JPanel();
			jPanelListAlgos.setLayout(new BorderLayout());
			jPanelListAlgos.add(getJToolBarAlgo(), java.awt.BorderLayout.NORTH);
			jPanelListAlgos.add(getJScrollPaneListAlgo(), java.awt.BorderLayout.CENTER);
		}
		return jPanelListAlgos;
	}
	/**
	 * This method initializes jToolBarAlgo	
	 * 	
	 * @return javax.swing.JToolBar	
	 */
	private JToolBar getJToolBarAlgo() {
		if (jToolBarAlgo == null) {
			jToolBarAlgo = new JToolBar();
			jToolBarAlgo.setUI(new BasicToolBarUI());
			jToolBarAlgo.setFloatable(false);
			jToolBarAlgo.add(getJButtonAlgoAdd());
			jToolBarAlgo.add(getJButtonAlgoRemove());
		}
		return jToolBarAlgo;
	}
	/**
	 * This method initializes jButtonAlgoAdd	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonAlgoAdd() {
		if (jButtonAlgoAdd == null) {
			jButtonAlgoAdd = new JButton();
			jButtonAlgoAdd.setToolTipText("Add new algorithm");
			jButtonAlgoAdd.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/add.png")));
			jButtonAlgoAdd.setMargin(new Insets(0, 0, 0, 0));
			jButtonAlgoAdd.setEnabled(false);
			jButtonAlgoAdd.setBorderPainted(false);
		}
		return jButtonAlgoAdd;
	}
	/**
	 * This method initializes jButtonAlgoRemove	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonAlgoRemove() {
		if (jButtonAlgoRemove == null) {
			jButtonAlgoRemove = new JButton();
			jButtonAlgoRemove.setToolTipText("Remove algorithm");
			jButtonAlgoRemove.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/delete.png")));
			jButtonAlgoRemove.setMargin(new Insets(0, 0, 0, 0));
			jButtonAlgoRemove.setEnabled(false);
			jButtonAlgoRemove.setBorderPainted(false);
		}
		return jButtonAlgoRemove;
	}
	/**
	 * This method initializes jScrollPaneListAlgo	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPaneListAlgo() {
		if (jScrollPaneListAlgo == null) {
			jScrollPaneListAlgo = new JScrollPane();
			jScrollPaneListAlgo.setPreferredSize(new Dimension(150, 400));
			jScrollPaneListAlgo.setViewportView(getJListAlgo());
		}
		return jScrollPaneListAlgo;
	}
	/**
	 * This method initializes jListAlgo	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListAlgo() {
		if (jListAlgo == null) {
			jListAlgo = new JList();
			jListAlgo.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));
			jListAlgo.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			jListAlgo.setModel(new DefaultListModel());
			jListAlgo.addListSelectionListener(new javax.swing.event.ListSelectionListener()
			{
				public void valueChanged(javax.swing.event.ListSelectionEvent e)
				{
					displayAlgo();
				}
			});
		}
		return jListAlgo;
	}
	/**
	 * This method initializes jPanelInfosAlgo	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelInfosAlgo() {
		if (jPanelInfosAlgo == null) {
			jPanelInfosAlgo = new JPanel();
			jPanelInfosAlgo.setLayout(new BorderLayout());
			jPanelInfosAlgo.add(getJPanelAlgoInfos(), java.awt.BorderLayout.CENTER);
			jPanelInfosAlgo.add(getJPanelAlgoInfosButtons(), java.awt.BorderLayout.SOUTH);
		}
		return jPanelInfosAlgo;
	}
	/**
	 * This method initializes jPanelAlgoInfos	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelAlgoInfos() {
		if (jPanelAlgoInfos == null) {
			GridBagConstraints gridBagConstraints31 = new GridBagConstraints();
			gridBagConstraints31.gridx = 1;
			gridBagConstraints31.insets = new Insets(0, 10, 5, 10);
			gridBagConstraints31.anchor = GridBagConstraints.NORTHWEST;
			gridBagConstraints31.weighty = 1.0;
			gridBagConstraints31.weightx = 1.0;
			gridBagConstraints31.gridy = 1;
			GridBagConstraints gridBagConstraints30 = new GridBagConstraints();
			gridBagConstraints30.gridx = 0;
			gridBagConstraints30.anchor = GridBagConstraints.NORTHWEST;
			gridBagConstraints30.insets = new Insets(3, 5, 5, 0);
			gridBagConstraints30.weighty = 1.0;
			gridBagConstraints30.gridy = 1;
			jLabelIsClustering = new JLabel();
			jLabelIsClustering.setText("Type:");
			TitledBorder titledBorder = BorderFactory.createTitledBorder(null, "Category Infos", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51));
			titledBorder.setTitle("Algorithm Infos");
			GridBagConstraints gridBagConstraints281 = new GridBagConstraints();
			gridBagConstraints281.anchor = GridBagConstraints.CENTER;
			gridBagConstraints281.insets = new Insets(0, 10, 5, 10);
			gridBagConstraints281.weightx = 1.0;
			gridBagConstraints281.weighty = 0.0;
			gridBagConstraints281.fill = GridBagConstraints.HORIZONTAL;
			GridBagConstraints gridBagConstraints291 = new GridBagConstraints();
			gridBagConstraints291.anchor = GridBagConstraints.CENTER;
			gridBagConstraints291.weighty = 0.0;
			gridBagConstraints291.insets = new Insets(0, 5, 5, 0);
			jLabelAlgoName = new JLabel();
			jLabelAlgoName.setText("Name:");
			jPanelAlgoInfos = new JPanel();
			jPanelAlgoInfos.setLayout(new GridBagLayout());
			jPanelAlgoInfos.setBorder(titledBorder);
			jPanelAlgoInfos.add(jLabelAlgoName, gridBagConstraints291);
			jPanelAlgoInfos.add(getJTextFieldAlgoName(), gridBagConstraints281);
			jPanelAlgoInfos.add(jLabelIsClustering, gridBagConstraints30);
			jPanelAlgoInfos.add(getJCheckBoxIsClustering(), gridBagConstraints31);
		}
		return jPanelAlgoInfos;
	}
	/**
	 * This method initializes jTextFieldAlgoName	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldAlgoName() {
		if (jTextFieldAlgoName == null) {
			jTextFieldAlgoName = new JTextField();
			jTextFieldAlgoName.setEnabled(true);
			jTextFieldAlgoName.setEditable(false);
		}
		return jTextFieldAlgoName;
	}
	/**
	 * This method initializes jPanelAlgoInfosButtons	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelAlgoInfosButtons() {
		if (jPanelAlgoInfosButtons == null) {
			FlowLayout flowLayout211 = new FlowLayout();
			flowLayout211.setHgap(5);
			flowLayout211.setAlignment(FlowLayout.RIGHT);
			jPanelAlgoInfosButtons = new JPanel();
			jPanelAlgoInfosButtons.setMinimumSize(new Dimension(135, 100));
			jPanelAlgoInfosButtons.setPreferredSize(new Dimension(140, 30));
			jPanelAlgoInfosButtons.setLayout(flowLayout211);
			jPanelAlgoInfosButtons.add(getJButtonAlgoParams(), null);
			jPanelAlgoInfosButtons.add(getJButtonAlgoTrain(), null);
		}
		return jPanelAlgoInfosButtons;
	}
	/**
	 * This method initializes jButtonAlgoTrain	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonAlgoTrain() {
		if (jButtonAlgoTrain == null) {
			jButtonAlgoTrain = new JButton();
			jButtonAlgoTrain.setEnabled(false);
			jButtonAlgoTrain.setMargin(new Insets(2, 10, 2, 10));
			jButtonAlgoTrain.setText("Train");
			jButtonAlgoTrain.setPreferredSize(new Dimension(65, 20));
			jButtonAlgoTrain.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					Object item = getJListAlgo().getSelectedValue();
					if (item != null)
						train(((TreeItemAlgo)item).getAlgo().idAlgo);
				}
			});
		}
		return jButtonAlgoTrain;
	}
	/**
	 * This method initializes jCheckBoxIsClustering	
	 * 	
	 * @return javax.swing.JCheckBox	
	 */
	private JCheckBox getJCheckBoxIsClustering() {
		if (jCheckBoxIsClustering == null) {
			jCheckBoxIsClustering = new JCheckBox();
			jCheckBoxIsClustering.setText("Is clustering");
			jCheckBoxIsClustering.setEnabled(false);
			jCheckBoxIsClustering.setMargin(new Insets(2, 0, 2, 2));
		}
		return jCheckBoxIsClustering;
	}
	/**
	 * This method initializes JButtonAlgoParams	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonAlgoParams() {
		if (JButtonAlgoParams == null) {
			JButtonAlgoParams = new JButton();
			JButtonAlgoParams.setText("Params");
			JButtonAlgoParams.setMargin(new Insets(0, 10, 0, 10));
			JButtonAlgoParams.setEnabled(false);
			JButtonAlgoParams.setPreferredSize(new Dimension(75, 20));
			JButtonAlgoParams.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					getJDialogParams().setVisible(true);
				}
			});
		}
		return JButtonAlgoParams;
	}
	/**
	 * This method initializes jDialogParams	
	 * 	
	 * @return javax.swing.JDialog	
	 */
	private JDialog getJDialogParams() {
		if (jDialogParams == null) {
			jDialogParams = new JDialog(getJDialogAlgo());
			jDialogParams.setTitle("Params");
			jDialogParams.setModal(true);
			jDialogParams.setLocationRelativeTo(getJDialogAlgo());
			jDialogParams.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			jDialogParams.setSize(new Dimension(409, 254));
			jDialogParams.setContentPane(getJContentPaneParams());
			jDialogParams.addWindowListener(new java.awt.event.WindowAdapter()
			{
				public void windowActivated(java.awt.event.WindowEvent e)
				{
					getJFrame().toFront();
				}
				public void windowOpened(java.awt.event.WindowEvent e)
				{
					Object item = getJListAlgo().getSelectedValue();
					if (item == null)
						return;
					
					refreshParams(((TreeItemAlgo)item).getAlgo().idAlgo);
				}
			});
		}
		return jDialogParams;
	}
	/**
	 * This method initializes jContentPaneParams	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJContentPaneParams() {
		if (jContentPaneParams == null) {
			jContentPaneParams = new JPanel();
			jContentPaneParams.setLayout(new BorderLayout());
			jContentPaneParams.add(getJPanelParamsButtons(), BorderLayout.SOUTH);
			jContentPaneParams.add(getJSplitPaneParams(), BorderLayout.CENTER);
		}
		return jContentPaneParams;
	}
	/**
	 * This method initializes jPanelParamsButtons	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelParamsButtons() {
		if (jPanelParamsButtons == null) {
			FlowLayout flowLayout42 = new FlowLayout();
			flowLayout42.setAlignment(FlowLayout.RIGHT);
			jPanelParamsButtons = new JPanel();
			jPanelParamsButtons.setLayout(flowLayout42);
			jPanelParamsButtons.add(getJButtonParamsClose(), null);
		}
		return jPanelParamsButtons;
	}
	/**
	 * This method initializes jButtonParamsClose	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonParamsClose() {
		if (jButtonParamsClose == null) {
			jButtonParamsClose = new JButton();
			jButtonParamsClose.setPreferredSize(new Dimension(65, 20));
			jButtonParamsClose.setText("Close");
			jButtonParamsClose.setMargin(new Insets(2, 10, 2, 10));
			jButtonParamsClose.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					getJDialogParams().dispose();
				}
			});
		}
		return jButtonParamsClose;
	}
	/**
	 * This method initializes jSplitPaneParams	
	 * 	
	 * @return javax.swing.JSplitPane	
	 */
	private JSplitPane getJSplitPaneParams() {
		if (jSplitPaneParams == null) {
			jSplitPaneParams = new JSplitPane();
			jSplitPaneParams.setLeftComponent(getJPanelListParams());
			jSplitPaneParams.setRightComponent(getJPanelInfosParams());
		}
		return jSplitPaneParams;
	}
	/**
	 * This method initializes jPanelListParams	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelListParams() {
		if (jPanelListParams == null) {
			jPanelListParams = new JPanel();
			jPanelListParams.setLayout(new BorderLayout());
			jPanelListParams.add(getJToolBarParams(), java.awt.BorderLayout.NORTH);
			jPanelListParams.add(getJScrollPaneListParams(), java.awt.BorderLayout.CENTER);
		}
		return jPanelListParams;
	}
	/**
	 * This method initializes jToolBarParams	
	 * 	
	 * @return javax.swing.JToolBar	
	 */
	private JToolBar getJToolBarParams() {
		if (jToolBarParams == null) {
			jToolBarParams = new JToolBar();
			jToolBarParams.setUI(new BasicToolBarUI());
			jToolBarParams.setFloatable(false);
			jToolBarParams.add(getJButtonParamsAdd());
			jToolBarParams.add(getJButtonParamsRemove());
		}
		return jToolBarParams;
	}
	/**
	 * This method initializes jButtonParamsAdd	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonParamsAdd() {
		if (jButtonParamsAdd == null) {
			jButtonParamsAdd = new JButton();
			jButtonParamsAdd.setToolTipText("Add new parameter");
			jButtonParamsAdd.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/add.png")));
			jButtonParamsAdd.setMargin(new Insets(0, 0, 0, 0));
			jButtonParamsAdd.setBorderPainted(false);
			jButtonParamsAdd.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					createNewParam();
				}
			});
		}
		return jButtonParamsAdd;
	}
	/**
	 * This method initializes jButtonParamsRemove	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonParamsRemove() {
		if (jButtonParamsRemove == null) {
			jButtonParamsRemove = new JButton();
			jButtonParamsRemove.setToolTipText("Remove parameter");
			jButtonParamsRemove.setIcon(new ImageIcon(getClass().getResource("/gui/img/icon/delete.png")));
			jButtonParamsRemove.setMargin(new Insets(0, 0, 0, 0));
			jButtonParamsRemove.setBorderPainted(false);
			jButtonParamsRemove.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					removeParam();
					refreshParams(m_idSelectedAlgo);
				}
			});
		}
		return jButtonParamsRemove;
	}
	/**
	 * This method initializes jScrollPaneListParams	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPaneListParams() {
		if (jScrollPaneListParams == null) {
			jScrollPaneListParams = new JScrollPane();
			jScrollPaneListParams.setPreferredSize(new Dimension(150, 400));
			jScrollPaneListParams.setViewportView(getJListParams());
		}
		return jScrollPaneListParams;
	}
	/**
	 * This method initializes jListParams	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListParams() {
		if (jListParams == null) {
			jListParams = new JList();
			jListParams.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));
			jListParams.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			jListParams.setModel(new DefaultListModel());
			jListParams.addListSelectionListener(new javax.swing.event.ListSelectionListener()
			{
				public void valueChanged(javax.swing.event.ListSelectionEvent e) 
				{
					displayParam();
				}
			});
		}
		return jListParams;
	}
	/**
	 * This method initializes jPanelInfosParams	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelInfosParams() {
		if (jPanelInfosParams == null) {
			jPanelInfosParams = new JPanel();
			jPanelInfosParams.setLayout(new BorderLayout());
			jPanelInfosParams.add(getJPanelParamsInfos(), java.awt.BorderLayout.CENTER);
			jPanelInfosParams.add(getJPanelParamsInfosButtons(), java.awt.BorderLayout.SOUTH);
		}
		return jPanelInfosParams;
	}
	/**
	 * This method initializes jPanelParamsInfos	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelParamsInfos() {
		if (jPanelParamsInfos == null) {
			GridBagConstraints gridBagConstraints34 = new GridBagConstraints();
			gridBagConstraints34.fill = GridBagConstraints.HORIZONTAL;
			gridBagConstraints34.gridy = 1;
			gridBagConstraints34.weightx = 1.0;
			gridBagConstraints34.insets = new Insets(0, 10, 5, 10);
			gridBagConstraints34.weighty = 1.0;
			gridBagConstraints34.anchor = GridBagConstraints.NORTHWEST;
			gridBagConstraints34.gridx = 1;
			GridBagConstraints gridBagConstraints33 = new GridBagConstraints();
			gridBagConstraints33.fill = GridBagConstraints.HORIZONTAL;
			gridBagConstraints33.gridy = 1;
			gridBagConstraints33.weightx = 1.0;
			gridBagConstraints33.insets = new Insets(0, 10, 5, 10);
			gridBagConstraints33.weighty = 1.0;
			gridBagConstraints33.anchor = GridBagConstraints.NORTHWEST;
			gridBagConstraints33.gridx = 1;
			GridBagConstraints gridBagConstraints32 = new GridBagConstraints();
			gridBagConstraints32.gridx = 0;
			gridBagConstraints32.weighty = 1.0;
			gridBagConstraints32.anchor = GridBagConstraints.NORTHWEST;
			gridBagConstraints32.insets = new Insets(0, 5, 5, 0);
			gridBagConstraints32.gridy = 1;
			jLabelParamsValue = new JLabel();
			jLabelParamsValue.setText("Value:");
			TitledBorder titledBorder1 = BorderFactory.createTitledBorder(null, "Category Infos", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51));
			titledBorder1.setTitle("Parameter Infos");
			GridBagConstraints gridBagConstraints282 = new GridBagConstraints();
			gridBagConstraints282.anchor = GridBagConstraints.NORTH;
			gridBagConstraints282.insets = new Insets(0, 10, 5, 10);
			gridBagConstraints282.weightx = 1.0;
			gridBagConstraints282.weighty = 0.0;
			gridBagConstraints282.fill = GridBagConstraints.HORIZONTAL;
			GridBagConstraints gridBagConstraints292 = new GridBagConstraints();
			gridBagConstraints292.anchor = GridBagConstraints.NORTH;
			gridBagConstraints292.weighty = 0.0;
			gridBagConstraints292.insets = new Insets(0, 5, 5, 0);
			jLabelParamsName = new JLabel();
			jLabelParamsName.setText("Name:");
			jPanelParamsInfos = new JPanel();
			jPanelParamsInfos.setLayout(new GridBagLayout());
			jPanelParamsInfos.setBorder(titledBorder1);
			jPanelParamsInfos.add(jLabelParamsName, gridBagConstraints292);
			jPanelParamsInfos.add(getJTextFieldParamsName(), gridBagConstraints282);
			jPanelParamsInfos.add(jLabelParamsValue, gridBagConstraints32);
			jPanelParamsInfos.add(getJTextFieldParamsValue(), gridBagConstraints34);
			jPanelParamsInfos.add(getJTextFieldParamsValue(), gridBagConstraints33);
		}
		return jPanelParamsInfos;
	}
	/**
	 * This method initializes jTextFieldParamsName	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldParamsName() {
		if (jTextFieldParamsName == null) {
			jTextFieldParamsName = new JTextField();
			jTextFieldParamsName.setEnabled(false);
		}
		return jTextFieldParamsName;
	}
	
	/**
	 * This method initializes jTextFieldParamsValue1	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldParamsValue() {
		if (jTextFieldParamsValue == null) {
			jTextFieldParamsValue = new JTextField();
			jTextFieldParamsValue.setEnabled(false);
		}
		return jTextFieldParamsValue;
	}
	/**
	 * This method initializes jPanelParamsInfosButtons	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelParamsInfosButtons() {
		if (jPanelParamsInfosButtons == null) {
			FlowLayout flowLayout212 = new FlowLayout();
			flowLayout212.setHgap(5);
			flowLayout212.setAlignment(FlowLayout.RIGHT);
			jPanelParamsInfosButtons = new JPanel();
			jPanelParamsInfosButtons.setMinimumSize(new Dimension(135, 100));
			jPanelParamsInfosButtons.setLayout(flowLayout212);
			jPanelParamsInfosButtons.add(getJButtonParamsApply(), null);
			jPanelParamsInfosButtons.add(getJButtonParamsRevert(), null);
		}
		return jPanelParamsInfosButtons;
	}
	/**
	 * This method initializes jButtonParamsApply	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonParamsApply() {
		if (jButtonParamsApply == null) {
			jButtonParamsApply = new JButton();
			jButtonParamsApply.setEnabled(false);
			jButtonParamsApply.setMargin(new Insets(2, 10, 2, 10));
			jButtonParamsApply.setText("Apply");
			jButtonParamsApply.setPreferredSize(new Dimension(65, 20));
			jButtonParamsApply.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					Object item = getJListAlgo().getSelectedValue();
					if (item == null)
						return;
					
					if (applyParam(((TreeItemAlgo)item).getAlgo().idAlgo))
						refreshParams(((TreeItemAlgo)item).getAlgo().idAlgo);
				}
			});
		}
		return jButtonParamsApply;
	}
	/**
	 * This method initializes jButtonParamsRevert	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonParamsRevert() {
		if (jButtonParamsRevert == null) {
			jButtonParamsRevert = new JButton();
			jButtonParamsRevert.setEnabled(false);
			jButtonParamsRevert.setMargin(new Insets(2, 10, 2, 10));
			jButtonParamsRevert.setText("Revert");
			jButtonParamsRevert.setPreferredSize(new Dimension(65, 20));
			jButtonParamsRevert.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					displayParam();
				}
			});
		}
		return jButtonParamsRevert;
	}
	/**
	 * Launches this application
	 */
	public static void main(String[] args)
	{
		SwingUtilities.invokeLater(new Runnable()
		{
			public void run()
			{
				FeedUS application = new FeedUS();
				application.getJFrame().setVisible(true);
				application.getJFrame().setLocationRelativeTo(null);
			}
		});
	}
}
