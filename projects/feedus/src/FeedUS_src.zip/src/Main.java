import java.io.IOException;


public class Main
{
	public static void main(String[] args) throws IOException
	{
		String url = "http://www.google.com";
		java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));
	}
	
//	public static void main(String[] args) throws SQLException, MalformedURLException, RssParserException, IOException
//	{
//		//MyConnection cnx = new MyConnection(TypeDB.POSTGRESQL, "postgresql.alwaysdata.com", "feedus_ift603", "feedus", "marcus19");
//		//MyConnection cnx = new MyConnection(TypeDB.POSTGRESQL, "stevie.heliohost.org", "feedus_ift603", "feedus", "marcus19");
//		//MyConnection cnx = new MyConnection(TypeDB.MYSQL, "stevie.heliohost.org", "feedus_ift603", "feedus_test", "test");
//		//MyConnection cnx = new MyConnection(TypeDB.MYSQL, "localhost", "feedus_ift603", "feedus", "marcus19");
//		
//		//Document doc = new Document(cnx);
//		Algo algo = new Algo(cnx);
//		
//		//for(TupleDocument it : doc.get())
//		for(TupleAlgo it : algo.get())
//		{
//			System.out.println(it);
//		}
//		
//		cnx.commit();
//	}
	
	
//	public static void main(String[] args) throws ParseException
//	{
//		//RssParser rp = new RssParser("http://feeds.reuters.com/reuters/scienceNews");
//    	RssParser rp = new RssParser("http://www.reddit.com/.rss");
//    	//RssParser rp = new RssParser("http://rss.slashdot.org/Slashdot/slashdot");
//    	//RssParser rp = new RssParser("http://slashdot.org/firehose_popular.rss");
//    	//RssParser rp = new RssParser("http://feeds.digg.com/digg/container/science/popular.rss");
//    	
//		rp.parse();
//		RssFeed feed = rp.getFeed();
//
//		// Listing all categories & the no. of elements in each category
//		if(feed.category != null)
//		{
//			System.out.println("Category List: ");
//			for(String category : feed.category.keySet())
//			{
//				System.out.println(category + ": " +((ArrayList<Item>) feed.category.get(category)).size());
//			}
//		}
//		
//		new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.ENGLISH);
//
//		// Listing all items in the feed
//		for(int i = 0; i < feed.items.size(); i++)
//		{
//			System.out.println(feed.items.get(i).title);
//			System.out.println(MyDate.valueOf(MyDate.parse(feed.items.get(i).pubDate)));
//			//System.out.println(feed.items.get(i).pubDate);
//			System.out.println(feed.items.get(i).link);
//		}
//	}
}
