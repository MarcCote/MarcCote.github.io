package preprocessing;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

class StopWords
{
	private final String STOP_WORDS_FILENAME = "StopWords.txt";
	private ArrayList<String> m_stopWords = new ArrayList<String>();
	private static StopWords m_instance = null;
	public static StopWords getInstance()
	{
		if (m_instance == null)
			m_instance = new StopWords();
		
		return m_instance;
	}
	
	private StopWords()
	{
		loadWords(STOP_WORDS_FILENAME);
		Collections.sort(m_stopWords);
	}
	
	private void loadWords(String p_fileName)
	{
		try 
		{
			BufferedReader br = new BufferedReader(new FileReader(p_fileName));
			String word;
			m_stopWords.clear();
			
			while((word = br.readLine()) != null)
				m_stopWords.add(word);
		}
		catch (FileNotFoundException e) { e.printStackTrace(); }
		catch (IOException e) { e.printStackTrace(); }
	}
	
	public boolean isStopWord(String p_word)
	{
		return Collections.binarySearch(m_stopWords, p_word) > 0;
	}
}