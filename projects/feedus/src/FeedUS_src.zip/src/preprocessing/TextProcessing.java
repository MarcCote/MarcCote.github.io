package preprocessing;

import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.regex.Pattern;

public class TextProcessing
{
	private String m_rawText;
	private StringBuffer m_text;
	private TreeMap<String, Integer> m_words;
	private int m_nbWords;
	StopWords m_stopper = StopWords.getInstance();
	PorterStemmer m_stemmer = PorterStemmer.getInstance();
	
	public TextProcessing(String p_text)
	{
		m_nbWords = 0;
		m_rawText = p_text;
		m_words = new TreeMap<String, Integer>();
		m_text = new StringBuffer();
		
		//Clean
		p_text = removeHTMLTags(p_text);
		Pattern pattern = Pattern.compile("[^a-zA-Z ]");
		p_text = p_text.replaceAll(pattern.pattern(), " ");
		
		StringTokenizer token = new StringTokenizer(p_text.toLowerCase());

		while(token.hasMoreTokens())
		{
			String word = token.nextToken();
			//Stop
			if(!m_stopper.isStopWord(word))
			{
				//Stem
				word = m_stemmer.stem(word);
				
				//Stats
				if (!m_words.containsKey(word))
					m_words.put(word, 0);
				
				m_words.put(word, m_words.get(word) + 1);
				++m_nbWords;
				
				m_text.append(word + " ");
			}
		}
	}
		
	public static String removeHTMLTags(String p_text)
	{
		String text = p_text;
        
        text = text.replaceAll("<[^>]*>", "");
        text = text.replaceAll("&[^;]*;", " ");
        
        return text;
	}
	
	public TreeMap<String, Integer> getWords()
	{
		return m_words;
	}
	
	public int getNbWords()
	{
		return m_nbWords;
	}
	
	public int getNbUniqWords()
	{
		return m_words.size();
	}
	
	public String getRawText()
	{
		return m_rawText;
	}
	
	public String getText()
	{
		return m_text.toString();
	}
	
	public static void main(String[] args) 
	{
		String text = "Eating potatoe make you look good. Even if the potatoes aren't benific for your health!";
		TextProcessing tp = new TextProcessing(text);
		System.out.println(tp.getText());
	}
}
