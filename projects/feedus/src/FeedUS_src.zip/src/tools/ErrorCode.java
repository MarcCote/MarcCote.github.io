package tools;

public enum ErrorCode {
	OK,
	Unknown,
	NeedMoreData,
	CantCreateAllCluster
}
