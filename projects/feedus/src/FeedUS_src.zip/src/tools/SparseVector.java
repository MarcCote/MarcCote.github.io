package tools;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TreeMap;

import app.exception.ParserException;


public class SparseVector {
	
	public static final String START_VECTOR = "SV";
	public static final String END_VECTOR = "EV";
	
	private TreeMap<Integer, Double> m_data; 
	
	public SparseVector()
	{
		m_data = new TreeMap<Integer, Double>();
	}
	
	public SparseVector(StringTokenizer st) throws ParserException
	{
		if(!st.hasMoreTokens())
			throw new ParserException("Expecting \"" + START_VECTOR + "\", receive EOF");
		
		String token = st.nextToken();
		if(!token.equals(START_VECTOR))
			throw new ParserException("Expecting \"" + START_VECTOR +
					"\", receive \"" + token + "\"");
		
		if(!st.hasMoreTokens())
			throw new ParserException("Expecting \"" + END_VECTOR + "\", receive EOF");
		
		m_data = new TreeMap<Integer, Double>();
		
		token = st.nextToken();
		Integer key;
		Double value;
		
		try{
			while(!token.equals(END_VECTOR))
			{
				
				key = Integer.parseInt(token);		
				
				if(!st.hasMoreTokens())
					throw new ParserException("Expecting Double value, receive EOF");				
				token = st.nextToken();
				
				value = Double.parseDouble(token);
				
				m_data.put(key, value);
				
				if(!st.hasMoreTokens())
					throw new ParserException("Expecting " + END_VECTOR + ", receive EOF");				
				token = st.nextToken();
			}
		} catch (NumberFormatException e) {
			throw new ParserException("NumberFormatException " + e.getMessage());
		}		
	}
	
	public SparseVector(SparseVector b)
	{
		m_data = (TreeMap<Integer, Double>) b.m_data.clone();
	}
	
	public double get(Integer index)
	{
		Double result = m_data.get(index);
		if(result == null)
			return 0.0;
		return result.doubleValue();
	}
	
	public void set(Integer index, Double value)
	{
		m_data.put(index, value);
	}
	
	public void add(SparseVector b)
	{
		ArrayList<Map.Entry<Integer, Double>> toAdd = new ArrayList<Map.Entry<Integer,Double>>();
		
		Iterator<Map.Entry<Integer, Double>> it1 = m_data.entrySet().iterator();
		Iterator<Map.Entry<Integer, Double>> it2 = b.m_data.entrySet().iterator();

		Map.Entry<Integer, Double> v1 = (it1.hasNext()?it1.next():null);;
		Map.Entry<Integer, Double> v2 = (it2.hasNext()?it2.next():null);;
		
		while(v1!=null && v2!=null)
		{			
			if(v1.getKey().equals(v2.getKey()))
			{
				v1.setValue(v1.getValue()+v2.getValue());
				v1 = (it1.hasNext()?it1.next():null);
				v2 = (it2.hasNext()?it2.next():null);
			} else if(v1.getKey()<v2.getKey())
				v1 = (it1.hasNext()?it1.next():null);
			else {
				toAdd.add(v2);
				v2 = (it2.hasNext()?it2.next():null);
			}
		}
		
		if(v2!=null && it2.hasNext())
			toAdd.add(it2.next());
		while(it2.hasNext())
		{
			toAdd.add(it2.next());
		}			
		
		for(Map.Entry<Integer, Double> e : toAdd)
			m_data.put(e.getKey(), e.getValue());
	}
	
	public void sub(SparseVector b)
	{
		ArrayList<Map.Entry<Integer, Double>> toAdd = new ArrayList<Map.Entry<Integer,Double>>();
		
		Iterator<Map.Entry<Integer, Double>> it1 = m_data.entrySet().iterator();
		Iterator<Map.Entry<Integer, Double>> it2 = b.m_data.entrySet().iterator();

		Map.Entry<Integer, Double> v1 = (it1.hasNext()?it1.next():null);;
		Map.Entry<Integer, Double> v2 = (it2.hasNext()?it2.next():null);;
		
		while(v1!=null && v2!=null)
		{			
			if(v1.getKey().equals(v2.getKey()))
			{
				v1.setValue(v1.getValue()-v2.getValue());
				v1 = (it1.hasNext()?it1.next():null);
				v2 = (it2.hasNext()?it2.next():null);
			} else if(v1.getKey()<v2.getKey())
				v1 = (it1.hasNext()?it1.next():null);
			else {
				toAdd.add(v2);
				v2 = (it2.hasNext()?it2.next():null);
			}
		}
		
		if(v2!=null)
			toAdd.add(it2.next());
		while(it2.hasNext())
		{
			toAdd.add(it2.next());
		}
		
		for(Map.Entry<Integer, Double> e : toAdd)
			m_data.put(e.getKey(), 0-e.getValue());
	}
	
	public void divide(double b)
	{
		Iterator<Map.Entry<Integer, Double>> it1 = m_data.entrySet().iterator();
		
		Map.Entry<Integer, Double> v1 = null;
		
		while(it1.hasNext())
		{
			v1 = it1.next();
			v1.setValue(v1.getValue()/b);
		}
	}
	
	public double dotProduct(SparseVector b)
	{
		double result = 0;
		
		Iterator<Map.Entry<Integer, Double>> it1 = m_data.entrySet().iterator();
		Iterator<Map.Entry<Integer, Double>> it2 = b.m_data.entrySet().iterator();

		Map.Entry<Integer, Double> v1 = (it1.hasNext()?it1.next():null);;
		Map.Entry<Integer, Double> v2 = (it2.hasNext()?it2.next():null);;
		
		while(v1!=null && v2!=null)
		{			
			if(v1.getKey().equals(v2.getKey()))
			{
				result += v1.getValue()*v2.getValue();
				v1 = (it1.hasNext()?it1.next():null);
				v2 = (it2.hasNext()?it2.next():null);
			} else if(v1.getKey()<v2.getKey())
				v1 = (it1.hasNext()?it1.next():null);
			else {
				v2 = (it2.hasNext()?it2.next():null);
			}
		}
		
		return result;
	}
	
	public double norm()
	{
		double result = 0;
		
		Iterator< Double> it1 = m_data.values().iterator();
		
		Double v1 = null;
		
		while(it1.hasNext())
		{
			v1 = it1.next();
			result += v1*v1;
		}
		
		result = Math.sqrt(result);
		
		return result;
	}
	
	public boolean equals(SparseVector b)
	{
		return m_data.equals(b.m_data);
	}
	
	public double cosineSimilarity(SparseVector b)
	{
		return dotProduct(b) / (norm() * b.norm());
	}
	
	public String toString()
	{
		String result = START_VECTOR+" ";
		
		for(Map.Entry<Integer, Double> e : m_data.entrySet())
		{
			result += e.getKey() + ":" + e.getValue() + " ";
		}
		
		result +=END_VECTOR;
		return result;
	}

}
