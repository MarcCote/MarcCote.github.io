package tools;

public class ArrayTool {
	
	public static double[] sumDoubleArray(double[] a, double[] b)
	{
		double[] result; 
		int aL = a.length;
		int bL = b.length;
		int i = 0;
		
		if(aL>bL)
		{
			result = new double[aL];
			for(; i<bL;++i)
				result[i] = a[i] + b[i];
			for(; i<aL;++i)
				result[i] = a[i];
		} else 
		{
			result = new double[bL];
			for(; i<aL;++i)
				result[i] = a[i] + b[i];
			for(; i<bL;++i)
				result[i] = a[i];
		}
		return result;
	}
	
	public static void addDoubleArray(double[] a, double[] b)
	{
		int min = Math.min(a.length, b.length);
		
		for(int i = 0; i<min;++i)
			a[i] += b[i];
	}
	
	public static void subDoubleArray(double[] a, double[] b)
	{
		int min = Math.min(a.length, b.length);
		
		for(int i = 0; i<min;++i)
			a[i] -= b[i];
	}
	
	public static void divideDoubleArray(double[] a, double b)
	{
		int d = a.length;
		
		for(int i = 0;i<d;++i)
			a[i] /= b;		
	}
	
	public static double dotProduct(double[] a, double[] b)
	{
		int d = a.length;
		double result = 0;
		for(int i = 0;i<d;++i)
			result += a[i]*b[i];
		
		return result;
	}
	
	public static double norm(double[] a)
	{
		int d = a.length;
		double result = 0;
		
		for(int i = 0;i<d;++i)
			result += a[i]*a[i];
		
		result = Math.sqrt(result);
		
		return result;
	}
	
	public static double cosineSimilarity(double[] a, double[] b)
	{
		return dotProduct(a, b) / (norm(a) * norm(b));
	}
}
