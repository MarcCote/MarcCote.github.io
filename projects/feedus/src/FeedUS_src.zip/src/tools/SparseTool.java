package tools;

import weka.core.SparseInstance;

public class SparseTool {
	
	
	public static void add(SparseInstance a, SparseInstance b)
	{
		int indexA = a.locateIndex(Integer.MAX_VALUE);
		int indexB = b.locateIndex(Integer.MAX_VALUE);
		
		while(indexA>=0 || indexB>=0)
		{
			
			if(indexA == indexB)
			{
				a.setValueSparse(indexA, a.valueSparse(indexA)+b.valueSparse(indexB));
				indexA = a.locateIndex(indexA-1);
				indexB = b.locateIndex(indexB-1);
			} else if(indexA>indexB)
				indexA = a.locateIndex(indexA-1);
			else {
				a.setValueSparse(indexA, b.valueSparse(indexB));
				indexB = b.locateIndex(indexB-1);
			}
		}
	}
	
	public static void sub(SparseInstance a, SparseInstance b)
	{
		int indexA = a.locateIndex(Integer.MAX_VALUE);
		int indexB = b.locateIndex(Integer.MAX_VALUE);
		
		while(indexA>=0 || indexB>=0)
		{
			
			if(indexA == indexB)
			{
				a.setValueSparse(indexA, a.valueSparse(indexA)-b.valueSparse(indexB));
				indexA = a.locateIndex(indexA-1);
				indexB = b.locateIndex(indexB-1);
			} else if(indexA>indexB)
				indexA = a.locateIndex(indexA-1);
			else {
				a.setValueSparse(indexA, b.valueSparse(indexB));
				indexB = b.locateIndex(indexB-1);
			}
		}
	}
	
	public static void divide(SparseInstance a, double b)
	{
		int indexA = a.locateIndex(Integer.MAX_VALUE);
		
		while(indexA>=0)
		{
			a.setValueSparse(indexA, a.valueSparse(indexA)/b);
			indexA = a.locateIndex(indexA-1);
		}
	}
	
	public static double dotProduct(SparseInstance a, SparseInstance b)
	{
		double result = 0;
		
		int indexA = a.locateIndex(Integer.MAX_VALUE);
		int indexB = b.locateIndex(Integer.MAX_VALUE);
		
		while(indexA>=0 || indexB>=0)
		{
			
			if(indexA == indexB)
			{
				result+=a.valueSparse(indexA) * b.valueSparse(indexB);
				indexA = a.locateIndex(indexA-1);
				indexB = b.locateIndex(indexB-1);
			} else if(indexA>indexB)
				indexA = a.locateIndex(indexA-1);
			else
				indexB = b.locateIndex(indexB-1);
		}
		return result;
	}
	
	public static double norm(SparseInstance a)
	{
		double result = 0;
		
		int indexA = a.locateIndex(Integer.MAX_VALUE);
		
		while(indexA>=0)
		{
			result += a.valueSparse(indexA)*a.valueSparse(indexA);
			indexA = a.locateIndex(indexA-1);
		}
		
		result = Math.sqrt(result);
		
		return result;
	}
	
	public static boolean equals(SparseInstance a, SparseInstance b)
	{
		int indexA = a.locateIndex(Integer.MAX_VALUE);
		int indexB = b.locateIndex(Integer.MAX_VALUE);
		
		while(indexA>=0 || indexB>=0)
		{			
			if(indexA != indexB || a.valueSparse(indexA) != b.valueSparse(indexB))
				return false;
			indexA = a.locateIndex(indexA-1);
			indexB = b.locateIndex(indexB-1);
		}
		
		return true;
	}
	
	public static double cosineSimilarity(SparseInstance a, SparseInstance b)
	{
		return dotProduct(a, b) / (norm(a) * norm(b));
	}

}
