package db.tuple;

public class TupleCategory
{
	public final static TupleCategory UNCLUSTERED = new TupleCategory(1L, "Unclustered", false);
	
	public Long idCategory;
	public String name;
	public Boolean createdByUser;
	
	public TupleCategory() {};
			
	public TupleCategory(Long idCategory, String name, Boolean createdByUser)
	{
		this.idCategory = idCategory;
		this.name = name;
		this.createdByUser = createdByUser;
	}
	
	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		
		sb.append(idCategory);
		sb.append(":");
		sb.append(name);
		sb.append(":");
		sb.append(createdByUser);
		
		return sb.toString();
	}
}
