package db.tuple;

import java.util.Calendar;
import java.util.GregorianCalendar;

import util.MyDate;

public class TupleDocument
{	
	public Long idDocument;
	public String title;
	public String description;
	public Calendar date = new GregorianCalendar();
	public String author;
	public Boolean seen;
	public Boolean visible;
	public String source;
	public String text;
	public Long idRSS;
	
	public TupleDocument() {}
	
	public TupleDocument(Long idDocument, String title, String description, Calendar date, String author, Boolean seen, Boolean visible, String source, String text, Long idRSS)
	{
		this.idDocument = idDocument;
		this.title = title;
		this.description = description;
		this.date = date;
		this.author = author;
		this.seen = seen;
		this.visible = visible;
		this.source = source;
		this.text = text;
		this.idRSS = idRSS;
	}
	
	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		
		sb.append(idDocument);
		sb.append(":");
		sb.append(title);
		sb.append(":");
		sb.append(description);
		sb.append(":");
		sb.append(MyDate.valueOf(date));
		sb.append(":");
		sb.append(author);
		sb.append(":");
		sb.append(seen);
		sb.append(":");
		sb.append(visible);
		sb.append(":");
		sb.append(source);
		sb.append(":");
		sb.append(text);
		sb.append(":");
		sb.append(idRSS);
		
		return sb.toString();
	}
}
