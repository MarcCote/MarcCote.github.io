package db.tuple;

public class TupleRssFeed
{
	public Long idRSS;
	public String name;
	public String url;
	public String tagID;
	public String tagClass;
	public String tagName;
	public String tag;
	
	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		
		sb.append(idRSS);
		sb.append(":");
		sb.append(name);
		sb.append(":");
		sb.append(url);
		sb.append(":");
		sb.append(tagID);
		sb.append(":");
		sb.append(tagClass);
		sb.append(":");
		sb.append(tagName);
		sb.append(":");
		sb.append(tag);
		
		return sb.toString();
	}
}
