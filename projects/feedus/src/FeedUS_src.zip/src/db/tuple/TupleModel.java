package db.tuple;

public class TupleModel {
	
	public Long idAlgo;
	public String name;
	public byte[] data;
	
	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		
		sb.append(idAlgo);
		sb.append(":");
		sb.append(name);
		sb.append(":");
		sb.append(data.toString());
		
		return sb.toString();
	}

}
