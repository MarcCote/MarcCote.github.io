package db.tuple;

public class TupleWord
{
	public Long idWord;
	public String word;
	
	@Deprecated
	public Long totalDocCount;
	
	public TupleWord() {}
			
	public TupleWord(Long idWord, String word, Long totalDocCount)
	{
		this.idWord = idWord;
		this.word = word;
		this.totalDocCount = totalDocCount;
	}
	
	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		
		sb.append(idWord);
		sb.append(":");
		sb.append(word);
		sb.append(":");
		sb.append(totalDocCount);
		
		return sb.toString();
	}
}
