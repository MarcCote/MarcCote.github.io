package db.tuple;

public class TupleWordDocument
{
	public Long idDocument;
	public Long idWord;
	public Long count;
	public Double weight;
	
	public TupleWord word = null;
	public TupleDocument document = null;
	
	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append(idDocument);
		sb.append(":");
		sb.append(idWord);
		sb.append(":");
		sb.append(count);
		sb.append(":");
		sb.append(weight);
		sb.append(":");
		
		if (document != null)
		{
			sb.append("[");
			sb.append(document);
			sb.append("]:");
		}
		
		if (word != null)
		{
			sb.append("[");
			sb.append(word);
			sb.append("]");
		}
		
		return sb.toString();
	}
}
