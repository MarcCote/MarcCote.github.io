package db.tuple;

public class TupleDocumentCategory
{
	public Long idAlgo;
	public Long idDocument;
	public Long idCategory;

	public TupleDocument document = null;
	public TupleCategory category = null;
	
	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		
		sb.append(idAlgo);
		sb.append(":");
		sb.append(idCategory);
		sb.append(":");
		sb.append(idDocument);
		
		return sb.toString();
	}
}
