package db.tuple;

public class TupleAlgo
{
	public Long idAlgo;
	public String name;
	public Boolean isClustering;
	
	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		
		sb.append(idAlgo);
		sb.append(":");
		sb.append(name);
		sb.append(":");
		sb.append(isClustering);
		
		return sb.toString();
	}
}
