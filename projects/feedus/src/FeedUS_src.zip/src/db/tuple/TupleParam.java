package db.tuple;

public class TupleParam
{
	public Long idAlgo;
	public Long idParams;
	public String name;
	public String value;
	
	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		
		sb.append(idParams);
		sb.append(":");
		sb.append(idAlgo);
		sb.append(":");
		sb.append(name);
		sb.append(":");
		sb.append(value);
		
		return sb.toString();
	}
}
