package db;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


/**
 * Connections manager with relational DB using JDBC.
 * 
 *<pre>
 * Marc-Alexandre C�t� - 07 166 997
 * Universit� de Sherbrooke
 * v1.0 - 07 mars 2010
 *
 * Precondition
 *   JDBC drivers need to be reachable.
 * 
 * Postcondition
 *   The connection is serializable but not auto-committing (if supported).
 * </pre>
 */
public class MyConnection
{
	public static String DEFAULT_HOST = "localhost";
	public static String DEFAULT_POSTGRES_PORT = "5432";
	public static String DEFAULT_ORACLE_PORT = "";
	public static String DEFAULT_MYSQL_PORT = "3306";
	public static String DEFAULT_SQL_SERVER_PORT = "";
	
	private Connection m_cnx;
	
	public static String getDefaultPort(TypeDB p_type)
	{
		switch (p_type)
		{
			case POSTGRESQL: return DEFAULT_POSTGRES_PORT;
			case MYSQL: return DEFAULT_MYSQL_PORT;
			case ORACLE: return DEFAULT_ORACLE_PORT;
			case SQL_SERVER: return DEFAULT_SQL_SERVER_PORT;
			default: break;
		}
		
		return null;
	}

	/**
	 * Open a connection that will be serializable but not auto-committing (if supported).
	 * 
	 * @param p_type of the DB
	 * @param p_dbName name of the DB
	 * @param p_user on the DB
	 * @param p_password on the DB
	 */
	public MyConnection(TypeDB p_type, String p_dbName, String p_user, String p_password) throws SQLException
	{
		this(p_type, DEFAULT_HOST, getDefaultPort(p_type), p_dbName, p_user, p_password);
	}
	
	/**
	 * Open a connection that will be serializable but not auto-committing (if supported).
	 * 
	 * @param p_type of the DB
	 * @param p_dbName name of the DB
	 * @param p_host where the DB is
	 * @param p_user on the DB
	 * @param p_password on the DB
	 */
	public MyConnection(TypeDB p_type, String p_host, String p_dbName, String p_user, String p_password) throws SQLException
	{
		this(p_type, p_host, getDefaultPort(p_type), p_dbName, p_user, p_password);
	}
	
	/**
	 * Open a connection that will be serializable but not auto-committing (if supported).
	 * 
	 * @param p_type of the DB
	 * @param p_dbName name of the DB
	 * @param p_host where the DB is
	 * @param p_port number the DB is listening to
	 * @param p_user on the DB
	 * @param p_password on the DB
	 */
	public MyConnection(TypeDB p_type, String p_host, String p_port, String p_dbName, String p_user, String p_password) throws SQLException
	{
		try
		{	
			switch (p_type)
			{
				case POSTGRESQL:
				{
					String url = "jdbc:postgresql:" + p_host;
					Properties props = new Properties();
					props.setProperty("user", p_user);
					props.setProperty("password", p_password);

					
					m_cnx = DriverManager.getConnection("jdbc:postgresql://" + p_host + ":" + p_port + "/" + p_dbName, p_user, p_password);
					break;
				}	
				case MYSQL:
				{
					String url = "jdbc:mysql://" + p_host + ":" + p_port + "/" + p_dbName;
					Properties props = new Properties();
					props.setProperty("user", p_user);
					props.setProperty("password", p_password);

					m_cnx = DriverManager.getConnection(url, p_user, p_password);
					
					break;
				}
				default:
					throw new Exception("Unsupported DB!");
			}

			// mettre en mode de commit manuel
			m_cnx.setAutoCommit(false);

			// mettre en mode s�rialisable si possible
			// (plus haut niveau d'integrit� l'acc�s concurrent aux donn�es)
			DatabaseMetaData dbmd = m_cnx.getMetaData();
			if (dbmd.supportsTransactionIsolationLevel(Connection.TRANSACTION_SERIALIZABLE))
			{
				m_cnx.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
				System.out.println("Serializable connection opened:\n" + "Estampille " + System.currentTimeMillis() + " " + m_cnx);
			}
			else
				System.out.println("Read commitable connection opened:\n" + "Heure " + System.currentTimeMillis() + " " + m_cnx);
		}
		catch (SQLException e)
		{
			throw e;
		}
		catch (Exception e)
		{
			e.printStackTrace(System.out);
			throw new SQLException("JDBC Driver non instanci�");
		}
	}

	/**
	 * Close the connection.
	 */
	public void close() throws SQLException
	{
		if (m_cnx.isClosed())
			return;
		
		m_cnx.rollback();
		m_cnx.close();
		
		System.out.println("Connection closed: " + m_cnx);
	}

	/**
	 * Commit
	 */
	public void commit() throws SQLException
	{
		m_cnx.commit();
	}

	/**
	 * Rollback
	 */
	public void rollback() throws SQLException
	{
		m_cnx.rollback();
	}

	/**
	 * Return the JDBC connection.
	 */
	public Connection getConnection()
	{
		return m_cnx;
	}
	
	public boolean isClosed()
	{
		try
		{
			return m_cnx.isClosed();
		}
		catch (SQLException e) { e.printStackTrace();}
		
		return false;
	}
}
