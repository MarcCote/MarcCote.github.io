package db;

public enum TypeDB
{
	POSTGRESQL,
	ORACLE,
	MYSQL,
	SQL_SERVER,
}
