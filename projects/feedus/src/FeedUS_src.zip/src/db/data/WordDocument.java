package db.data;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.TreeMap;

import algo.TypeAlgo;

import db.MyConnection;
import db.tuple.TupleDocument;
import db.tuple.TupleWord;
import db.tuple.TupleWordDocument;

public class WordDocument
{
	private PreparedStatement m_stmtSelectRef;
	private PreparedStatement m_stmtSelect;
	private PreparedStatement m_stmtSelectByDocument;
	private PreparedStatement m_stmtSelectRefByDocument;
	private PreparedStatement m_stmtSelectByWord;
	private PreparedStatement m_stmtSelectRefByWord;
	private PreparedStatement m_stmtSelectAll;
	private PreparedStatement m_stmtSelectAllOrdered;
	private PreparedStatement m_stmtSelectAllOrderedClassified;
	private PreparedStatement m_stmtSelectNbDocument;
	private PreparedStatement m_stmtSelectNbClassifiedDocument;
	private PreparedStatement m_stmtSelectUnclassifiedWord;
	private PreparedStatement m_stmtInsert;
	private PreparedStatement m_stmtUpdate;
	private PreparedStatement m_stmtDelete;
	private MyConnection m_cnx;
	
	/**
	  * Creation of an instance. Prepared statements are built.
	  */
	public WordDocument(MyConnection cx) throws SQLException 
	{
		m_cnx = cx;
		m_stmtSelectRef = cx.getConnection().prepareStatement(
				"SELECT idDocument, idWord, count, weight " +
				"FROM words_documents " +
				"WHERE idDocument = ? AND idWord = ?");
		
		m_stmtSelect = cx.getConnection().prepareStatement(
				"SELECT words_documents.idDocument, words_documents.idWord, count, weight, word, totalDocCount, title, description, date, author, seen, visible, source, text, idRSS " +
				"FROM words_documents " +
				"INNER JOIN words ON words.idWord = words_documents.idWord " +
				"INNER JOIN documents ON documents.idDocument = words_documents.idDocument " +
				"WHERE words_documents.idDocument = ? AND words_documents.idWord = ?");
		
		m_stmtSelectRefByDocument = cx.getConnection().prepareStatement(
				"SELECT idDocument, idWord, count, weight " +
				"FROM words_documents " +
				"WHERE idDocument = ?");
		
		m_stmtSelectByDocument = cx.getConnection().prepareStatement(
				"SELECT idDocument, words_documents.idWord, count, weight, word, totalDocCount " +
				"FROM words_documents " +
				"INNER JOIN words ON words.idWord = words_documents.idWord " +
				"WHERE idDocument = ?");
		
		m_stmtSelectRefByWord = cx.getConnection().prepareStatement(
				"SELECT idDocument, idWord, count, weight " +
				"FROM words_documents " +
				"WHERE idWord = ?");
		
		m_stmtSelectByWord = cx.getConnection().prepareStatement(
				"SELECT words_documents.idDocument, idWord, count, weight, title, description, date, author, seen, visible, source, text, idRSS " +
				"FROM words_documents " +
				"INNER JOIN documents ON documents.idDocument = words_documents.idDocument " +
				"WHERE idWord = ?");
		
		m_stmtSelectAll = cx.getConnection().prepareStatement(
				"SELECT idDocument, idWord, count, weight " +
				"FROM words_documents");
		
		m_stmtSelectAllOrdered = cx.getConnection().prepareStatement(
				"SELECT idDocument, idWord, count, weight " +
				"FROM words_documents " +
				"order by iddocument");
		
		m_stmtSelectAllOrderedClassified = cx.getConnection().prepareStatement(
				"SELECT words_documents.idDocument, idWord, count, weight " +
				"FROM words_documents " +
				"INNER JOIN documents_categories ON words_documents.iddocument = documents_categories.iddocument " +
				"WHERE documents_categories.idalgo = ? " +
				"order by words_documents.iddocument");
		
		m_stmtSelectNbDocument = cx.getConnection().prepareStatement(
				"SELECT idword, count(*) nbDocument " +
				"FROM words_documents " +
				"group by idword");
		
		m_stmtSelectNbClassifiedDocument = cx.getConnection().prepareStatement(
				"SELECT idword, count(*) nbDocument " +
				"FROM words_documents " +
				"INNER JOIN documents_categories ON words_documents.iddocument = documents_categories.iddocument " +
				"WHERE documents_categories.idalgo = ? " +
				"group by idword);");
		
		m_stmtSelectUnclassifiedWord = cx.getConnection().prepareStatement(
				"select w.iddocument, w.idword, w.count, w.weight " +
				"from words_documents w " +
				"inner join ( " +
				"	select iddocument " +
				"	from documents_categories " +
				"	where (idalgo = 1) or (idcategory != 1 and idalgo = 2) " +
				"	group by iddocument " +
				"	having count(*) < 2) d " +
				"on w.iddocument = d.iddocument " +
				"order by w.iddocument");
		
		m_stmtInsert = cx.getConnection().prepareStatement(
				"INSERT INTO words_documents (idDocument, idWord, count, weight) " +
				" VALUES (?, ?, ?, ?) ");
		
		m_stmtUpdate = cx.getConnection().prepareStatement(
				"UPDATE words_documents " +
				" SET count = ?, weight = ? " + 
				" WHERE idDocument = ? AND idWord = ?");
		
		m_stmtDelete = cx.getConnection().prepareStatement(
				"DELETE FROM words_documents " +
				"WHERE idDocument = ? AND idWord = ?");
	}

	public MyConnection getConnexion()
	{
		return m_cnx;
	}
	
	public static TupleWordDocument create(ResultSet p_rset) throws SQLException
	{
		TupleWordDocument word_document = null;
		
		word_document = new TupleWordDocument();
		word_document.idDocument = p_rset.getLong("idDocument");
		word_document.idWord = p_rset.getLong("idWord");
		word_document.count = p_rset.getLong("count");
		word_document.weight = p_rset.getDouble("weight");
		
		return word_document;
	}
	
	public TupleWordDocument getRef(Long p_idDocument, Long p_idWord) throws SQLException
	{
		m_stmtSelectRef.setLong(1, p_idDocument);
		m_stmtSelectRef.setLong(2, p_idWord);
		ResultSet rset = m_stmtSelectRef.executeQuery();
		TupleWordDocument word_document = null;
		
		if (rset.next())
			word_document = create(rset);

		rset.close();
	    return word_document;
	}
	
	public TupleWordDocument get(Long p_idDocument, Long p_idWord) throws SQLException
	{
		m_stmtSelect.setLong(1, p_idDocument);
		m_stmtSelect.setLong(2, p_idWord);
		ResultSet rset = m_stmtSelect.executeQuery();
		TupleWordDocument word_document = null;
		
		if (rset.next())
		{
			word_document = create(rset);
			word_document.document = Document.create(rset);
			word_document.word = Word.create(rset);
		}

		rset.close();
	    return word_document;
	}
	
	public ArrayList<TupleWordDocument> getRefByDocument(Long p_idDocument) throws SQLException
	{
		m_stmtSelectRefByDocument.setLong(1, p_idDocument);
		ResultSet rset = m_stmtSelectRefByDocument.executeQuery();
		ArrayList<TupleWordDocument> listWordDocument = new ArrayList<TupleWordDocument>();
		
		while (rset.next())
			listWordDocument.add(create(rset));

		rset.close();
	    return listWordDocument;
	}
	
	public ArrayList<TupleWordDocument> getByDocument(Long p_idDocument) throws SQLException
	{
		m_stmtSelectByDocument.setLong(1, p_idDocument);
		ResultSet rset = m_stmtSelectRefByDocument.executeQuery();
		ArrayList<TupleWordDocument> listWordDocument = new ArrayList<TupleWordDocument>();
		TupleDocument document = new Document(m_cnx).get(p_idDocument);
		
		while (rset.next())
	    {
			TupleWordDocument word_document = create(rset);
			word_document.word = Word.create(rset);
			word_document.document = document;
			listWordDocument.add(word_document);
	    }

		rset.close();
	    return listWordDocument;
	}
	
	public ArrayList<TupleWordDocument> getRefByWord(Long p_idWord) throws SQLException
	{
		m_stmtSelectRefByWord.setLong(1, p_idWord);
		ResultSet rset = m_stmtSelectRefByWord.executeQuery();
		ArrayList<TupleWordDocument> listWordDocument = new ArrayList<TupleWordDocument>();

		while (rset.next())
			listWordDocument.add(create(rset));

		rset.close();
	    return listWordDocument;
	}
	
	public ArrayList<TupleWordDocument> getByWord(Long p_idWord) throws SQLException
	{
		m_stmtSelectByWord.setLong(1, p_idWord);
		ResultSet rset = m_stmtSelectRefByWord.executeQuery();
		ArrayList<TupleWordDocument> listWordDocument = new ArrayList<TupleWordDocument>();
		TupleWord word = new Word(m_cnx).get(p_idWord);
		
		while (rset.next())
		{
			TupleWordDocument word_document = create(rset);
			word_document.document = Document.create(rset);
			word_document.word = word;
			listWordDocument.add(word_document);
	    }

		rset.close();
	    return listWordDocument;
	}
	
	public ArrayList<TupleWordDocument> get() throws SQLException
	{
		ResultSet rset = m_stmtSelectAll.executeQuery();
		ArrayList<TupleWordDocument> listWordDocument = new ArrayList<TupleWordDocument>();

		while (rset.next())
			listWordDocument.add(create(rset));

		rset.close();
	    return listWordDocument;
	}
	
	public ArrayList<TupleWordDocument> getOrdered() throws SQLException
	{
		ResultSet rset = m_stmtSelectAllOrdered.executeQuery();
		ArrayList<TupleWordDocument> listWordDocument = new ArrayList<TupleWordDocument>();

		while (rset.next())
			listWordDocument.add(create(rset));

		rset.close();
	    return listWordDocument;
	}
	
	public ArrayList<TupleWordDocument> getOrderedClassified() throws SQLException
	{
		m_stmtSelectAllOrderedClassified.setLong(1, TypeAlgo.USER.getCode());
		ResultSet rset = m_stmtSelectAllOrderedClassified.executeQuery();
		ArrayList<TupleWordDocument> listWordDocument = new ArrayList<TupleWordDocument>();

		while (rset.next())
			listWordDocument.add(create(rset));

		rset.close();
	    return listWordDocument;
	}
	
	public TreeMap<Integer, Double> getNbDocumentPerWord() throws SQLException
	{
		ResultSet rset = m_stmtSelectNbDocument.executeQuery();
		TreeMap<Integer, Double> map = new TreeMap<Integer, Double>();

		while (rset.next())
			map.put((int)rset.getLong("idword"),rset.getDouble("nbDocument"));

		rset.close();
	    return map;
	}
	
	public TreeMap<Integer, Double> getNbClassifiedDocumentPerWord() throws SQLException
	{
		m_stmtSelectNbClassifiedDocument.setLong(1, TypeAlgo.USER.getCode());
		ResultSet rset = m_stmtSelectNbClassifiedDocument.executeQuery();
		TreeMap<Integer, Double> map = new TreeMap<Integer, Double>();

		while (rset.next())
			map.put((int)rset.getLong("idword"),rset.getDouble("nbDocument"));

		rset.close();
	    return map;
	}
	
	public TreeMap<Integer, Double> getIDF(long p_nbDoc) throws SQLException
	{
		ResultSet rset = m_stmtSelectNbDocument.executeQuery();
		TreeMap<Integer, Double> map = new TreeMap<Integer, Double>();

		while (rset.next())
			map.put((int)rset.getLong("idword"),Math.log(p_nbDoc/(double) rset.getInt("nbDocument")));

		rset.close();
	    return map;
	}
	
	public TreeMap<Integer, Double> getClassifiedIDF(long p_nbDoc) throws SQLException
	{
		ResultSet rset = m_stmtSelectNbClassifiedDocument.executeQuery();
		TreeMap<Integer, Double> map = new TreeMap<Integer, Double>();

		while (rset.next())
			map.put((int)rset.getLong("idword"),Math.log(p_nbDoc/(double) rset.getInt("nbDocument")));

		rset.close();
	    return map;
	}
	
	public ArrayList<TupleWordDocument> getUnclassifiedWord() throws SQLException
	{
		ResultSet rset = m_stmtSelectUnclassifiedWord.executeQuery();
		ArrayList<TupleWordDocument> listWordDocument = new ArrayList<TupleWordDocument>();

		while (rset.next())
			listWordDocument.add(create(rset));

		rset.close();
	    return listWordDocument;
	}
	
	public boolean insert(Long p_idDocument, Long p_idWord, Integer p_count, Double p_weight) throws SQLException
	{
		m_stmtInsert.setLong(1, p_idDocument);
		m_stmtInsert.setLong(2, p_idWord);
		m_stmtInsert.setLong(3, p_count);
		m_stmtInsert.setDouble(4, p_weight);
		
		return m_stmtInsert.executeUpdate() != 0;
	}
	
	public int update(Long p_idDocument, Long p_idWord, Integer p_count, Double p_weight) throws SQLException
	{
		m_stmtUpdate.setLong(1, p_count);
		m_stmtUpdate.setDouble(2, p_weight);
		m_stmtUpdate.setLong(3, p_idDocument);
		m_stmtUpdate.setLong(4, p_idWord);
		
		return m_stmtUpdate.executeUpdate();
	}
	
	public int delete(Long p_idDocument, Long p_idWord) throws SQLException
	{
		m_stmtDelete.setLong(1, p_idDocument);
		m_stmtDelete.setLong(2, p_idWord);
		return m_stmtDelete.executeUpdate();
	}
}
