package db.data;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import db.MyConnection;
import db.tuple.TupleAlgo;

public class Algo
{
	private PreparedStatement m_stmtSelect;
	private PreparedStatement m_stmtSelectAll;
	private PreparedStatement m_stmtInsert;
	private PreparedStatement m_stmtUpdate;
	private PreparedStatement m_stmtDelete;
	private MyConnection m_cnx;

	/**
	  * Creation of an instance. Prepared statements are built.
	  */
	public Algo(MyConnection cx) throws SQLException 
	{	
		m_cnx = cx;
		m_stmtSelect = cx.getConnection().prepareStatement(
				"SELECT idAlgo, name, isClustering " +
				"FROM algorithms " +
				"WHERE idAlgo = ?");
		
		m_stmtSelectAll = cx.getConnection().prepareStatement(
				"SELECT idAlgo, name, isClustering " +
				"FROM algorithms");
		
		m_stmtInsert = cx.getConnection().prepareStatement(
				"INSERT INTO algorithms (name, isClustering) " +
				" VALUES (?, ?)", Statement.RETURN_GENERATED_KEYS);
		
		m_stmtUpdate = cx.getConnection().prepareStatement(
				"UPDATE algorithms " +
				" SET name = ?, isClustering = ? " + 
				" WHERE idAlgo = ?");
		
		m_stmtDelete = cx.getConnection().prepareStatement(
				"DELETE FROM algorithms " +
				"WHERE idAlgo = ?");
	}

	public MyConnection getConnexion()
	{
		return m_cnx;
	}
	
	public static TupleAlgo create(ResultSet p_rset) throws SQLException
	{
		TupleAlgo algo = null;

		algo = new TupleAlgo();
		algo.idAlgo = p_rset.getLong("idAlgo");
		algo.name = p_rset.getString("name");
		algo.isClustering = p_rset.getBoolean("isClustering");
	
		return algo;
	}
	
	public TupleAlgo get(Long p_idAlgo) throws SQLException
	{
		m_stmtSelect.setLong(1, p_idAlgo);
		ResultSet rset = m_stmtSelect.executeQuery();
		TupleAlgo algo = null;
		
		if (rset.next())
			algo = create(rset);

		rset.close();
	    return algo;
	}
	
	public ArrayList<TupleAlgo> get() throws SQLException
	{
		ResultSet rset = m_stmtSelectAll.executeQuery();
		ArrayList<TupleAlgo> algos = new ArrayList<TupleAlgo>();
		
		while (rset.next())
			algos.add(create(rset));

		rset.close();
	    return algos;
	}
	
	public Long insert(String p_name, Boolean p_isClustering) throws SQLException
	{
		m_stmtInsert.setString(1, p_name);
		m_stmtInsert.setBoolean(2, p_isClustering);
		m_stmtInsert.executeUpdate();
		
		ResultSet rset = m_stmtInsert.getGeneratedKeys();
		
		if (rset.next())
			return rset.getLong(1);
		
		return null;
	}
	
	public int update(Long p_idAlgo, String p_name, Boolean p_isClustering) throws SQLException
	{
		m_stmtUpdate.setString(1, p_name);
		m_stmtUpdate.setBoolean(2, p_isClustering);
		m_stmtUpdate.setLong(3, p_idAlgo);
		m_stmtUpdate.executeUpdate();
		
		return m_stmtUpdate.executeUpdate();
	}
	
	public int delete(Long p_idAlgo) throws SQLException
	{
		m_stmtDelete.setLong(1, p_idAlgo);
		return m_stmtDelete.executeUpdate();
	}
}
