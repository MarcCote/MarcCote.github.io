package db.data;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import db.MyConnection;
import db.tuple.TupleCategory;

public class Category
{
	private PreparedStatement m_stmtSelect;
	private PreparedStatement m_stmtSelectAll;
	private PreparedStatement m_stmtSelectAllOnlyUserCategory;
	private PreparedStatement m_stmtInsert;
	private PreparedStatement m_stmtUpdate;
	private PreparedStatement m_stmtDelete;
	private MyConnection m_cnx;
	
	/**
	  * Creation of an instance. Prepared statements are built.
	  */
	public Category(MyConnection cx) throws SQLException 
	{	
		m_cnx = cx;
		m_stmtSelect = cx.getConnection().prepareStatement(
				"SELECT idCategory, name, createdByUser " +
				"FROM categories " +
				"WHERE idCategory = ?");
		
		m_stmtSelectAll = cx.getConnection().prepareStatement(
				"SELECT idCategory, name, createdByUser " +
				"FROM categories");
		
		m_stmtSelectAllOnlyUserCategory = cx.getConnection().prepareStatement(
				"SELECT idCategory, name, createdByUser " +
				"FROM categories " +
				"WHERE createdByUser = true");
		
		m_stmtInsert = cx.getConnection().prepareStatement(
				"INSERT INTO categories (name, createdByUser) " +
				" VALUES (?, ?) ", Statement.RETURN_GENERATED_KEYS);
		
		m_stmtUpdate = cx.getConnection().prepareStatement(
				"UPDATE categories " +
				" SET name = ?, createdByUser = ? " + 
				" WHERE idCategory = ?");
		
		m_stmtDelete = cx.getConnection().prepareStatement(
				"DELETE FROM categories " +
				"WHERE idCategory = ?");
	}

	public MyConnection getConnexion()
	{
		return m_cnx;
	}
	
	public static TupleCategory create(ResultSet p_rset) throws SQLException
	{
		TupleCategory category = null;
		
		category = new TupleCategory();
		category.idCategory = p_rset.getLong("idCategory");
		category.name = p_rset.getString("name");
		category.createdByUser = p_rset.getBoolean("createdByUser");
	
		return category;
	}
	
	public TupleCategory get(Long p_idCategory) throws SQLException
	{
		m_stmtSelect.setLong(1, p_idCategory);
		ResultSet rset = m_stmtSelect.executeQuery();
		TupleCategory category = null;
		
		if (rset.next())
			category = create(rset);

		rset.close();
	    return category;
	}
	
	public ArrayList<TupleCategory> get() throws SQLException
	{
		ResultSet rset = m_stmtSelectAll.executeQuery();
		ArrayList<TupleCategory> categories = new ArrayList<TupleCategory>();
		
		while (rset.next())
			categories.add(create(rset));

		rset.close();
	    return categories;
	}

	public ArrayList<TupleCategory> getUserCategories() throws SQLException
	{
		ResultSet rset = m_stmtSelectAllOnlyUserCategory.executeQuery();
		ArrayList<TupleCategory> categories = new ArrayList<TupleCategory>();
		
		while (rset.next())
			categories.add(create(rset));

		rset.close();
	    return categories;
	}
	
	public Long insert(String p_name, Boolean p_createdByUser) throws SQLException
	{
		m_stmtInsert.setString(1, p_name);
		m_stmtInsert.setBoolean(2, p_createdByUser);
		m_stmtInsert.executeUpdate();
		
		ResultSet rset = m_stmtInsert.getGeneratedKeys();
		Long idDocuement = null;
		
		if (rset.next())
			idDocuement = rset.getLong(1);
		
		return idDocuement;
	}
	
	public int update(Long p_idRSS, String p_name, Boolean p_createdByUser) throws SQLException
	{
		m_stmtUpdate.setString(1, p_name);
		m_stmtUpdate.setBoolean(2, p_createdByUser);
		m_stmtUpdate.setLong(3, p_idRSS);
		
		return m_stmtUpdate.executeUpdate();
	}
	
	public int delete(Long p_idCategory) throws SQLException
	{
		m_stmtDelete.setLong(1, p_idCategory);
		return m_stmtDelete.executeUpdate();
	}
}
