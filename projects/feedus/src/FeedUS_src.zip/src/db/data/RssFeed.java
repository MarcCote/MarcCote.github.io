package db.data;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import db.MyConnection;
import db.tuple.TupleRssFeed;

public class RssFeed
{
	private PreparedStatement m_stmtSelect;
	private PreparedStatement m_stmtSelectAll;
	private PreparedStatement m_stmtInsert;
	private PreparedStatement m_stmtUpdate;
	private PreparedStatement m_stmtDelete;
	private MyConnection m_cnx;

	/**
	  * Creation of an instance. Prepared statements are built.
	  */
	public RssFeed(MyConnection cx) throws SQLException 
	{	
		m_cnx = cx;
		m_stmtSelect = cx.getConnection().prepareStatement(
				"SELECT idRSS, name, url, tagID, tagClass, tagName, tag " +
				"FROM rss_feeds " +
				"WHERE idRSS = ?");
		
		m_stmtSelectAll = cx.getConnection().prepareStatement(
				"SELECT idRSS, name, url, tagID, tagClass, tagName, tag " +
				"FROM rss_feeds");
		
		m_stmtInsert = cx.getConnection().prepareStatement(
				"INSERT INTO rss_feeds (name, url, tagID, tagClass, tagName, tag) " +
				" VALUES (?, ?, ?, ?, ?, ?) ", Statement.RETURN_GENERATED_KEYS);
		
		m_stmtUpdate = cx.getConnection().prepareStatement(
				"UPDATE rss_feeds " +
				" SET name = ?, url = ?, tagID = ?, "+
				"     tagClass = ?, tagName = ?, tag = ? " + 
				" WHERE idRSS = ?");
		
		m_stmtDelete = cx.getConnection().prepareStatement(
				"DELETE FROM rss_feeds " +
				"WHERE idRSS = ?");
	}

	public MyConnection getConnexion()
	{
		return m_cnx;
	}
	
	public static TupleRssFeed create(ResultSet p_rset) throws SQLException
	{
		TupleRssFeed rss = null;
		
		rss = new TupleRssFeed();
		rss.idRSS = p_rset.getLong("idRSS");
		rss.name = p_rset.getString("name");
		rss.url = p_rset.getString("url");
		rss.tagID = p_rset.getString("tagID");
		rss.tagClass = p_rset.getString("tagClass");
		rss.tagName = p_rset.getString("tagName");
		rss.tag = p_rset.getString("tag");
		
		return rss;
	}
	
	public TupleRssFeed get(Long p_idRSS) throws SQLException
	{
		m_stmtSelect.setLong(1, p_idRSS);
		ResultSet rset = m_stmtSelect.executeQuery();
		TupleRssFeed rssFeed = null;
		
		if (rset.next())
			rssFeed = create(rset);

		rset.close();
	    return rssFeed;
	}
	
	public ArrayList<TupleRssFeed> get() throws SQLException
	{
		ResultSet rset = m_stmtSelectAll.executeQuery();
		ArrayList<TupleRssFeed> rssFeeds = new ArrayList<TupleRssFeed>();
		
		while (rset.next())
			rssFeeds.add(create(rset));

		rset.close();
	    return rssFeeds;
	}
	
	public Long insert(String p_name, String p_url, String p_tagID, String p_tagClass, String p_tagName, String p_tag) throws SQLException
	{
		m_stmtInsert.setString(1, p_name);
		m_stmtInsert.setString(2, p_url);
		m_stmtInsert.setString(3, p_tagID);
		m_stmtInsert.setString(4, p_tagClass);
		m_stmtInsert.setString(5, p_tagName);
		m_stmtInsert.setString(6, p_tag);
		m_stmtInsert.executeUpdate();
		
		ResultSet rset = m_stmtInsert.getGeneratedKeys();
		
		if (rset.next())
			return rset.getLong(1);
		
		return null;
	}
	
	public int update(Long p_idRSS, String p_name, String p_url, String p_tagID, String p_tagClass, String p_tagName, String p_tag) throws SQLException
	{
		m_stmtUpdate.setString(1, p_name);
		m_stmtUpdate.setString(2, p_url);
		m_stmtUpdate.setString(3, p_tagID);
		m_stmtUpdate.setString(4, p_tagClass);
		m_stmtUpdate.setString(5, p_tagName);
		m_stmtUpdate.setString(6, p_tag);
		m_stmtUpdate.setLong(7, p_idRSS);
		
		return m_stmtUpdate.executeUpdate();
	}
	
	public int delete(Long p_idRSS) throws SQLException
	{
		m_stmtDelete.setLong(1, p_idRSS);
		return m_stmtDelete.executeUpdate();
	}
}
