package db.data;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TreeMap;

import algo.TypeAlgo;

import db.MyConnection;
import db.tuple.TupleDocument;

public class Document
{
	private PreparedStatement m_stmtSelect;
	private PreparedStatement m_stmtSelectBySource;
	private PreparedStatement m_stmtSelectAll;
	private PreparedStatement m_stmtSelectNbDocument;
	private PreparedStatement m_stmtSelectNbClassifiedDocument;
	private PreparedStatement m_stmtSelectClassifiedDocumentClasses;
	private PreparedStatement m_stmtInsert;
	private PreparedStatement m_stmtUpdate;
	private PreparedStatement m_stmtDelete;
	private MyConnection m_cnx;

	/**
	  * Creation of an instance. Prepared statements are built.
	  */
	public Document(MyConnection cx) throws SQLException 
	{	
		m_cnx = cx;
		m_stmtSelect = cx.getConnection().prepareStatement(
				"SELECT idDocument, title, description, date, author, seen, visible, source, text, idRSS " +
				"FROM documents " +
				"WHERE idDocument = ?");
		
		m_stmtSelectBySource = cx.getConnection().prepareStatement(
				"SELECT idDocument, title, description, date, author, seen, visible, source, text, idRSS " +
				"FROM documents " +
				"WHERE source = ?");
		
		m_stmtSelectAll = cx.getConnection().prepareStatement(
				"SELECT idDocument, title, description, date, author, seen, visible, source, text, idRSS " +
				"FROM documents");
		
		m_stmtSelectNbDocument = cx.getConnection().prepareStatement(
				"select count(*) nbDocument " +
				"from documents");
		
		m_stmtSelectNbClassifiedDocument = cx.getConnection().prepareStatement(
				"SELECT count(*) nbDocument " +
				"FROM documents_categories " +
				"WHERE idalgo = ?");
		
		m_stmtSelectClassifiedDocumentClasses = cx.getConnection().prepareStatement(
				"SELECT idDocument, idCategory " +
				"FROM documents_categories " +
				"WHERE idalgo = ?");
		
		m_stmtInsert = cx.getConnection().prepareStatement(
				"INSERT INTO documents (title, description, date, author, seen, visible, source, text, idRSS) " +
				" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
		
		m_stmtUpdate = cx.getConnection().prepareStatement(
				"UPDATE documents " +
				" SET title = ?, description = ?, date = ?, "+
				"     author = ?, seen = ?, visible = ?, source = ?, " + 
				"	  text = ?, idRSS = ? " + 
				" WHERE idDocument = ?");
		
		m_stmtDelete = cx.getConnection().prepareStatement(
				"DELETE FROM documents " +
				"WHERE idDocument = ?");
	}

	public MyConnection getConnexion()
	{
		return m_cnx;
	}
	
	public static TupleDocument create(ResultSet p_rset) throws SQLException
	{
		TupleDocument document = null;
		
		document = new TupleDocument();
		document.idDocument = p_rset.getLong("idDocument");
		document.title = p_rset.getString("title");
		document.description = p_rset.getString("description");
		document.date.setTime(p_rset.getDate("date"));
		document.author = p_rset.getString("author");
		document.seen = p_rset.getBoolean("seen");
		document.visible = p_rset.getBoolean("visible");
		document.source = p_rset.getString("source");
		document.text = p_rset.getString("text");
		document.idRSS = p_rset.getLong("idRSS");
		
		return document;
	}
	
	public TupleDocument get(Long p_idDocument) throws SQLException
	{
		m_stmtSelect.setLong(1, p_idDocument);
		ResultSet rset = m_stmtSelect.executeQuery();
		TupleDocument document = null;
		
		if (rset.next())
			document = create(rset);

		rset.close();
	    return document;
	}
	
	public TupleDocument get(String p_source) throws SQLException
	{
		m_stmtSelectBySource.setString(1, p_source);
		ResultSet rset = m_stmtSelectBySource.executeQuery();
		TupleDocument document = null;
		
		if (rset.next())
			document = create(rset);

		rset.close();
	    return document;
	}
	
	public ArrayList<TupleDocument> get() throws SQLException
	{
		ResultSet rset = m_stmtSelectAll.executeQuery();
		ArrayList<TupleDocument> documents = new ArrayList<TupleDocument>();
		
		while (rset.next())
			documents.add(create(rset));

		rset.close();
	    return documents;
	}
	
	public long getNbDocument() throws SQLException
	{
		ResultSet rset = m_stmtSelectNbDocument.executeQuery();
		rset.next();
		long nbDoc = rset.getLong("nbDocument");
		rset.close();
	    return nbDoc;	
	}
	
	public long getNbClassifiedDocument() throws SQLException
	{
		m_stmtSelectNbClassifiedDocument.setLong(1, TypeAlgo.USER.getCode());
		ResultSet rset = m_stmtSelectNbClassifiedDocument.executeQuery();
		rset.next();
		long nbDoc = rset.getLong("nbDocument");
		rset.close();
	    return nbDoc;	
	}
	
	public TupleDocument insert(String p_title, String p_description, Calendar p_date, String p_author, Boolean p_seen, Boolean p_visible, String p_source, String p_text, Long p_idRSS) throws SQLException
	{
		m_stmtInsert.setString(1, p_title);
		m_stmtInsert.setString(2, p_description);
		m_stmtInsert.setDate(3, new Date(p_date.getTime().getTime()));
		m_stmtInsert.setString(4, p_author);
		m_stmtInsert.setBoolean(5, p_seen);
		m_stmtInsert.setBoolean(6, p_visible);
		m_stmtInsert.setString(7, p_source);
		m_stmtInsert.setString(8, p_text);
		m_stmtInsert.setLong(9, p_idRSS);
		m_stmtInsert.executeUpdate();
		
		ResultSet rset = m_stmtInsert.getGeneratedKeys();
		TupleDocument document = new TupleDocument(null, p_title, p_description, p_date, p_author, p_seen, p_visible, p_source, p_text, p_idRSS);
		
		if (rset.next())
			document.idDocument = rset.getLong(1);
		
		return document;
	}
	
	public int update(Long p_idDocument, String p_title, String p_description, Calendar p_date, String p_author, Boolean p_seen, Boolean p_visible, String p_source, String p_text, Long p_idRSS) throws SQLException
	{
		m_stmtUpdate.setString(1, p_title);
		m_stmtUpdate.setString(2, p_description);
		m_stmtUpdate.setDate(3, new Date(p_date.getTime().getTime()));
		m_stmtUpdate.setString(4, p_author);
		m_stmtUpdate.setBoolean(5, p_seen);
		m_stmtUpdate.setBoolean(6, p_visible);
		m_stmtUpdate.setString(7, p_source);
		m_stmtUpdate.setString(8, p_text);
		m_stmtUpdate.setLong(9, p_idRSS);
		m_stmtUpdate.setLong(10, p_idDocument);
		
		return m_stmtUpdate.executeUpdate();
	}
	
	public int delete(Long p_idDocument) throws SQLException
	{
		m_stmtDelete.setLong(1, p_idDocument);
		return m_stmtDelete.executeUpdate();
	}

	public TreeMap<Integer, Integer> getClassifiedDocumentClasses() throws SQLException
	{
		m_stmtSelectClassifiedDocumentClasses.setLong(1, TypeAlgo.USER.getCode());
		ResultSet rset = m_stmtSelectNbClassifiedDocument.executeQuery();
		TreeMap<Integer, Integer> map = new TreeMap<Integer, Integer>();

		while (rset.next())
			map.put((int)rset.getLong("idword"),(int)rset.getLong("nbDocument"));

		rset.close();
		
		return map;
	}
}
