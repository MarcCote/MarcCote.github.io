package db.data;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import db.MyConnection;
import db.tuple.TupleModel;

public class Model {
	
	private PreparedStatement m_stmtSelect;
	private PreparedStatement m_stmtInsert;
	private PreparedStatement m_stmtUpdate;
	private PreparedStatement m_stmtDelete;
	private MyConnection m_cnx;

	/**
	  * Creation of an instance. Prepared statements are built.
	  */
	public Model(MyConnection cx) throws SQLException 
	{	
		m_cnx = cx;
		m_stmtSelect = cx.getConnection().prepareStatement(
				"SELECT idAlgo, name, data " +
				"FROM models " +
				"WHERE idAlgo = ?");
		
		m_stmtInsert = cx.getConnection().prepareStatement(
				"INSERT INTO models (idAlgo, name, data) " +
				" VALUES (?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
		
		m_stmtUpdate = cx.getConnection().prepareStatement(
				"UPDATE models " +
				" SET name = ?, data = ? " + 
				" WHERE idAlgo = ?");
		
		m_stmtDelete = cx.getConnection().prepareStatement(
				"DELETE FROM models " +
				"WHERE idAlgo = ?");
	}

	public MyConnection getConnexion()
	{
		return m_cnx;
	}
	
	public static TupleModel create(ResultSet p_rset) throws SQLException
	{
		TupleModel model = null;
		
		model = new TupleModel();
		model.idAlgo = p_rset.getLong("idAlgo");
		model.name = p_rset.getString("name");
		model.data = p_rset.getBytes("data");
		
		return model;
	}
	
	public TupleModel get(Integer p_idAlgo) throws SQLException
	{
		m_stmtSelect.setLong(1, p_idAlgo);
		ResultSet rset = m_stmtSelect.executeQuery();
		TupleModel model = null;
		
		if (rset.next())
			model = create(rset);

		rset.close();
	    return model;
	}
	
	public Long insert(Long p_idAlgo, String p_name, byte[] p_data) throws SQLException
	{
		m_stmtInsert.setLong(1, p_idAlgo);
		m_stmtInsert.setString(2, p_name);
		m_stmtInsert.setBytes(3, p_data);
		m_stmtInsert.executeUpdate();
		
		ResultSet rset = m_stmtInsert.getGeneratedKeys();
		
		if (rset.next())
			return rset.getLong(1);
		
		return null;
	}
	
	public int update(Long p_idAlgo, String p_name, byte[] p_data) throws SQLException
	{
		m_stmtUpdate.setString(1, p_name);
		m_stmtUpdate.setBytes(2, p_data);
		m_stmtUpdate.setLong(3, p_idAlgo);
		m_stmtUpdate.executeUpdate();
		
		return m_stmtUpdate.executeUpdate();
	}
	
	public int delete(Long p_idAlgo) throws SQLException
	{
		m_stmtDelete.setLong(1, p_idAlgo);
		return m_stmtDelete.executeUpdate();
	}

}
