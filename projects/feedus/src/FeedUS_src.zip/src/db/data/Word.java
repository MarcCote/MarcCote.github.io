package db.data;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import db.MyConnection;
import db.tuple.TupleWord;

public class Word
{
	private PreparedStatement m_stmtSelect;
	private PreparedStatement m_stmtSelectByWord;
	private PreparedStatement m_stmtSelectAll;
	private PreparedStatement m_stmtNbWord;
	private PreparedStatement m_stmtInsert;
	private PreparedStatement m_stmtUpdate;
	private PreparedStatement m_stmtDelete;
	private MyConnection m_cnx;
	
	/**
	  * Creation of an instance. Prepared statements are built.
	  */
	public Word(MyConnection cx) throws SQLException 
	{	
		m_cnx = cx;
		m_stmtSelect = cx.getConnection().prepareStatement(
				"SELECT idWord, word, totalDocCount " +
				"FROM words " +
				"WHERE idWord = ?");
		
		m_stmtSelectByWord = cx.getConnection().prepareStatement(
				"SELECT idWord, word, totalDocCount " +
				"FROM words " +
				"WHERE word = ?");
		
		m_stmtSelectAll = cx.getConnection().prepareStatement(
				"SELECT idWord, word, totalDocCount " +
				"FROM words");
		
		m_stmtNbWord = cx.getConnection().prepareStatement(
				"select max(idWord) nbWord from words");
		
		m_stmtInsert = cx.getConnection().prepareStatement(
				"INSERT INTO words (word, totalDocCount) " +
				" VALUES (?, ?) ", Statement.RETURN_GENERATED_KEYS);
		
		m_stmtUpdate = cx.getConnection().prepareStatement(
				"UPDATE words " +
				" SET word = ?, totalDocCount = ? " + 
				" WHERE idWord = ?");
		
		m_stmtDelete = cx.getConnection().prepareStatement(
				"DELETE FROM words " +
				"WHERE idWord = ?");
	}

	public MyConnection getConnexion()
	{
		return m_cnx;
	}
	
	public static TupleWord create(ResultSet p_rset) throws SQLException
	{
		TupleWord word = null;
		
		word = new TupleWord();
		word.idWord = p_rset.getLong("idWord");
		word.word = p_rset.getString("word");
		word.totalDocCount = p_rset.getLong("totalDocCount");
		
		return word;
	}
	
	public TupleWord get(Long p_idWord) throws SQLException
	{
		m_stmtSelect.setLong(1, p_idWord);
		ResultSet rset = m_stmtSelect.executeQuery();
		TupleWord word = null;
		
		if (rset.next())
			word = create(rset);

		rset.close();
	    return word;
	}
	
	public TupleWord get(String p_word) throws SQLException
	{
		m_stmtSelectByWord.setString(1, p_word);
		ResultSet rset = m_stmtSelectByWord.executeQuery();
		TupleWord word = null;
		
		if (rset.next())
			word = create(rset);

		rset.close();
	    return word;
	}
	
	public ArrayList<TupleWord> get() throws SQLException
	{
		ResultSet rset = m_stmtSelectAll.executeQuery();
		ArrayList<TupleWord> words = new ArrayList<TupleWord>();
		
		while (rset.next())
			words.add(create(rset));

		rset.close();
	    return words;
	}
	
	public long getNbWord() throws SQLException
	{
		ResultSet rset = m_stmtNbWord.executeQuery();
		rset.next();
		long result = rset.getLong("nbWord");
		rset.close();
		return result;
	}
	
	public TupleWord insert(String p_word, Long p_totalDocCount) throws SQLException
	{
		m_stmtInsert.setString(1, p_word);
		m_stmtInsert.setLong(2, p_totalDocCount);
		m_stmtInsert.executeUpdate();
		
		ResultSet rset = m_stmtInsert.getGeneratedKeys();
		TupleWord word = new TupleWord(null, p_word, p_totalDocCount);
		
		if (rset.next())
			word.idWord = rset.getLong(1);
		
		return word;
	}
	
	public int update(Long p_idWord, String p_word, Long p_totalDocCount) throws SQLException
	{
		m_stmtUpdate.setString(1, p_word);
		m_stmtUpdate.setLong(2, p_totalDocCount);
		m_stmtUpdate.setLong(3, p_idWord);
		
		return m_stmtUpdate.executeUpdate();
	}
	
	public int delete(Long p_idWord) throws SQLException
	{
		m_stmtDelete.setLong(1, p_idWord);
		return m_stmtDelete.executeUpdate();
	}
}
