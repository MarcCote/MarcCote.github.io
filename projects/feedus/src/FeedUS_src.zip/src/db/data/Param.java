package db.data;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.TreeMap;

import db.MyConnection;
import db.tuple.TupleParam;

public class Param
{
	private PreparedStatement m_stmtSelect;
	private PreparedStatement m_stmtSelectByAlgo;
	private PreparedStatement m_stmtSelectAll;
	private PreparedStatement m_stmtInsert;
	private PreparedStatement m_stmtUpdate;
	private PreparedStatement m_stmtDelete;
	private MyConnection m_cnx;
	
	/**
	  * Creation of an instance. Prepared statements are built.
	  */
	public Param(MyConnection cx) throws SQLException 
	{	
		m_cnx = cx;
		m_stmtSelect = cx.getConnection().prepareStatement(
				"SELECT idParam, idAlgo, name, value " +
				"FROM params " +
				"WHERE idParam = ?");
		
		m_stmtSelectAll = cx.getConnection().prepareStatement(
				"SELECT idParam, idAlgo, name, value " +
				"FROM params");
		
		m_stmtSelectByAlgo = cx.getConnection().prepareStatement(
				"SELECT idParam, idAlgo, name, value " +
				"FROM params " +
				"WHERE idAlgo = ?");
		
		m_stmtInsert = cx.getConnection().prepareStatement(
				"INSERT INTO params (idAlgo, name, value) " +
				" VALUES (?, ?, ?) ", Statement.RETURN_GENERATED_KEYS);
		
		m_stmtUpdate = cx.getConnection().prepareStatement(
				"UPDATE params " +
				" SET idAlgo = ?, name = ?, value = ? " + 
				" WHERE idParam = ?");
		
		m_stmtDelete = cx.getConnection().prepareStatement(
				"DELETE FROM params " +
				"WHERE idParam = ?");
	}

	public MyConnection getConnexion()
	{
		return m_cnx;
	}
	
	public static TupleParam create(ResultSet p_rset) throws SQLException
	{
		TupleParam param = null;
		
		param = new TupleParam();
		param.idParams = p_rset.getLong("idParam");
		param.idAlgo = p_rset.getLong("idAlgo");
		param.name = p_rset.getString("name");
		param.value = p_rset.getString("value");
		
		return param;
	}
	
	public TupleParam get(Long p_idWord) throws SQLException
	{
		m_stmtSelect.setLong(1, p_idWord);
		ResultSet rset = m_stmtSelect.executeQuery();
		TupleParam param = null;
		
		if (rset.next())
			param = create(rset);

		rset.close();
	    return param;
	}
	
	public ArrayList<TupleParam> get() throws SQLException
	{
		ResultSet rset = m_stmtSelectAll.executeQuery();
		ArrayList<TupleParam> params = new ArrayList<TupleParam>();
		
		while (rset.next())
			params.add(create(rset));

		rset.close();
	    return params;
	}
	
	public ArrayList<TupleParam> getByAlgo(Long p_idAlgo) throws SQLException
	{
		m_stmtSelectByAlgo.setLong(1, p_idAlgo);
		ResultSet rset = m_stmtSelectByAlgo.executeQuery();
		ArrayList<TupleParam> params = new ArrayList<TupleParam>();
		
		while (rset.next())
			params.add(create(rset));

		rset.close();
	    return params;
	}
	
	public TreeMap<String, String> getTreeByAlgo(Long p_idAlgo) throws SQLException
	{
		m_stmtSelectByAlgo.setLong(1, p_idAlgo);
		ResultSet rset = m_stmtSelectByAlgo.executeQuery();
		TreeMap<String, String> params = new TreeMap<String, String>();
		
		while (rset.next())
		{
			TupleParam param = create(rset);
			params.put(param.name, param.value);
		}

		rset.close();
	    return params;
	}
	
	public Long insert(Long p_idAlgo, String p_name, String p_value) throws SQLException
	{
		m_stmtInsert.setLong(1, p_idAlgo);
		m_stmtInsert.setString(2, p_name);
		m_stmtInsert.setString(3, p_value);
		m_stmtInsert.executeUpdate();
		
		ResultSet rset = m_stmtInsert.getGeneratedKeys();
		
		if (rset.next())
			return rset.getLong(1);
		
		return null;
	}
	
	public int update(Long p_idParam, Long p_idAlgo, String p_name, String p_value) throws SQLException
	{
		m_stmtUpdate.setLong(1, p_idAlgo);
		m_stmtUpdate.setString(2, p_name);
		m_stmtUpdate.setString(3, p_value);
		m_stmtUpdate.setLong(4, p_idParam);
		
		return m_stmtUpdate.executeUpdate();
	}
	
	public int delete(Long p_idParam) throws SQLException
	{
		m_stmtDelete.setLong(1, p_idParam);
		return m_stmtDelete.executeUpdate();
	}
}
