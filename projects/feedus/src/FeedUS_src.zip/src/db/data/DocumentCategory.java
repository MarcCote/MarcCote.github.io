package db.data;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import algo.TypeAlgo;

import db.MyConnection;
import db.tuple.TupleDocumentCategory;

public class DocumentCategory
{
	private PreparedStatement m_stmtSelectRef;
	private PreparedStatement m_stmtSelect;
	private PreparedStatement m_stmtSelectByAlgoUserOther;
	private PreparedStatement m_stmtSelectByAlgoUserOtherOnlyVisible;
	private PreparedStatement m_stmtSelectRefByAlgo;
	private PreparedStatement m_stmtSelectByAlgo;
	private PreparedStatement m_stmtSelectByAlgoOnlyVisible;
	private PreparedStatement m_stmtSelectRefByOther;
	private PreparedStatement m_stmtSelectByOther;
	private PreparedStatement m_stmtSelectByOtherOnlyVisible;
	private PreparedStatement m_stmtSelectAll;
	private PreparedStatement m_stmtInsert;
	private PreparedStatement m_stmtUpdate;
	private PreparedStatement m_stmtDelete;
	private PreparedStatement m_stmtDeleteFromAllCategories;
	private PreparedStatement m_stmtDeleteByCategory;
	
	private MyConnection m_cnx;
	
	/**
	  * Creation of an instance. Prepared statements are built.
	  */
	public DocumentCategory(MyConnection cx) throws SQLException 
	{	
		m_cnx = cx;
		m_stmtSelectRef = cx.getConnection().prepareStatement(
				"SELECT idAlgo, idDocument, idCategory " +
				"FROM documents_categories " +
				"WHERE idAlgo = ? AND idDocument = ?");
		
		m_stmtSelectByAlgoUserOther = cx.getConnection().prepareStatement(
					"SELECT documents_categories.idAlgo, documents_categories.idDocument, documents_categories.idCategory, " + 
					" title, description, date, author, seen, visible, source, text, idRSS, " + 
					" name, createdByUser " +
					"FROM documents_categories " +
					"INNER JOIN documents ON documents.idDocument = documents_categories.idDocument " +
					"INNER JOIN categories ON categories.idCategory = documents_categories.idCategory " +
					"WHERE idAlgo = ? " + 
						"AND documents_categories.idDocument NOT IN " + 
							"(SELECT idDocument " +
							"FROM documents_categories " +
							"WHERE idAlgo = " + TypeAlgo.USER.getCode() + " ) " +
				"UNION " +
					"SELECT documents_categories.idAlgo, documents_categories.idDocument, documents_categories.idCategory, " + 
					" title, description, date, author, seen, visible, source, text, idRSS, " + 
					" name, createdByUser " +
					"FROM documents_categories " +
					"INNER JOIN documents ON documents.idDocument = documents_categories.idDocument " +
					"INNER JOIN categories ON categories.idCategory = documents_categories.idCategory " +
					"WHERE idAlgo = ? " + 
						"AND documents_categories.idDocument NOT IN " + 
							"(SELECT idDocument " +
							"FROM documents_categories " +
							"WHERE idAlgo = ?)" +
						"AND documents_categories.idDocument NOT IN " + 
							"(SELECT idDocument " +
							"FROM documents_categories " +
							"WHERE idAlgo = " + TypeAlgo.USER.getCode() + ") " +
				"UNION " +
					"SELECT documents_categories.idAlgo, documents_categories.idDocument, documents_categories.idCategory, " + 
					" title, description, date, author, seen, visible, source, text, idRSS, " + 
					" name, createdByUser " +
					"FROM documents_categories " +
					"INNER JOIN documents ON documents.idDocument = documents_categories.idDocument " +
					"INNER JOIN categories ON categories.idCategory = documents_categories.idCategory " +
					"WHERE idAlgo = " + TypeAlgo.USER.getCode()
				);
		
		m_stmtSelectByAlgoUserOtherOnlyVisible = cx.getConnection().prepareStatement(
					"SELECT documents_categories.idAlgo, documents_categories.idDocument, documents_categories.idCategory, " + 
					" title, description, date, author, seen, visible, source, text, idRSS, " + 
					" name, createdByUser " +
					"FROM documents_categories " +
					"INNER JOIN documents ON documents.idDocument = documents_categories.idDocument " +
					"INNER JOIN categories ON categories.idCategory = documents_categories.idCategory " +
					"WHERE idAlgo = ? " + 
						"AND visible = true " +
						"AND documents_categories.idDocument NOT IN " + 
							"(SELECT idDocument " +
							"FROM documents_categories " +
							"WHERE idAlgo = " + TypeAlgo.USER.getCode() + " ) " +
				"UNION " +
					"SELECT documents_categories.idAlgo, documents_categories.idDocument, documents_categories.idCategory, " + 
					" title, description, date, author, seen, visible, source, text, idRSS, " + 
					" name, createdByUser " +
					"FROM documents_categories " +
					"INNER JOIN documents ON documents.idDocument = documents_categories.idDocument " +
					"INNER JOIN categories ON categories.idCategory = documents_categories.idCategory " +
					"WHERE idAlgo = ? " + 
						"AND visible = true " +
						"AND documents_categories.idDocument NOT IN " + 
							"(SELECT idDocument " +
							"FROM documents_categories " +
							"WHERE idAlgo = ?)" +
						"AND documents_categories.idDocument NOT IN " + 
							"(SELECT idDocument " +
							"FROM documents_categories " +
							"WHERE idAlgo = " + TypeAlgo.USER.getCode() + ") " +
				"UNION " +
					"SELECT documents_categories.idAlgo, documents_categories.idDocument, documents_categories.idCategory, " + 
					" title, description, date, author, seen, visible, source, text, idRSS, " + 
					" name, createdByUser " +
					"FROM documents_categories " +
					"INNER JOIN documents ON documents.idDocument = documents_categories.idDocument " +
					"INNER JOIN categories ON categories.idCategory = documents_categories.idCategory " +
					"WHERE idAlgo = " + TypeAlgo.USER.getCode() +
						" AND visible = true "
				);
		
		m_stmtSelect = cx.getConnection().prepareStatement(
				"SELECT documents_categories.idAlgo, documents_categories.idDocument, documents_categories.idCategory, " + 
					" title, description, date, author, seen, visible, source, text, idRSS, " + 
					" name, createdByUser " +
				"FROM documents_categories " +
				"INNER JOIN documents ON documents.idDocument = documents_categories.idDocument " +
				"INNER JOIN categories ON categories.idCategory = documents_categories.idCategory " +
				"WHERE documents_categories.idAlgo = ? " + 
					"AND documents_categories.idDocument = ? " +
					"AND documents_categories.idCategory = ?");
		
		m_stmtSelectRefByAlgo = cx.getConnection().prepareStatement(
				"SELECT idAlgo, idDocument, idCategory " +
				"FROM documents_categories " +
				"WHERE idAlgo = ?");
		
		m_stmtSelectByAlgo = cx.getConnection().prepareStatement(
				"SELECT documents_categories.idAlgo, documents_categories.idDocument, documents_categories.idCategory, " + 
				" title, description, date, author, seen, visible, source, text, idRSS, " + 
				" name, createdByUser " +
				"FROM documents_categories " +
				"INNER JOIN documents ON documents.idDocument = documents_categories.idDocument " +
				"INNER JOIN categories ON categories.idCategory = documents_categories.idCategory " +
				"WHERE documents_categories.idAlgo = ? ");
		
		m_stmtSelectByAlgoOnlyVisible = cx.getConnection().prepareStatement(
				"SELECT documents_categories.idAlgo, documents_categories.idDocument, documents_categories.idCategory, " + 
				" title, description, date, author, seen, visible, source, text, idRSS, " + 
				" name, createdByUser " +
				"FROM documents_categories " +
				"INNER JOIN documents ON documents.idDocument = documents_categories.idDocument " +
				"INNER JOIN categories ON categories.idCategory = documents_categories.idCategory " +
				"WHERE documents_categories.idAlgo = ? " +
					"AND visible = true");
		
		m_stmtSelectRefByOther = cx.getConnection().prepareStatement(
				"SELECT idAlgo, idDocument, idCategory " +
				"FROM documents_categories " +
				"WHERE idAlgo = ? " + 
					"AND idDocument NOT IN " + 
						"(SELECT idDocument " +
						"FROM documents_categories " +
						"WHERE idAlgo = ? )");
		
		m_stmtSelectByOther = cx.getConnection().prepareStatement(
				"SELECT documents_categories.idAlgo, documents_categories.idDocument, documents_categories.idCategory, " + 
				" title, description, date, author, seen, visible, source, text, idRSS, " + 
				" name, createdByUser " +
				"FROM documents_categories " +
				"INNER JOIN documents ON documents.idDocument = documents_categories.idDocument " +
				"INNER JOIN categories ON categories.idCategory = documents_categories.idCategory " +
				"WHERE idAlgo = ? " + 
					"AND documents_categories.idDocument NOT IN " + 
						"(SELECT idDocument " +
						"FROM documents_categories " +
						"WHERE idAlgo = ? )");
		
		m_stmtSelectByOtherOnlyVisible = cx.getConnection().prepareStatement(
				"SELECT documents_categories.idAlgo, documents_categories.idDocument, documents_categories.idCategory, " + 
				" title, description, date, author, seen, visible, source, text, idRSS, " + 
				" name, createdByUser " +
				"FROM documents_categories " +
				"INNER JOIN documents ON documents.idDocument = documents_categories.idDocument " +
				"INNER JOIN categories ON categories.idCategory = documents_categories.idCategory " +
				"WHERE idAlgo = ? " +
					"AND visible = true " +
					"AND documents_categories.idDocument NOT IN " + 
						"(SELECT idDocument " +
						"FROM documents_categories " +
						"WHERE idAlgo = ? )");

		m_stmtSelectAll = cx.getConnection().prepareStatement(
				"SELECT idAlgo, idDocument, idCategory " +
				"FROM documents_categories ");
		
		m_stmtInsert = cx.getConnection().prepareStatement(
				"INSERT INTO documents_categories (idAlgo, idDocument, idCategory) " +
				" VALUES (?, ?, ?) ");
		
		m_stmtUpdate = cx.getConnection().prepareStatement(
				"UPDATE documents_categories " +
				" SET idCategory = ? " + 
				" WHERE idAlgo = ? and idDocument = ?");
		
		m_stmtDelete = cx.getConnection().prepareStatement(
				"DELETE FROM documents_categories " +
				"WHERE idAlgo = ? AND idDocument = ? AND idCategory = ?");
		
		m_stmtDeleteFromAllCategories = cx.getConnection().prepareStatement(
				"DELETE FROM documents_categories " +
				"WHERE idAlgo = ? AND idDocument = ? ");
		
		m_stmtDeleteByCategory = cx.getConnection().prepareStatement(
				"DELETE FROM documents_categories " +
				"WHERE idCategory = ? ");
	}

	public MyConnection getConnexion()
	{
		return m_cnx;
	}
	
	public static TupleDocumentCategory create(ResultSet p_rset) throws SQLException
	{
		TupleDocumentCategory document_category = null;
		
		document_category = new TupleDocumentCategory();
		document_category.idAlgo = p_rset.getLong("idAlgo");
		document_category.idDocument = p_rset.getLong("idDocument");
		document_category.idCategory = p_rset.getLong("idCategory");
		
		return document_category;
	}
	
	public ArrayList<TupleDocumentCategory> getByAlgoUserOther(Long p_idAlgo, Long p_idAlternativeAlgo) throws SQLException
	{
		return getByAlgoUserOther(p_idAlgo, p_idAlternativeAlgo, false);
	}
	
	public ArrayList<TupleDocumentCategory> getByAlgoUserOther(Long p_idAlgo, Long p_idAlternativeAlgo, boolean p_getOnlyVisible) throws SQLException
	{
		PreparedStatement preparedStatement = m_stmtSelectByAlgoUserOther;
		
		if (p_getOnlyVisible)
			preparedStatement = m_stmtSelectByAlgoUserOtherOnlyVisible;
			
		preparedStatement.setLong(1, p_idAlgo);
		preparedStatement.setLong(2, p_idAlternativeAlgo);
		preparedStatement.setLong(3, p_idAlgo);
		ResultSet rset = preparedStatement.executeQuery();
		
		ArrayList<TupleDocumentCategory> listDocumentCategory = new ArrayList<TupleDocumentCategory>();
		
		while (rset.next())
	    {
			TupleDocumentCategory document_category = create(rset);
			document_category.category = Category.create(rset);
			document_category.document = Document.create(rset);
			listDocumentCategory.add(document_category);
	    }

		rset.close();
	    return listDocumentCategory;
	}
	
	public TupleDocumentCategory getRef(Long p_idAlgo, Long p_idDocument) throws SQLException
	{
		m_stmtSelectRef.setLong(1, p_idAlgo);
		m_stmtSelectRef.setLong(2, p_idDocument);
		ResultSet rset = m_stmtSelectRef.executeQuery();
		TupleDocumentCategory document_category = null;
		
		if (rset.next())
			document_category = create(rset);

		rset.close();
	    return document_category;
	}
	
	public TupleDocumentCategory get(Long p_idAlgo, Long p_idDocument, Long p_idCategory) throws SQLException
	{
		m_stmtSelect.setLong(1, p_idAlgo);
		m_stmtSelect.setLong(2, p_idDocument);
		m_stmtSelect.setLong(3, p_idCategory);
		ResultSet rset = m_stmtSelect.executeQuery();
		TupleDocumentCategory document_category = null;
		
		if (rset.next())
		{
			document_category = create(rset);
			document_category.document = Document.create(rset);
			document_category.category = Category.create(rset);
		}

		rset.close();
	    return document_category;
	}
	
	public ArrayList<TupleDocumentCategory> getRefByAlgo(Long p_idAlgo) throws SQLException
	{
		m_stmtSelectRefByAlgo.setLong(1, p_idAlgo);
		ResultSet rset = m_stmtSelectRefByAlgo.executeQuery();
		ArrayList<TupleDocumentCategory> listDocumentCategory = new ArrayList<TupleDocumentCategory>();
		
		while (rset.next())
			listDocumentCategory.add(create(rset));

		rset.close();
	    return listDocumentCategory;
	}
	
	public ArrayList<TupleDocumentCategory> getByAlgo(Long p_idAlgo) throws SQLException
	{
		return getByAlgo(p_idAlgo, false);
	}
	
	public ArrayList<TupleDocumentCategory> getByAlgo(Long p_idAlgo, boolean p_getOnlyVisible) throws SQLException
	{
		PreparedStatement preparedStatement = m_stmtSelectByAlgo;
		
		if (p_getOnlyVisible)
			preparedStatement = m_stmtSelectByAlgoOnlyVisible;
			
		preparedStatement.setLong(1, p_idAlgo);
		ResultSet rset = preparedStatement.executeQuery();
		
		ArrayList<TupleDocumentCategory> listDocumentCategory = new ArrayList<TupleDocumentCategory>();
		
		while (rset.next())
	    {
			TupleDocumentCategory document_category = create(rset);
			document_category.category = Category.create(rset);
			document_category.document = Document.create(rset);
			listDocumentCategory.add(document_category);
	    }

		rset.close();
	    return listDocumentCategory;
	}
	
	public ArrayList<TupleDocumentCategory> getRefByOther(Long p_idAlgo, Long p_idAlgoAlternative) throws SQLException
	{
		m_stmtSelectRefByOther.setLong(1, p_idAlgoAlternative);
		m_stmtSelectRefByOther.setLong(2, p_idAlgo);
		ResultSet rset = m_stmtSelectRefByOther.executeQuery();
		ArrayList<TupleDocumentCategory> listDocumentCategory = new ArrayList<TupleDocumentCategory>();

		while (rset.next())
			listDocumentCategory.add(create(rset));

		rset.close();
	    return listDocumentCategory;
	}
	
	public ArrayList<TupleDocumentCategory> getByOther(Long p_idAlgo, Long p_idAlgoAlternative) throws SQLException
	{
		return getByOther(p_idAlgo, p_idAlgoAlternative, false);
	}
	
	public ArrayList<TupleDocumentCategory> getByOther(Long p_idAlgo, Long p_idAlgoAlternative, boolean p_getOnlyVisible) throws SQLException
	{
		PreparedStatement preparedStatement = m_stmtSelectByOther;
		
		if (p_getOnlyVisible)
			preparedStatement = m_stmtSelectByOtherOnlyVisible;
		
		preparedStatement.setLong(1, p_idAlgoAlternative);
		preparedStatement.setLong(2, p_idAlgo);
		ResultSet rset = preparedStatement.executeQuery();
		ArrayList<TupleDocumentCategory> listDocumentCategory = new ArrayList<TupleDocumentCategory>();

		while (rset.next())
		{
			TupleDocumentCategory document_category = create(rset);
			document_category.document = Document.create(rset);
			document_category.category = Category.create(rset);
			listDocumentCategory.add(document_category);
	    }

		rset.close();
	    return listDocumentCategory;
	}
	
	public ArrayList<TupleDocumentCategory> get() throws SQLException
	{
		ResultSet rset = m_stmtSelectAll.executeQuery();
		ArrayList<TupleDocumentCategory> listDocumentCategory = new ArrayList<TupleDocumentCategory>();

		while (rset.next())
			listDocumentCategory.add(create(rset));

		rset.close();
	    return listDocumentCategory;
	}
	
	public boolean insert(Long p_idAlgo, Long p_idDocument, Long p_idCategory) throws SQLException
	{
		m_stmtInsert.setLong(1, p_idAlgo);
		m_stmtInsert.setLong(2, p_idDocument);
		m_stmtInsert.setLong(3, p_idCategory);
		
		return m_stmtInsert.executeUpdate() != 0;
	}
	
	public int update(Long p_algo, Long p_idDocument, Long p_category) throws SQLException
	{
		m_stmtUpdate.setLong(1, p_category);
		m_stmtUpdate.setDouble(2, p_algo);
		m_stmtUpdate.setLong(3, p_idDocument);
		
		return m_stmtUpdate.executeUpdate();
	}
	
	public int delete(Long p_idAlgo, Long p_idDocument) throws SQLException
	{
		m_stmtDeleteFromAllCategories.setLong(1, p_idAlgo);
		m_stmtDeleteFromAllCategories.setLong(2, p_idDocument);
		return m_stmtDeleteFromAllCategories.executeUpdate();
	}
	
	public int delete(Long p_idAlgo, Long p_idDocument, Long p_idCategory) throws SQLException
	{
		m_stmtDelete.setLong(1, p_idAlgo);
		m_stmtDelete.setLong(2, p_idDocument);
		m_stmtDelete.setLong(3, p_idCategory);
		return m_stmtDelete.executeUpdate();
	}

	public int deleteByCategory(Long p_idCategory) throws SQLException
	{
		m_stmtDeleteByCategory.setLong(1, p_idCategory);
		return m_stmtDeleteByCategory.executeUpdate();
	}
}
