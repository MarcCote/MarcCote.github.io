import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeMap;

import kMean.BKMean;
import kMean.BKMeanTrainer;
import tools.SparseVector;
import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instances;
import weka.core.SparseInstance;
import db.MyConnection;
import db.TypeDB;
import db.data.Document;
import db.data.DocumentCategory;
import db.data.Model;
import db.data.WordDocument;
import db.tuple.TupleWordDocument;


public class SVMTest {

	public static void main(String args[])
	{
		weka.classifiers.functions.LibSVM Svm = new weka.classifiers.functions.LibSVM();
		
		try
		{
			MyConnection m_cnx = new MyConnection(TypeDB.MYSQL, "feedus.servebeer.com", "4242", "feedus_ift603", "Simon", "marcus19*");
			WordDocument m_wordDocument = new WordDocument(m_cnx);
			Document m_document = new Document(m_cnx);
			Word m_word = new Word(m_cnx);
			DocumentCategory m_documentCategory = new DocumentCategory(m_cnx);
			Model m_model = new Model(m_cnx);
			
			TreeMap<Integer, Double> IDFs = m_wordDocument.getClassifiedIDF(m_document.getNbClassifiedDocument());
			TreeMap<Integer, Integer> documentClasses = m_document.getClassifiedDocumentClasses();
			
			//ArrayList<TupleWordDocument> tuples =  m_wordDocument.getUnclassifiedWord();
			ArrayList<TupleWordDocument> tuples =  m_wordDocument.getOrderedClassified();
			
			int nbWords = (int) m_word.getNbWord();
			
			FastVector atts = new FastVector();
			ArrayList<Integer> aDocId = new ArrayList<Integer>();
			SparseInstance currentInstance = null;
			Iterator<TupleWordDocument> it = tuples.iterator();
			long lastDocumentId = -1;
			Double idf = null;
			TupleWordDocument twd;
			
			Instances data = new Instances("TrainingSet", atts, nbWords + 1);
			atts.addElement(new Attribute("class"));
			for(int i = 1; i <= nbWords; ++i)
				atts.addElement(new Attribute("" + i));
			
			while(it.hasNext())
			{
				twd = it.next();
				
				if(twd.idDocument != lastDocumentId)
				{
					lastDocumentId = twd.idDocument;
					currentInstance = new SparseInstance(nbWords);
					data.add(currentInstance);
					currentInstance.setValue(0, documentClasses.get(twd.idWord.intValue()));
					aDocId.add(twd.idDocument.intValue());
				}
				
				
				idf = IDFs.get(twd.idWord.intValue());
				
				if(idf!=null)
					currentInstance.setValue(twd.idWord.intValue(), twd.weight*idf);
				else
					System.out.println("Missing idf for word id " + twd.idWord);
				
		
			}
			
			
			
			BKMeanTrainer bkmean = new BKMeanTrainer(
					aInstances.toArray(new SparseVector[aInstances.size()]),
					aDocId.toArray(new Integer[aDocId.size()]), 10, 4);
			
			bkmean.train();
			

//			m_model.insert(6l, "BKMean", bkmean.getModel().toString().getBytes());
			m_model.update(6l, "BKMean", bkmean.getModel().toString().getBytes());

			m_cnx.commit();
			
			String textModel = new String(m_model.get(6).data);
			
			BKMean bk2 = new BKMean(textModel);
			
			for(int i = 0;i<bkmean.mK;++i)
			{
				System.out.println("Cluster : " + i);
				for(SparseVector j : bkmean.mCluster[i])
				{
					System.out.print(bk2.cluster(j));
				}
				System.out.println();
			}
			
//			String textModel = bkmean.getModel().toString()
			
//			FileOutputStream fos = new FileOutputStream("test.txt");
//			OutputStreamWriter out = new OutputStreamWriter(fos);
//			out.write(textModel);
//			out.flush();
			
			
			//System.out.println(bkmean.getModel().toString());
			
			int a = 0;
			for(Integer[] i : bkmean.mDocId)
			{
				System.out.println("Cluster : " + a);
				for(Integer j : i)
				{
					if(m_documentCategory.getRef(6, j.longValue())==null)
						m_documentCategory.insert(6, j.longValue(), (long) (a+16));
					else
						m_documentCategory.update(6l, j.longValue(), (long) (a+16));
					
					// Print
					//TupleDocument tp = m_document.get(j.longValue());
					//System.out.println("\t"+tp.title);
				}
				++a;
			}
			m_cnx.commit();
			m_cnx.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
