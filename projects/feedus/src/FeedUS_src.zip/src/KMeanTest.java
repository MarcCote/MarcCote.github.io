import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeMap;

import tools.SparseVector;
import algo.kmean.BKMean;
import algo.kmean.BKMeanTrainer;
import db.MyConnection;
import db.TypeDB;
import db.data.Document;
import db.data.DocumentCategory;
import db.data.Model;
import db.data.WordDocument;
import db.tuple.TupleWordDocument;


public class KMeanTest {
	
	public static void main(String args[])
	{
		try
		{
			MyConnection m_cnx = new MyConnection(TypeDB.MYSQL, "feedus.servebeer.com", "4242", "feedus_ift603", "Julien", "marcus19*");
			WordDocument m_wordDocument = new WordDocument(m_cnx);
			Document m_document = new Document(m_cnx);
			//Word m_word = new Word(m_cnx);
			DocumentCategory m_documentCategory = new DocumentCategory(m_cnx);
			Model m_model = new Model(m_cnx);
			
			TreeMap<Integer, Double> IDFs = m_wordDocument.getIDF(m_document.getNbDocument());
			
			//ArrayList<TupleWordDocument> tuples =  m_wordDocument.getUnclassifiedWord();
			ArrayList<TupleWordDocument> tuples =  m_wordDocument.getOrdered();
			
			//int nbWords = (int) m_word.getNbWord();
			
			ArrayList<SparseVector> aInstances = new ArrayList<SparseVector>();
			ArrayList<Integer> aDocId = new ArrayList<Integer>();
			SparseVector currentInstance = null;
			Iterator<TupleWordDocument> it = tuples.iterator();
			long lastDocumentId = -1;
			Double idf = null;
			TupleWordDocument twd;
			while(it.hasNext())
			{
				twd = it.next();
				
				if(twd.idDocument != lastDocumentId)
				{
					lastDocumentId = twd.idDocument;
					currentInstance = new SparseVector();
					aInstances.add(currentInstance);
					aDocId.add(twd.idDocument.intValue());
				}
				
				idf = IDFs.get(twd.idWord.intValue());
				
				if(idf!=null)
					currentInstance.set(twd.idWord.intValue(), twd.weight*idf);
				else
					System.out.println("Missing idf for word id " + twd.idWord);
			}
			BKMeanTrainer bkmean = new BKMeanTrainer(
					aInstances.toArray(new SparseVector[aInstances.size()]),
					aDocId.toArray(new Integer[aDocId.size()]), 10, 4);
			
			bkmean.train();
			

//			m_model.insert(6l, "BKMean", bkmean.getModel().toString().getBytes());
			m_model.update(6l, "BKMean", bkmean.getModel().toString().getBytes());

			m_cnx.commit();
			
			String textModel = new String(m_model.get(6).data);
			
			BKMean bk2 = new BKMean(textModel);
			
			for(int i = 0;i<bkmean.mK;++i)
			{
				System.out.println("Cluster : " + i);
				for(SparseVector j : bkmean.mCluster[i])
				{
					System.out.print(bk2.cluster(j));
				}
				System.out.println();
			}
			
//			String textModel = bkmean.getModel().toString()
			
//			FileOutputStream fos = new FileOutputStream("test.txt");
//			OutputStreamWriter out = new OutputStreamWriter(fos);
//			out.write(textModel);
//			out.flush();
			
			
			//System.out.println(bkmean.getModel().toString());
			
			int a = 0;
			for(Integer[] i : bkmean.mDocId)
			{
				System.out.println("Cluster : " + a);
				for(Integer j : i)
				{
					if(m_documentCategory.getRef(6, j.longValue())==null)
						m_documentCategory.insert(6, j.longValue(), (long) (a+16));
					else
						m_documentCategory.update(6l, j.longValue(), (long) (a+16));
					
					// Print
					//TupleDocument tp = m_document.get(j.longValue());
					//System.out.println("\t"+tp.title);
				}
				++a;
			}
			m_cnx.commit();
			m_cnx.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
