

import weka.classifiers.trees.RandomForest;
import weka.clusterers.XMeans;
import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Instances;
import hr.irb.fastRandomForest.FastRandomForest;

public class RandomForestTest {
	
	public static void main(String args[])
	{
	
		//hr.irb.fastRandomForest.FastRandomForest a = new FastRandomForest();
		
		FastVector atts = new FastVector();
		
		atts.addElement(new Attribute("a1"));
		atts.addElement(new Attribute("a2"));
		
		Instances data = new Instances("TrainingSet", atts, nbData);
		
		double[] vals = new double[data.numAttributes()];
		
		vals[0] = 0.5;
		vals[1] = 0.5;
		data.add(new Instance(1.0, vals));
		
		vals[0] = 0.2;
		vals[1] = 0.9;
		data.add(new Instance(1.0, vals));
		
		RandomForest b = new RandomForest();
		
		b.setMaxDepth(value);
		b.setNumFeatures(newNumFeatures);
		b.setNumTrees(newNumTrees);
		b.setSeed(seed);
		b.buildClassifier(data);
		
	}

}
