package web.rss;

import java.util.ArrayList;
import java.util.HashMap;

import web.rss.RssParser.Item;

public class RssFeedItem
{
    public  String title;
    public  String description;
    public  String link;
    public  String language;
    public  String generator;
    public  String copyright;
    public  String imageUrl;
    public  String imageTitle;
    public  String imageLink;
   
    public ArrayList <Item> items;
    public HashMap <String, ArrayList <Item>> category;
   
    public void addItem(Item item)
    {
        if (this.items == null)
            this.items = new ArrayList<Item>();
        this.items.add(item);
    }
   
    public void addItem(String category, Item item)
    {
        if (this.category == null)
            this.category = new HashMap<String, ArrayList<Item>>();
        if (!this.category.containsKey(category))
            this.category.put(category, new ArrayList<Item>());
        this.category.get(category).add(item);
    }
}