package web.html;

import org.htmlparser.Node;
import org.htmlparser.NodeFilter;

public class NoFilter implements NodeFilter
{
	private static final long	serialVersionUID	= -8856481285607256077L;

	@Override
	public boolean accept(Node arg0)
	{
		return true;
	}

}
