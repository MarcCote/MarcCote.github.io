package web.html;

import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;

import org.htmlparser.NodeFilter;
import org.htmlparser.Parser;
import org.htmlparser.filters.AndFilter;
import org.htmlparser.filters.HasAttributeFilter;
import org.htmlparser.filters.TagNameFilter;
import org.htmlparser.util.NodeList;
import org.htmlparser.util.ParserException;

public class HtmlParser
{
	public static String getText(String p_source, String p_tagID, String p_tagClass, String p_tagName, String p_tag)
	{
		String text = null;
		String attribute = null;
		String value = null;
		
		if (p_tagID != null && !p_tagID.isEmpty())
		{
			attribute = "id";
			value = p_tagID;
		}
		else if (p_tagClass != null && !p_tagClass.isEmpty())
		{
			attribute = "class";
			value = p_tagClass;
		}
		else if (p_tagName != null && !p_tagName.isEmpty())
		{
			attribute = "name";
			value = p_tagName;
		}
        
        try
        {	
            Parser parser = new Parser();
            NodeFilter tagFilter = new NoFilter();
            NodeFilter attributeFilter = new NoFilter();

            if (p_tag != null && !p_tag.isEmpty())
            	tagFilter = new TagNameFilter(p_tag);
            
            if (attribute != null && !attribute.isEmpty())
            	attributeFilter = new HasAttributeFilter(attribute, value);
            
            parser.setResource(p_source);
            NodeList nodes = parser.parse(new AndFilter(tagFilter, attributeFilter));
            
            text = nodes.toHtml(true);
        }
        catch(ParserException e)
        {
            e.printStackTrace();
        }
        
        return text;
    }
	
	public static void main(String[] args) throws IOException, ParserException
	{
		URL url = new URL("http://www.reuters.com/article/idUSTRE62E0K420100315?feedType=RSS&feedName=scienceNews&utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+reuters%2FscienceNews+%28News+%2F+US+%2F+Science%29");

        Parser parser;
        NodeFilter filter;
        try
        {
            parser = new Parser();
            filter = new HasAttributeFilter("id", "articleText");
            parser.setResource(url.toExternalForm());
            NodeList nodes = parser.parse(filter);
            
            String html = nodes.toHtml();
            
            FileWriter fw = new FileWriter("try.html");
            fw.write(html);
            fw.close();
            
            html = html.replaceAll("<[^>]*>", "");
            html = html.replaceAll("&[^;]*;", " ");
            
            System.out.println(html);
        }
        catch(ParserException e)
        {
            e.printStackTrace();
        }
    }
}
