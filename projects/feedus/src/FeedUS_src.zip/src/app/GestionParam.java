package app;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.TreeMap;

import app.exception.NotExistingException;
import app.exception.NullOrEmptyException;
import db.MyConnection;
import db.data.Algo;
import db.data.Param;
import db.tuple.TupleParam;

public class GestionParam
{
	MyConnection m_cnx;
	Param m_param;
	Algo m_algo;
	
	public GestionParam(Param p_param, Algo p_algo)
	{
		m_param = p_param;
		m_algo = p_algo;
		m_cnx = p_param.getConnexion();
	}
	
	public void addParam(Long p_idAlgo, String p_name, String p_value) throws Exception
	{
		try
		{
			if (m_algo.get(p_idAlgo) == null)
				throw new NotExistingException("Algorithm associated to the parameter does not exist.");
			
			if (p_name == null || p_name.isEmpty())
				throw new NullOrEmptyException("Name of the parameter is empty or null.");
			
			if (p_value == null || p_value.isEmpty())
				throw new NullOrEmptyException("Value of the parameter is empty or null.");
			
			m_param.insert(p_idAlgo, p_name, p_value);
		    m_cnx.commit();
	    }
		catch (Exception e)
	    {
		    m_cnx.rollback();
		    throw e;
	    }
	}
	
	public void modifyParam(Long p_idParam, Long p_idAlgo, String p_name, String p_value) throws Exception
	{
		try
		{
			if (m_param.get(p_idParam) == null)
				throw new NotExistingException("That parameter does not exist: " + p_idParam);
			
			if (p_name == null || p_name.isEmpty())
				throw new NullOrEmptyException("Name of the parameter is empty or null.");
			
			if (p_value == null || p_value.isEmpty())
				throw new NullOrEmptyException("Value of the parameter is empty or null.");
			
			m_param.update(p_idParam, p_idAlgo, p_name, p_value);
		    m_cnx.commit();
	    }
		catch (Exception e)
	    {
		    m_cnx.rollback();
		    throw e;
	    }
	}
	
	public void removeParam(Long p_idParam) throws Exception
	{
		try
		{
			if (m_param.get(p_idParam) == null)
				throw new NotExistingException("That parameter does not exist: " + p_idParam);
			
			m_param.delete(p_idParam);
		    m_cnx.commit();
	    }
		catch (Exception e)
	    {
		    m_cnx.rollback();
		    throw e;
	    }
	}
	
	public ArrayList<TupleParam> getParams() throws SQLException
	{
		return m_param.get();
	}
	
	public ArrayList<TupleParam> getParamsByAlgo(Long p_idAlgo) throws SQLException
	{
		return m_param.getByAlgo(p_idAlgo);
	}
	
	public TreeMap<String, String> getTreeParamsByAlgo(Long p_idAlgo) throws SQLException
	{
		return m_param.getTreeByAlgo(p_idAlgo);
	}
}