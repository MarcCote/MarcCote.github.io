package app;

import app.exception.NotExistingException;
import db.MyConnection;
import db.data.Algo;
import db.data.Category;
import db.data.Document;
import db.data.DocumentCategory;

public class GestionDocumentCategory
{
	MyConnection m_cnx;
	Category m_category;
	Document m_document;
	Algo m_algo;
	DocumentCategory m_documentCategory;
	
	public GestionDocumentCategory(DocumentCategory p_documentCategory, Category p_category, Document p_document, Algo p_algo)
	{
		m_category = p_category;
		m_document = p_document;
		m_algo = p_algo;
		m_documentCategory = p_documentCategory;
		m_cnx = p_category.getConnexion();
	}

	public void assign(Long p_idAlgo, Long p_idDocument, Long p_idCategory) throws Exception
	{
		try
		{
			if (m_algo.get(p_idAlgo) == null)
				throw new NotExistingException("That algo does not exist: " + p_idAlgo);
			
			if (m_document.get(p_idDocument) == null)
				throw new NotExistingException("That document does not exist: " + p_idDocument);
			
			if (m_category.get(p_idCategory) == null)
				throw new NotExistingException("That category does not exist: " + p_idCategory);
			
			m_documentCategory.insert(p_idAlgo, p_idDocument, p_idCategory);
			m_cnx.commit();
		}
		catch (Exception e)
	    {
		    m_cnx.rollback();
		    throw e;
	    }
	}
	
	public void unassign(Long p_idAlgo, Long p_idDocument) throws Exception
	{
		try
		{
			if (m_algo.get(p_idAlgo) == null)
				throw new NotExistingException("That algo does not exist: " + p_idAlgo);
			
			if (m_document.get(p_idDocument) == null)
				throw new NotExistingException("That document does not exist: " + p_idDocument);

			//TODO: Check if the document was assigned.
			//if (m_documentCategory.get(p_idDocument) == null)
			//	throw new NotExistingException("That document does not exist: " + p_idDocument);

			m_documentCategory.delete(p_idAlgo, p_idDocument);
			m_cnx.commit();
		}
		catch (Exception e)
	    {
		    m_cnx.rollback();
		    throw e;
	    }
	}

}
