package app;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Observable;
import java.util.TreeMap;

import tools.SparseVector;
import algo.TypeAlgo;
import algo.kmean.BKMeanTrainer;
import app.exception.NotExistingException;
import db.MyConnection;
import db.data.Algo;
import db.data.Category;
import db.data.Document;
import db.data.DocumentCategory;
import db.data.Model;
import db.data.Param;
import db.data.RssFeed;
import db.data.Word;
import db.data.WordDocument;
import db.tuple.TupleAlgo;
import db.tuple.TupleCategory;
import db.tuple.TupleDocument;
import db.tuple.TupleDocumentCategory;
import db.tuple.TupleParam;
import db.tuple.TupleRssFeed;
import db.tuple.TupleWordDocument;

public class GestionFeedUS extends Observable
{
	MyConnection m_cnx;
	
	Algo m_algo;
	Document m_document;
	RssFeed m_feedRSS;
	Word m_word;
	Category m_category;
	Model m_model;
	Param m_param;
	
	WordDocument m_wordDocument;
	DocumentCategory m_documentCategory;
	
	GestionDocument m_gestionDocument;
	GestionRssFeed m_gestionFeedRSS;
	GestionCategory m_gestionCategory;
	GestionDocumentCategory m_gestionDocumentCategory;
	GestionParam m_gestionParam;
	
	public GestionFeedUS(MyConnection p_cnx) throws SQLException
	{
		m_cnx = p_cnx;
		m_algo = new Algo(m_cnx);
		m_document = new Document(m_cnx);
		m_feedRSS = new RssFeed(m_cnx);
		m_word = new Word(m_cnx);
		m_category = new Category(m_cnx);
		m_model = new Model(m_cnx);
		m_param = new Param(m_cnx);
		
		m_wordDocument = new WordDocument(m_cnx);
		m_documentCategory = new DocumentCategory(m_cnx);
		
		m_gestionDocument = new GestionDocument(m_document, m_feedRSS, m_word, m_wordDocument);
		m_gestionFeedRSS = new GestionRssFeed(m_feedRSS, m_document);
		m_gestionCategory = new GestionCategory(m_category, m_documentCategory);
		m_gestionDocumentCategory = new GestionDocumentCategory(m_documentCategory, m_category, m_document, m_algo);
		m_gestionParam = new GestionParam(m_param, m_algo);
	}
	
	public void fetch() throws SQLException
	{
		ArrayList<TupleDocument> documents = m_gestionFeedRSS.checkUpdates();
		
		for (TupleDocument tupleDocument : documents)
		{
			try
			{
				//Get the new ID of the newly inserted document.
				TupleDocument document = m_gestionDocument.addDocument(tupleDocument);
				m_documentCategory.insert(TypeAlgo.NONE.getCode(), document.idDocument, TupleCategory.UNCLUSTERED.idCategory);
			}
			catch (Exception e)
			{
				System.out.println("Failed: " + tupleDocument.title + " => " + e.getMessage());
				e.printStackTrace();
			}
		}
		
		setChanged();
		super.notifyObservers();
		clearChanged();
	}
	
	@Deprecated
	public TreeMap<TupleCategory, ArrayList<TupleDocumentCategory>> getDocs(TypeAlgo p_algo) throws SQLException
	{
		return getDocs(p_algo, TypeAlgo.NONE);
	}
	
	public TreeMap<TupleCategory, ArrayList<TupleDocumentCategory>> getDocs(TypeAlgo p_classficationAlgo, TypeAlgo p_clusteringAlgo) throws SQLException
	{
		ArrayList<TupleDocumentCategory> results = m_documentCategory.getByAlgoUserOther(p_classficationAlgo.getCode(), p_clusteringAlgo.getCode(), true);
		
		TreeMap<TupleCategory, ArrayList<TupleDocumentCategory>> documents = new TreeMap<TupleCategory, ArrayList<TupleDocumentCategory>>(new Comparator<TupleCategory>()
		{
			@Override
			public int compare(TupleCategory o1, TupleCategory o2)
			{
				if (!o1.createdByUser && o2.createdByUser)
					return 1;
				
				if (o1.createdByUser && !o2.createdByUser)
					return -1;
				
				if (o1.name.equalsIgnoreCase(o2.name))
					return o1.idCategory.compareTo(o2.idCategory);
					
				return o1.name.compareToIgnoreCase(o2.name);
			}}
		);
		
		for (TupleDocumentCategory result : results)
		{
			if (!documents.containsKey(result.category))
				documents.put(result.category, new ArrayList<TupleDocumentCategory>());
			
			documents.get(result.category).add(result);
		}
		
		return documents;
	}
	
	
	//RSS feed
	public ArrayList<TupleRssFeed> getRssFeeds() throws SQLException
	{
		return m_gestionFeedRSS.getFeeds();
	}

	public void removeRssFeed(TupleRssFeed p_rss) throws Exception
	{
		m_gestionFeedRSS.removeFeed(p_rss.idRSS);
	}

	public void addRssFeed(TupleRssFeed p_rss) throws Exception
	{
		m_gestionFeedRSS.addFeed(p_rss.name, p_rss.url, p_rss.tagID, p_rss.tagClass, p_rss.tagName, p_rss.tag);
	}

	public void modifyRssFeed(TupleRssFeed p_rss) throws Exception
	{
		m_gestionFeedRSS.modifyFeed(p_rss.idRSS, p_rss.name, p_rss.url, p_rss.tagID, p_rss.tagClass, p_rss.tagName, p_rss.tag);
	}
	

	//Category
	public void assign(TupleDocument p_document, TupleCategory p_category) throws Exception
	{
		m_gestionDocumentCategory.assign(TypeAlgo.USER.getCode(), p_document.idDocument, p_category.idCategory);
	}
	public void unassign(TupleDocument p_document) throws Exception
	{
		m_gestionDocumentCategory.unassign(TypeAlgo.USER.getCode(), p_document.idDocument);
	}

	public ArrayList<TupleCategory> getUserCategories() throws SQLException
	{
		return m_gestionCategory.getUserCategories();
	}

	public ArrayList<TupleCategory> getCategories() throws SQLException
	{
		return m_gestionCategory.getCategories();
	}

	public void addCategory(TupleCategory p_category) throws Exception
	{
		m_gestionCategory.addCategory(p_category.name);
	}

	public void removeCategory(TupleCategory p_category) throws Exception
	{
		m_gestionCategory.removeCategory(p_category.idCategory);
	}

	public void modifyCategory(TupleCategory p_category) throws Exception
	{
		m_gestionCategory.modifyCategory(p_category.idCategory, p_category.name);
	}

	//Algo
	public ArrayList<TupleAlgo> getAlgos() throws SQLException
	{
		return m_algo.get();
	}

	public TupleAlgo getAlgo(Long p_idAlgo) throws SQLException
	{
		return m_algo.get(p_idAlgo);
	}

	//Param
	public void addParam(TupleParam param) throws Exception
	{
		m_gestionParam.addParam(param.idAlgo, param.name, param.value);
	}

	public void modifyParam(TupleParam param) throws Exception
	{
		m_gestionParam.modifyParam(param.idParams, param.idAlgo, param.name, param.value);
	}

	public void removeParam(TupleParam param) throws Exception
	{
		m_gestionParam.removeParam(param.idParams);
	}

	public ArrayList<TupleParam> getParams(Long p_idAlgo) throws SQLException
	{
		return m_gestionParam.getParamsByAlgo(p_idAlgo);
	}

	//Training
	public void train(Long p_idAlgo) throws SQLException, NotExistingException
	{
		//TupleAlgo algo = m_algo.get(p_idAlgo);
		TreeMap<String, String> params = m_gestionParam.getTreeParamsByAlgo(p_idAlgo);

		if (p_idAlgo == TypeAlgo.B_K_MEANS.getCode())
			trainBKMean(params);
		else if (p_idAlgo == TypeAlgo.RANDOM_FOREST_TREE.getCode())
			trainRandomForestTree(params);
		else if (p_idAlgo == TypeAlgo.SVM.getCode())
			trainSVM(params);
		else if (p_idAlgo == TypeAlgo.ROCCHIO.getCode())
			trainRocchio(params);
		else
			throw new NotExistingException("Algorithm does not exist: " + p_idAlgo);
	}
	
	//Bisecting K-Means
	public void trainBKMean(TreeMap<String, String> p_params) throws SQLException
	{
		TreeMap<Integer, Double> IDFs = m_wordDocument.getIDF(m_document.getNbDocument());
		ArrayList<TupleWordDocument> tuples =  m_wordDocument.getOrdered();
		
		ArrayList<SparseVector> aInstances = new ArrayList<SparseVector>();
		ArrayList<Integer> aDocId = new ArrayList<Integer>();
		SparseVector currentInstance = null;
		long lastDocumentId = -1;
		Double idf = null;
		
		for (TupleWordDocument twd : tuples)
		{
			if(twd.idDocument != lastDocumentId)
			{
				lastDocumentId = twd.idDocument;
				currentInstance = new SparseVector();
				aInstances.add(currentInstance);
				aDocId.add(twd.idDocument.intValue());
			}
			
			idf = IDFs.get(twd.idWord.intValue());
			
			if(idf!=null)
				currentInstance.set(twd.idWord.intValue(), twd.weight*idf);
			else
				System.out.println("Missing idf for word id " + twd.idWord);
		}
		
		int nbClusters = Integer.parseInt(p_params.get("-nbClusters"));
		int nbIterations = Integer.parseInt(p_params.get("-nbIterations"));
		
		BKMeanTrainer bkmean = new BKMeanTrainer(
				aInstances.toArray(new SparseVector[aInstances.size()]),
				aDocId.toArray(new Integer[aDocId.size()]), nbClusters, nbIterations);
		
		bkmean.train();
		
		//Update Bisecting K-MEans model.
		m_model.update(TypeAlgo.B_K_MEANS.getCode(), "BKMean", bkmean.getModel().toString().getBytes());

		m_cnx.commit();
	}
	
	//Random Forest Tree
	public void trainRandomForestTree(TreeMap<String, String> params) throws SQLException
	{}
	
	//SVM
	public void trainSVM(TreeMap<String, String> params) throws SQLException
	{}
	
	//Rocchio
	public void trainRocchio(TreeMap<String, String> params) throws SQLException
	{}
}
