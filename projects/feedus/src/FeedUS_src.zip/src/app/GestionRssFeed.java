package app;

import java.sql.SQLException;
import java.util.ArrayList;

import util.MyDate;
import web.rss.RssFeedItem;
import web.rss.RssParser;
import web.rss.RssParser.Item;

import app.exception.NotExistingException;
import app.exception.NullOrEmptyException;
import db.MyConnection;
import db.data.Document;
import db.data.RssFeed;
import db.tuple.TupleDocument;
import db.tuple.TupleRssFeed;

public class GestionRssFeed
{
	MyConnection m_cnx;
	RssFeed m_rssFeed;
	Document m_document;
	
	public GestionRssFeed(RssFeed p_rssFeed, Document p_document)
	{
		m_rssFeed = p_rssFeed;
		m_document = p_document;
		m_cnx = p_rssFeed.getConnexion();
	}
	
	public void addFeed(String p_name, String p_url, String p_tagID, String p_tagClass, String p_tagName, String p_tag) throws Exception
	{
		try
		{
			if (p_name == null || p_name.isEmpty())
				throw new NullOrEmptyException("Name of the RSS feed is empty or null.");
			
			if (p_url == null || p_url.isEmpty())
				throw new NullOrEmptyException("URL of the RSS feed is empty or null.");

			m_rssFeed.insert(p_name, p_url, p_tagID, p_tagClass, p_tagName, p_tag);
		    m_cnx.commit();
	    }
		catch (Exception e)
	    {
		    m_cnx.rollback();
		    throw e;
	    }
	}
	
	public void modifyFeed(Long p_idFeed, String p_name, String p_url, String p_tagID, String p_tagClass, String p_tagName, String p_tag) throws Exception
	{
		try
		{
			if (m_rssFeed.get(p_idFeed) == null)
				throw new NotExistingException("That RSS feed does not exist: " + p_idFeed);
			
			if (p_name == null || p_name.isEmpty())
				throw new NullOrEmptyException("Name of the RSS feed is empty or null.");
			
			if (p_url == null || p_url.isEmpty())
				throw new NullOrEmptyException("URL of the RSS feed is empty or null.");
			
			m_rssFeed.update(p_idFeed, p_name, p_url, p_tagID, p_tagClass, p_tagName, p_tag);
		    m_cnx.commit();
	    }
		catch (Exception e)
	    {
		    m_cnx.rollback();
		    throw e;
	    }
	}
	
	public void removeFeed(Long p_idFeed) throws Exception
	{
		try
		{
			if (m_rssFeed.get(p_idFeed) == null)
				throw new NotExistingException("That RSS feed does not exist: " + p_idFeed);
			
			m_rssFeed.delete(p_idFeed);
		    m_cnx.commit();
	    }
		catch (Exception e)
	    {
		    m_cnx.rollback();
		    throw e;
	    }
	}
	
	public ArrayList<TupleDocument> checkUpdates() throws SQLException
	{
		ArrayList<TupleRssFeed> rssFeeds = m_rssFeed.get();
		ArrayList<TupleDocument> documents = new ArrayList<TupleDocument>();
		
		for (TupleRssFeed rssFeed : rssFeeds)
			documents.addAll(checkUpdates(rssFeed));
		
		return documents;
	}
	
	public ArrayList<TupleDocument> checkUpdates(TupleRssFeed p_rss)
	{
		ArrayList<TupleDocument> documents = new ArrayList<TupleDocument>();
		
		RssParser parser = new RssParser(p_rss.url);
		parser.parse();
		RssFeedItem feed = parser.getFeed();

		for (Item item : feed.items)
		{
			try
			{
				TupleDocument document = new TupleDocument();
				document.title = item.title;
				document.description = item.description;
				document.date = MyDate.parseToCalendar(item.pubDate);
				document.source = item.link;
				document.idRSS = p_rss.idRSS;
			
				if (m_document.get(document.source) != null)
					continue;
				
				documents.add(document);
			}
			catch (Exception e) {}
		}

		return documents;
	}
	
	public ArrayList<TupleRssFeed> getFeeds() throws SQLException
	{
		return m_rssFeed.get();
	}
}