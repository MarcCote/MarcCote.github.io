package app;

import java.sql.SQLException;
import java.util.ArrayList;

import app.exception.NotExistingException;
import app.exception.NullOrEmptyException;
import db.MyConnection;
import db.data.Category;
import db.data.DocumentCategory;
import db.tuple.TupleCategory;

public class GestionCategory
{
	MyConnection m_cnx;
	Category m_category;
	DocumentCategory m_documentCategory;
	
	public GestionCategory(Category p_category, DocumentCategory p_documentCategory)
	{
		m_category = p_category;
		m_documentCategory = p_documentCategory;
		m_cnx = p_category.getConnexion();
	}
	
	public ArrayList<TupleCategory> getCategories() throws SQLException
	{
		return m_category.get();
	}
	
	public ArrayList<TupleCategory> getUserCategories() throws SQLException
	{
		return m_category.getUserCategories();
	}
	
	public void addCategory(String p_name) throws Exception
	{
		try
		{
			if (p_name == null || p_name.isEmpty())
				throw new NullOrEmptyException("The name of the category is empty or null.");
			
			m_category.insert(p_name, true);
		    m_cnx.commit();
	    }
		catch (Exception e)
	    {
		    m_cnx.rollback();
		    throw e;
	    }
	}

	public void removeCategory(Long p_idCategory) throws Exception
	{
		try
		{
			if (m_category.get(p_idCategory) == null)
				throw new NotExistingException("That category does not exist: " + p_idCategory);
			
			//Unassign document from the category.
			m_documentCategory.deleteByCategory(p_idCategory);
			
			//Remove category
			m_category.delete(p_idCategory);
		    m_cnx.commit();
	    }
		catch (Exception e)
	    {
		    m_cnx.rollback();
		    throw e;
	    }
	}
	
	public void modifyCategory(Long p_idCategory, String p_name) throws Exception
	{
		try
		{
			if (m_category.get(p_idCategory) == null)
				throw new NotExistingException("That category does not exist: " + p_idCategory);
			
			if (p_name == null || p_name.isEmpty())
				throw new NullOrEmptyException("Name of the category is empty or null.");

			m_category.update(p_idCategory, p_name, true);
		    m_cnx.commit();
	    }
		catch (Exception e)
	    {
		    m_cnx.rollback();
		    throw e;
	    }
	}

}
