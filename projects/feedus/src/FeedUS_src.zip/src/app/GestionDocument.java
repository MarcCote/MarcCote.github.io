package app;

import java.util.Calendar;
import java.util.Map.Entry;

import preprocessing.TextProcessing;
import web.html.HtmlParser;
import app.exception.NotExistingException;
import app.exception.NullOrEmptyException;
import db.MyConnection;
import db.data.Document;
import db.data.RssFeed;
import db.data.Word;
import db.data.WordDocument;
import db.tuple.TupleDocument;
import db.tuple.TupleRssFeed;
import db.tuple.TupleWord;

public class GestionDocument
{
	MyConnection m_cnx;
	Document m_document;
	RssFeed m_feedRSS;
	Word m_word;
	WordDocument m_wordDocument;
	
	public GestionDocument(Document p_document, RssFeed p_feedRSS, Word p_word, WordDocument p_wordDocument)
	{
		m_document = p_document;
		m_feedRSS = p_feedRSS;
		m_word = p_word;
		m_wordDocument = p_wordDocument;
		m_cnx = p_feedRSS.getConnexion();
	}
	
	private TupleDocument addDocument(String p_title, String p_description, Calendar p_date, String p_author, Boolean p_seen, Boolean p_visible, String p_source, String p_text, Long p_idRSS) throws Exception
	{
		TupleDocument document = null;
		try
		{
			if (p_idRSS == null)
				throw new NullOrEmptyException("The RSS feed ID is null.");
			
			if (m_feedRSS.get(p_idRSS) == null)
				throw new NotExistingException("The RSS feed does not exist: " + p_idRSS); 

			if (p_title == null || p_title.isEmpty())
				throw new NullOrEmptyException("The title of the document is empty or null.");
			
			if (p_description == null || p_description.isEmpty())
				throw new NullOrEmptyException("The description of the document is empty or null.");
			
			if (p_date == null)
				throw new NullOrEmptyException("The date of the document is null.");
			
			if (p_author == null || p_author.isEmpty())
				throw new NullOrEmptyException("The author of the document is empty or null.");
			
			if (p_seen == null)
				throw new NullOrEmptyException("Can't determine if document has been seen or not. (null attribute)");
			
			if (p_source == null || p_source.isEmpty())
				throw new NullOrEmptyException("The source of the document is empty or null.");
			
			if (p_text == null || p_text.isEmpty())
				throw new NullOrEmptyException("The text of the document is empty or null.");

			document = m_document.insert(p_title, p_description, p_date, p_author, p_seen, p_visible, p_source, p_text, p_idRSS);
		    //m_cnx.commit();
	    }
		catch (Exception e)
	    {
		    //m_cnx.rollback();
		    throw e;
	    }
		
		return document;
	}
	
	public TupleDocument addDocument(TupleDocument p_document) throws Exception
	{
		if (p_document.title == null || p_document.title.isEmpty())
			p_document.title = "No Title";
		
		if (p_document.author == null || p_document.author.isEmpty())
			p_document.author = "No Author";
		
		if (p_document.description == null)
			p_document.description = "";
		
		if (p_document.date == null)
			p_document.date = Calendar.getInstance();
			
		return addDocument(p_document.title, p_document.description, p_document.date, p_document.author, p_document.source, p_document.idRSS);
	}
	
	public TupleDocument addDocument(String p_title, String p_description, Calendar p_date, String p_author, String p_source, Long p_idRSS) throws Exception
	{
		try
		{
			if (p_idRSS == null)
				throw new NullOrEmptyException("The RSS feed ID is null.");
			
			TupleRssFeed rss = m_feedRSS.get(p_idRSS);
			if (rss == null)
				throw new NotExistingException("The RSS feed does not exist: " + p_idRSS); 

			if (p_source == null || p_source.isEmpty())
				throw new NullOrEmptyException("The URL to get the document is empty or null.");

			//Retrieve text.
			String rawText = HtmlParser.getText(p_source, rss.tagID, rss.tagClass, rss.tagName, rss.tag);
			TupleDocument document = addDocument(p_title, p_description, p_date, p_author, false, true, p_source, rawText, p_idRSS);
			
			//Process text.
			TextProcessing text = new TextProcessing(rawText);
			
			//Populate words_documents join table.
			for (Entry<String, Integer> entry : text.getWords().entrySet())
			{
				TupleWord word = m_word.get(entry.getKey());
				
				if (word == null)
					word = m_word.insert(entry.getKey(), 0L);
				
				m_wordDocument.insert(document.idDocument, word.idWord, entry.getValue(), ((double)entry.getValue() / (double)text.getNbWords()));
			}

		    m_cnx.commit();
		    return document;
	    }
		catch (Exception e) {
			m_cnx.rollback();
		    throw e;
		}
	}

	public void removeDocument(Long p_idDocument) throws Exception
	{
		try
		{
			if (m_document.get(p_idDocument) == null)
				throw new NotExistingException("That document does not exist: " + p_idDocument);
			
			m_document.delete(p_idDocument);
		    m_cnx.commit();
	    }
		catch (Exception e)
	    {
		    m_cnx.rollback();
		    throw e;
	    }
	}

}
