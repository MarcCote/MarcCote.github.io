package app.exception;

public class NotExistingException extends Exception
{
	private static final long	serialVersionUID	= -5420424683549955552L;
	
	public NotExistingException(String p_msg)
	{
		super(p_msg);
	}
}
