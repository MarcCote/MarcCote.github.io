package app.exception;

public class ParserException extends Exception{

	private static final long serialVersionUID = 94456111691056076L;
	
	public ParserException(String p_message)
	{
		super(p_message);
	}

}
