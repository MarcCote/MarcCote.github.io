package app.exception;

public class NullOrEmptyException extends Exception
{
	private static final long	serialVersionUID	= -6864816006893918829L;

	public NullOrEmptyException(String p_msg)
	{
		super(p_msg);
	}
}
