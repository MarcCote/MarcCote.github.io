package algo.kmean;

import java.util.StringTokenizer;

import tools.SparseVector;

import app.exception.ParserException;

public class BKMean {	

	public BKMeanCentroid mCentroidTree;
	
	public BKMean(BKMeanCentroid root)
	{
		mCentroidTree = root;
	}
	
	public BKMean(String model) throws ParserException
	{		
		StringTokenizer st = new StringTokenizer(model, " \t\r\n\f:;");
		mCentroidTree = new BKMeanCentroid(st);		
	}
	
	public int cluster(SparseVector p_data)
	{
		return mCentroidTree.cluster(p_data);
	}
	
	public String toString()
	{
		return mCentroidTree.toString();
	}

}
