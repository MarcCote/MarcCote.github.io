package algo.kmean;

import java.util.Arrays;

import tools.SparseTool;
import tools.ErrorCode;
import tools.SparseVector;

public class KMean {
	
	public SparseVector[] mData;
	public int[] mDataClass;
	public ClusterInfo[] mClusterInfos;
	public int mK;
	public int mNbData;
	
	public ErrorCode error;
	
	public KMean(SparseVector[] data, int k)
	{
		mData = data;
		mK = k;
		mNbData = data.length;
	}
	
	public void train()
	{
		mDataClass = new int[mNbData];
		mClusterInfos = new ClusterInfo[mK];		
		error = ErrorCode.OK;
		
		if(mNbData<mK)
		{
			error = ErrorCode.NeedMoreData;
			return;
		}
		
		int i = 0;
		int d = 0;
		int nbClassified = 0;
		double dist = 0;
		while(i<mK)
		{			
			if(nbClassified >= mNbData)
			{
				error = ErrorCode.CantCreateAllCluster;
				return;
			}
			
			do
				d = (int) (Math.random()*mNbData);
			while(mDataClass[d] != 0);
			
			for(int j = 0; j<i; ++j)
			{
				dist = 1 - mData[d].cosineSimilarity(mClusterInfos[j].mCentroid); 
				if(dist<0.000000000001)
				{
					mDataClass[d] = j+1;
					mClusterInfos[j].mClusterSum.add(mData[d]);
					mClusterInfos[j].mSSE+=dist;
					++mClusterInfos[j].mNbData;
					++nbClassified;
					j=i;
				}
			}
			
			if(mDataClass[d]==0)
			{
				mDataClass[d] = i+1;
				mClusterInfos[i] = new ClusterInfo(mData[d]);
				mClusterInfos[i].mClusterSum.add(mData[d]);
				++mClusterInfos[i].mNbData;
				++nbClassified;
				++i;
			}
		}
		
		boolean changed = true;
		SparseVector tmp;
		while(changed)
		{
			changed = false;
			iterate();
			
//			for(int clusterNb = 1; clusterNb<mK+1;clusterNb++)
//			{
//				System.out.println("Cluster " + clusterNb + ": " + mCentroids[clusterNb-1].mValue[0] + "\t" + mCentroids[clusterNb-1].mValue[1]);
//				for(int dataNb = 0;dataNb<mNbData;++dataNb)
//				{
//					if(mDataClass[dataNb]==clusterNb)
//						System.out.println(""+mData[dataNb][0]+"\t"+mData[dataNb][1]);
//				}
//			}
			
			for(i = 0; i<mK;++i)
			{
				tmp = new SparseVector(mClusterInfos[i].mClusterSum);
				tmp.divide(mClusterInfos[i].mNbData);
				
				if(!mClusterInfos[i].mCentroid.equals(tmp))
				{
					changed = true;
					mClusterInfos[i].mCentroid=tmp;
				}
			}
			
		}
	}
	
	private void iterate()
	{
		int bestClassIndex = -1;
		double smallestDist = Double.POSITIVE_INFINITY;
		double dist = 0;
		for(int i = 0;i<mNbData;++i)
		{
			bestClassIndex = -1;
			smallestDist = Double.POSITIVE_INFINITY;
			for(int j = 0; j<mK;++j)
			{
				dist = distance(mData[i],mClusterInfos[j].mCentroid);
				if(dist<smallestDist)
				{
					smallestDist = dist;
					bestClassIndex=j;
				}
			}			
			if(bestClassIndex+1!=mDataClass[i])
			{
				if(mDataClass[i]!=0)
				{
					mClusterInfos[mDataClass[i]-1].mClusterSum.sub(mData[i]);
					mClusterInfos[mDataClass[i]-1].mSSE -= smallestDist;
					--mClusterInfos[mDataClass[i]-1].mNbData;
				}
				mClusterInfos[bestClassIndex].mClusterSum.add(mData[i]);
				mClusterInfos[bestClassIndex].mSSE += smallestDist;
				++mClusterInfos[bestClassIndex].mNbData;
				mDataClass[i] = bestClassIndex+1;
			}			
		}
	}
	
	private double distance(SparseVector a, SparseVector b)
	{
//		double[] c = a.clone();
//		ArrayTool.subDoubleArray(c, b);
//		return ArrayTool.norm(c);
		return 1 - a.cosineSimilarity(b);
	}

}
