package algo.kmean;

import tools.ErrorCode;
import tools.SparseVector;

public class BKMeanTrainer {
	
	public int mIter;
	public int mK;
	public SparseVector[][] mCluster;
	public Integer[][] mDocId;
	public ClusterInfo[] mClusterInfos;
	public BKMeanCentroid mCentroidTree;
	public ErrorCode mError;
	
	public BKMeanTrainer(SparseVector[] data, Integer[] docId, int k, int iter){
		mError = ErrorCode.OK;
		mK = k;
		mIter = iter;
		
		mCluster = new SparseVector[mK][];
		mCluster[0] = data;
		mDocId = new Integer[mK][];
		mDocId[0] = docId;
		mClusterInfos = new ClusterInfo[mK];
		mClusterInfos[0] = new ClusterInfo();
		
		mCentroidTree = new BKMeanCentroid((SparseVector) null);
		mClusterInfos[0].mAssociatedBKMeanCentroid = mCentroidTree;
	}
	
	public void train()
	{
		double bestSSE;
		int split = 0;
		int i1, i2;
		KMean kMean;
		BKMeanCentroid bkMeanCentroid;
		
		for(int i = 1; i<mK;++i)
		{
			bestSSE = Double.MAX_VALUE;
			split = 0;
			for(int j = 0; j<i;++j)
				if(mClusterInfos[j].mSSE>mClusterInfos[split].mSSE)
					split=j;
			
			bkMeanCentroid = mClusterInfos[split].mAssociatedBKMeanCentroid;
			bkMeanCentroid.mChildren = new BKMeanCentroid[2];
			Integer[] oldDocId = mDocId[split];
			
			kMean = new KMean(mCluster[split], 2);
			for(int j = 0; j<mIter;++j)
			{
				kMean.train();
				
				if(kMean.error==ErrorCode.OK)
				{					
					if(bestSSE>kMean.mClusterInfos[0].mSSE + kMean.mClusterInfos[1].mSSE)
					{
						bestSSE = kMean.mClusterInfos[0].mSSE + kMean.mClusterInfos[1].mSSE;
						mClusterInfos[split] = kMean.mClusterInfos[0];
						mCluster[split] = new SparseVector[mClusterInfos[split].mNbData];
						mDocId[split] = new Integer[mClusterInfos[split].mNbData];
						bkMeanCentroid.mChildren[0] = new BKMeanCentroid(mClusterInfos[split].mCentroid);
						mClusterInfos[split].mAssociatedBKMeanCentroid = bkMeanCentroid.mChildren[0];
						
						mClusterInfos[i] = kMean.mClusterInfos[1];						
						mCluster[i] = new SparseVector[mClusterInfos[i].mNbData];
						mDocId[i] = new Integer[mClusterInfos[i].mNbData];
						bkMeanCentroid.mChildren[1] = new BKMeanCentroid(mClusterInfos[i].mCentroid);
						mClusterInfos[i].mAssociatedBKMeanCentroid = bkMeanCentroid.mChildren[1]; 
						
						i1 = 0;
						i2 = 0;
						for(int k = 0; k<kMean.mNbData;++k)
						{
							if(kMean.mDataClass[k]==1)
							{
								mDocId[split][i1] = oldDocId[k];
								mCluster[split][i1++] = kMean.mData[k];
							}
							else
							{
								mDocId[i][i2] = oldDocId[k];
								mCluster[i][i2++] = kMean.mData[k];
							}
						}
					}
				} else {
					mError = kMean.error;
					return;
				}
			}
		}
	}
	
	public BKMean getModel()
	{
		for(int i = 0;i<mClusterInfos.length;++i)
		{
			mClusterInfos[i].mAssociatedBKMeanCentroid.mClusterId = i;
		}
		
		return new BKMean(mCentroidTree);
	}

}
