package algo.kmean;

import tools.SparseVector;


public class ClusterInfo {
	
	public SparseVector mCentroid;
	public SparseVector mClusterSum;
	public int mNbData;
	public double mSSE;
	public BKMeanCentroid mAssociatedBKMeanCentroid;
	
	public ClusterInfo()
	{
		mCentroid = new SparseVector();
		mClusterSum = new SparseVector();
		mNbData = 0;
		mSSE = 0;
	}
	
	public ClusterInfo(SparseVector value)
	{
		mCentroid = new SparseVector(value);
		mClusterSum = new SparseVector();
		mNbData = 0;
		mSSE = 0;
	}
}
