package algo.kmean;

import java.util.StringTokenizer;

import app.exception.ParserException;

import tools.SparseVector;

public class BKMeanCentroid {
	
	public static final String ROOT_KEYWORD = "root";
	public static final String NODE_KEYWORD = "node";
	public static final String LEAF_KEYWORD = "leaf";
	
	public SparseVector mValue;
	public BKMeanCentroid[] mChildren;
	public int mClusterId = -1;
	
	public BKMeanCentroid(SparseVector value)
	{
		mValue = value;
		mChildren = null;
	}
	
	public BKMeanCentroid(StringTokenizer st) throws ParserException
	{
		if(!st.hasMoreTokens())
			throw new ParserException("Expecting "+ROOT_KEYWORD+" or " + 
					NODE_KEYWORD+" or "+LEAF_KEYWORD);
		String token = st.nextToken();
		if(token.equals(ROOT_KEYWORD)){
			mValue = null;			
			mChildren = new BKMeanCentroid[2];
			mChildren[0] = new BKMeanCentroid(st);
			mChildren[1] = new BKMeanCentroid(st);
		} 
		else if(token.equals(NODE_KEYWORD)){
			mValue = new SparseVector(st);			
			mChildren = new BKMeanCentroid[2];
			mChildren[0] = new BKMeanCentroid(st);
			mChildren[1] = new BKMeanCentroid(st);
		}
		else if(token.equals(LEAF_KEYWORD)) {
			mValue = new SparseVector(st);
			if(!st.hasMoreTokens())
				throw new ParserException("Expecting ClusterID, reach EOF");
			token = st.nextToken();
			try {
				mClusterId = Integer.parseInt(token);
			} catch(NumberFormatException e) {
				throw new ParserException("Expecting ClusterID, NumberFormatExcepion " + e.getMessage());
			}
		}
		else
			throw new ParserException("Expecting "+ROOT_KEYWORD+" or " + 
					NODE_KEYWORD+" or "+LEAF_KEYWORD + " received " + token);
	}
	
	public boolean hasChildren()
	{
		return mChildren == null;
	}
	
	public void print(int indentation)
	{
		for(int i = 0;i<indentation;++i)
			System.out.print("\t\t");
		
		if(mValue!=null)
		{
			System.out.println(mValue.toString());
		} else {
			System.out.println("Root");
		}
		if(mChildren!=null)
		{
			for(int i = 0;i<mChildren.length;++i)
				mChildren[i].print(indentation+1);
		}
	}
	
	public int cluster(SparseVector p_data)
	{
		if(mChildren==null)
			return mClusterId;
		
		if(mChildren[0].mValue.cosineSimilarity(p_data) > mChildren[1].mValue.cosineSimilarity(p_data))
			return mChildren[0].cluster(p_data);
		else
			return mChildren[1].cluster(p_data);
	}
	
	public String toString()
	{
		String result = "";
		
		if(mValue==null)
			result += ROOT_KEYWORD + "\n" + mChildren[0].toString() + mChildren[1].toString();
		else if(mChildren!=null)
			result += NODE_KEYWORD + " " + mValue.toString() + "\n" + 
					mChildren[0].toString() + mChildren[1].toString();
		else
			result += LEAF_KEYWORD + " " + mValue.toString() + " " + mClusterId + "\n";
		
		return result;
	}

}
