package algo;

public enum TypeAlgo
{
	NONE(1),
	USER(2),
	SVM(3),
	ROCCHIO(4),
	RANDOM_FOREST_TREE(5),
	B_K_MEANS(6);
	
	private int m_code;
	private TypeAlgo(int code)
	{
		this.m_code = code;
	}

	public long getCode()
	{
		return m_code;
    } 
}
