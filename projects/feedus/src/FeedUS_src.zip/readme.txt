In order to compile FeedUS, you will need thoses libraries:

-Weka
-RapidMiner